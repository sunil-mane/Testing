package com.bt.controllers;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bt.controllers.DataController;
import com.bt.jsonBean.Credentials;
import com.bt.services.V21Properties;



@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"file:///C:\\Users\\611189996\\svn update 10 14 2016\\V21Portal\\src\\main\\webapp\\WEB-INF\\mvc-dispatcher-servlet.xml"})
@ContextConfiguration(locations={"file:**/mvc-dispatcher-servlet.xml"})
public class TestDataController  {
 
    private MockMvc mockMvc;
 
    @Autowired
    private DataController controller;
	@Autowired
	public V21Properties v21Properties;

	Credentials cred = new Credentials();
	
    @Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
       
    }
    /*
    @Test
    public void testUserAuth() throws Exception {
    	Credentials credentials = new Credentials();
    	credentials.setUsername("user1");
    	credentials.setPassword("password1");
    	System.out.println("Tesing AuthUser");
   
    }*/
    @Test
	public void testGetXmlFiles() throws Exception {

		System.out.println("Testing getXmlFile");
		/*mockMvc.perform(get("/searchFile")
				.param("emsId", "emsId-100")		
				.param("date", "01-10-2016")		
				.param("flowId", "28738_64633")		
				.param("fileName", "Request_Him_DSLM_54868344_92815837_05_Aug_16_18_38_26_504_1.xml")		
				)

		.andExpect(status().isOk())
		.andExpect(content().contentType(MediaType.APPLICATION_XML))
		.andDo(MockMvcResultHandlers.print())		;
*/
	}
    
    /* @Test
	public void testFirstSearchCall() throws Exception {

		System.out.println("Testing First use case: firstSearchCall");
		mockMvc.perform(get("/search")
				.param("emsId", "emsId-100")		
				.param("date", "01-10-2016")		
				)
		.andExpect(status().isOk())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
		.andDo(MockMvcResultHandlers.print())
		;

	}
    
   
    @Test
   	public void testFirstSearchCallErr600() throws Exception {

   		System.out.println("Testing First use case: firstSearchCall for error code 600");
   		mockMvc.perform(get("/search")
   				.param("emsId", "emsId-100")		
   				.param("date", "01-10-2016")
   				.param("error", "600")
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;

   	}
     
    @Test
   	public void testFirstSearchCallErr1100() throws Exception {

   		System.out.println("Testing First use case: firstSearchCall for error code 1100");
   		mockMvc.perform(get("/search")
   				.param("emsId", "emsId-100")		
   				.param("date", "01-10-2016")
   				.param("error", "1100")
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;

   	}
       
    
    @Test
   	public void testSecondSearchCall() throws Exception {

   		System.out.println("Testing First use case: secondSearchCall");
   		mockMvc.perform(get("/search")
   				.param("emsId", "emsId-100")		
				.param("date", "01-10-2016")		
				.param("flowId", "28738_64633")
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;
   	}
   	
    @Test
   	public void testSecondUseCaseFailureResponseOnly() throws Exception {

   		System.out.println("Testing second use case for all failure response only");
   		mockMvc.perform(get("/search")
   				.param("errorCode", "true")		
				.param("date", "01-10-2016")		
				.param("flowId", "28738")
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;
   	}
   	
   	
    @Test
   	public void testSecondUseCaseAllResponses() throws Exception {

   		System.out.println("Testing second use case for all response");
   		mockMvc.perform(get("/search")
   				.param("errorCode", "false")		
				.param("date", "01-10-2016")		
				.param("flowId", "28738")
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;
   	}
   
    
	
    @Test
   	public void thirdUseCaseErr600() throws Exception {

   		System.out.println("Testing second use case for all response");
   		mockMvc.perform(get("/search")
   				.param("errorCode", "600")		
				.param("date", "01-10-2016")		
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;
   	}
    
    
    @Test
   	public void thirdUseCaseErr1100() throws Exception {

   		System.out.println("Testing second use case for all response");
   		mockMvc.perform(get("/search")
   				.param("errorCode", "1100")		
				.param("date", "01-10-2016")		
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;
   	}
    
       */
    
 /*   @Test
   	public void thirdUseCaseEmsWithErr1100() throws Exception {

    	System.out.println("Testing Third use case:with Error Code for EMS ID: firstSearchCall");

   		mockMvc.perform(get("/search")
   				.param("error", "1100")		
				.param("date", "01-10-2016")
				.param("emsId", "emsId-100")
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;
   	}
 
    
    @Test
   	public void thirdUseCaseEmsWithErr600() throws Exception {

    	System.out.println("Testing Third use case:with Error Code for EMS ID: firstSearchCall");

   		mockMvc.perform(get("/search")
   				.param("errorCode", "600")		
				.param("date", "01-10-2016")
				.param("emsId", "emsId-100")
   				)
   		.andExpect(status().isOk())
   		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
   		.andDo(MockMvcResultHandlers.print())
   		;
   	}*/
}
