/**
 *  Search Service
 */

(function(){
    'use strict';
    
    angular
            .module('MyApp')
            .factory('searchService', searchService);
    
    searchService.$inject = [ "$http"];
    
    function searchService($http){
        function search(date, emsId){
            //return $http.get('assets/data/flowids.json');
            return $http.get('search?date='+date+'&emsId='+emsId);
        }
        
        function selectAnyId(href){
        	return $http.get(href);
        }
        
        function searchByFlowId(date, flowId, failureResponse){
            return $http.get('search?date='+date+'&flowId='+flowId+'&errorCode='+failureResponse);
        }
        
        function searchByErrorCode(date, errorCode){
        	return $http.get('search?date='+date+'&errorCode='+errorCode);
        }
        
        
        function sendMail(mailds,data){
        	return $http.post('sendEmail?emailResult='+mailds, data);
        }
        
        function zipDownload(data){
        	return $http.post('zip', data, { responseType: 'arraybuffer' });
        }
        
        function bulkSearch(data){
        	return $http.post('search',data);
        }
        
        return {
            search:search,
            searchByFlowId:searchByFlowId,
            searchByErrorCode:searchByErrorCode,
            selectAnyId:selectAnyId,
            bulkSearch:bulkSearch,
            sendMail:sendMail,
            zipDownload:zipDownload
        };
    }
    
})();