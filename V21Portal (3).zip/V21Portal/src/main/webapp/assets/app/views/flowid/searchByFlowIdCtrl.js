/**
 * Search Controller
 */

(function () {
    'use strict';

    angular
            .module('MyApp')
            .controller('searchByFlowIdCtrl', searchCtrl);

    searchCtrl.$inject = ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window'];
    
    function searchCtrl($scope, searchService, $state, $filter, toastr, $window) {

        /******* Date Picker  *******/
        $scope.today = function () {
            $scope.date = new Date();
        };
        $scope.today();

        $scope.clear = function () {
            $scope.date = null;
        };

        $scope.opened = false;
        var date=new Date();
        date.setMonth(date.getMonth() - 1);
        
        $scope.dateOptions = {
            //dateDisabled: disabled,
            formatYear: 'yy',
            maxDate: new Date(),
            minDate: date,
            startingDay: 1
        };

        // Disable weekend selection
        function disabled(data) {
            var date = data.date,
                    mode = data.mode;
            return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
        }

        $scope.formats = ['dd-MM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
        $scope.format = $scope.formats[0];
        $scope.failureResponse = false;
        $scope.loading = false;

        $scope.search = function (date, flowId, failureResponse) {
            $scope.loading = true;
            $scope.flowId = flowId;
            $scope.date = date;
            $scope.failureResponse = failureResponse;
            date = $filter('date')($scope.date, $scope.format);
            $scope.xmlIds = [];
            searchService.searchByFlowId(date, flowId, failureResponse).then(function (response) {
                
                $scope.loading = false;
                $scope.selection = 'xml';
                $scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.data.message);
                console.log(response);
            });
        };

        

        $scope.showPage = function (value) {
            $scope.selection = value;
        };

        //$scope.xmlIds = searchService.getXmlIds();

        $scope.selectXmlId = function (href) {
            $window.open(href, "XML Document", "width=600,scrollbars=yes,resizable=yes");
            searchService.selectAnyId(href).then(function (response) {
                //var myWindow = $window.open("", "XML Document", "width=600,height=400");
                //myWindow.document.write(response.data);
                //$scope.loading = false;
                //$scope.selection = 'xml';
                //$scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                //$scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });

        };


    }
    
})();