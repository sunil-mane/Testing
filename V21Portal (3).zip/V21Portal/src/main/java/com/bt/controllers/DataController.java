package com.bt.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bt.exceptions.InvalidRequestException;
import com.bt.jsonBean.AuthResponse;
import com.bt.jsonBean.BulkSearch;
import com.bt.jsonBean.Credentials;
import com.bt.jsonBean.EmailService;
import com.bt.jsonBean.ErrorResponce;
import com.bt.jsonBean.SearchResponse;
import com.bt.services.V21Properties;
import com.bt.services.V21SearchHelper;
import com.bt.services.V21SearchServices;
import com.bt.util.V21FileUtility;

@RestController
public class DataController {

	@Autowired
	public V21Properties v21Properties;
	@Autowired
	private V21SearchServices searchService; 
	@Autowired
	private V21SearchHelper searchHelper; 
	@Autowired
	private AuthResponse response;
	@Autowired
	private ErrorResponce errorResponce;
	@Autowired
	private V21FileUtility v21FileUtility;

	@RequestMapping(value = "/search", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public SearchResponse  getListOfFlows(
			@RequestParam(value="emsId",required=false) String emsId,
			@RequestParam(value="date",required=false) String date,
			@RequestParam(value="flowId",required=false)String flowId,
			@RequestParam(value="errorCode",required=false)String errorCode,
			@RequestParam(value="emailResult",required=false)String emailResult,
			@RequestParam(value="jsonObject",required=false)String jsonObject,
			@RequestParam(value="error",required=false)String error
			) {
		System.out.println("Initializing search helper");
		searchHelper.initSearchHelper();
		if (date!=null && !"".equals(date)) {
			System.out.println("Checking for date dir: "+date);
			date=searchHelper.dateForOperation(date);
			searchHelper.checkDateDir(date);
		}


		if (emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && (flowId==null || "".equals(flowId)) && (null!=error && !"".equals(error))) {

			System.out.println("Third use case:with Error Code for EMS ID: firstSearchCall");

			//throw new InvalidRequestException("EmsId not Found", "EMS Id: 101", null);
			return searchService.firstSearchCall(emsId, date, error);
		}

		else if (emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && (flowId!=null || !"".equals(flowId)) && (null!=error && !"".equals(error))) {

			System.out.println("Third use case:with Error Code for Flow ID: "+flowId);

			return searchService.secondUseCase(searchHelper.dateForOperation(date), flowId, error);
		}

		else if (emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && (flowId==null || "".equals(flowId))) {

			System.out.println("First use case: firstSearchCall");

			//throw new InvalidRequestException("EmsId not Found", "EMS Id: 101", null);
			return searchService.firstSearchCall(emsId, date);
		}else if (!(flowId==null || "".equals(flowId)) && date!=null && !"".equals(date) && errorCode!=null && !"".equals(errorCode)) {
			System.out.println("Second Use Case");
			boolean err=false;
			if (errorCode.equals("true")) {
				err = true;
			}  

			System.out.println("Started : "+System.currentTimeMillis());
			return searchService.secondUseCase(date	, flowId,err);
		}else if(emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && (flowId!=null || !"".equals(flowId))) {
			System.out.println("First use case: secondSearchCall :"+emsId);
			return searchService.secondSearchCall(emsId, date, flowId);
		}else if (!(flowId==null || "".equals(flowId)) && date!=null && !"".equals(date)){
			String flowIds[]=flowId.split(",");

			if (flowIds.length>1) {
				System.out.println("Fourth Use Case");
				return searchService.fourthUseCase(searchHelper.dateForOperation(date), flowIds,false);
			}else {
				System.out.println("Second Use Case");
				return searchService.secondUseCase(searchHelper.dateForOperation(date), flowId,false);
			}


		}else if (date!=null && !"".equals(date) && (errorCode!=null || !"".equals(errorCode))) {
			List<String> errors=new ArrayList<String>();
			for(String error1:errorCode.split(",")){
				errors.add(error1);
			}
			System.out.println("Third Use Case");
			return searchService.thirdUseCase(searchHelper.dateForOperation(date), errors);
		}
		/*else if (null!=emailResult && ""!=emailResult && null!=jsonObject ) {

			System.out.println("Send Email....");
			return searchService.sendEmail(emailResult, jsonObject);
		}*/

		else {
			return null;
		}



	}

	@RequestMapping(value = "/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public SearchResponse  getBulkSearchResult(

			@RequestBody BulkSearch bulkSearch
			) {
		searchHelper.initSearchHelper();
		System.out.println("Bulk search initiated"+ System.currentTimeMillis());
		String date=bulkSearch.getDate();
		if (date!=null && !"".equals(date)) {
			System.out.println("Checking for date dir: "+date);
			date=searchHelper.dateForOperation(date);
			searchHelper.checkDateDir(date);
		}
		if (bulkSearch!=null) {
			String flowIds[]=bulkSearch.getFlowId().split(",");

			if (flowIds.length>0) {
				System.out.println("Fourth Use Case");
				return searchService.fourthUseCase(date, flowIds,false);
			}
		}
		return null;

	}

	@RequestMapping(value = "/searchFile", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public String  getXmlFiles(
			@RequestParam("emsId") String emsId,
			@RequestParam("date") String date,
			@RequestParam(value="flowId",required=false)String flowId,
			@RequestParam(value="fileName",required=false)String fileName
			) {
		searchHelper.initSearchHelper();
		return searchService.getXml(emsId, date, flowId, fileName);
	}

	@RequestMapping(value = "/zip", method = RequestMethod.POST, produces="application/zip")
	public byte[] zipFiles(@RequestBody SearchResponse searchResponse) {
		searchHelper.initSearchHelper();
		return v21FileUtility.zipFiles(searchResponse);

	}


	@RequestMapping(value = "/sendEmail",method = RequestMethod.POST, produces="application/json" ,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ErrorResponce sendEmail(@RequestBody EmailService emailService,
			@RequestParam("emailResult") String emailResult){
		searchHelper.initSearchHelper();

		if (null!=emailResult && ""!=emailResult && null!=emailService ) {	
			System.out.println("Received flowid "+emailService.getFlowId());
			String flowIds[]=emailService.getFlowId().split(",");		
							
			System.out.println("Send Email....");
			errorResponce=searchService.sendEmail(emailResult, emailService.getResult(), flowIds);
			if(("Success")!=errorResponce.getMessage()){
				throw new InvalidRequestException("Error while sending Email to "+emailResult);
			}
			
			return errorResponce;			
		}
		else{			
			errorResponce.setMessage("Failure");
			throw new InvalidRequestException("Error while sending Email to "+emailResult);
		}

	}

/*
	@RequestMapping(value = "/sendEmail",method = RequestMethod.POST, produces="application/json")
	public ErrorResponce sendEmail(@RequestBody SearchResponse searchResponse, @RequestBody BulkSearch bulkSearch,
			@RequestParam("emailResult") String emailResult){
		searchHelper.initSearchHelper();

		if (null!=emailResult && ""!=emailResult && null!=searchResponse ) {

			if (bulkSearch!=null) {
				String flowIds[]=bulkSearch.getFlowId().split(",");		
			
				System.out.println("Send Email....");
				errorResponce=searchService.sendEmail(emailResult, searchResponse, flowIds);
				if(("Success")!=errorResponce.getMessage()){
					throw new InvalidRequestException("Error while sending Email to "+emailResult);
				}
			}
			return errorResponce;			
		}
		else{			
			errorResponce.setMessage("Failure");
			throw new InvalidRequestException("Error while sending Email to "+emailResult);
		}

	}*/


	@RequestMapping(value = "/authUser",method = RequestMethod.POST)
	public AuthResponse authUser(@RequestBody Credentials credentials)
	{
		searchHelper.initSearchHelper();
		System.out.println("Initializing Search helper service");
		searchHelper.initSearchHelper();
		//v21Properties.setCredentialsStr(credentialsStr);
		System.out.println("Authenticating user: ");

		if (null!=credentials ) {

			if(searchService.validateUser(credentials,v21Properties.getAllUsers())){              

				response.setAuthToken(credentials);             
				System.out.println("User Authenticated");

			}else {
				response.setAuthToken(null);      
				System.out.println("Invalid user");
				throw new InvalidRequestException("Invalid Credentials");
			}
		}
		return response;


	}


}
