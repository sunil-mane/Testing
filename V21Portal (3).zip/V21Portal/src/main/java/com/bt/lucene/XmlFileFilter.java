package com.bt.lucene;


import java.io.File;
import java.io.FileFilter;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
@Service
@Scope("prototype")
public class XmlFileFilter implements FileFilter {

   public boolean accept(File pathname) {
      return pathname.getName().toLowerCase().endsWith(".xml");
   }
}