package com.bt.lucene;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bt.jsonBean.SearchList;
import com.bt.services.V21Properties;


@Service
@Scope("prototype")
public class LuceneTester {

	@Autowired
	private V21Properties v21Properties;

	@Autowired
	private Indexer indexer;
	@Autowired
	private Searcher searcher;
	private TopDocs hits;
	public static List<String> fileList_first=new ArrayList<String>();
	public List<SearchList> searchListData=new ArrayList<SearchList>();


	public void createIndex(String dataDir1) throws IOException{

		indexer.initIndexer(v21Properties.getIndexDir());
		//int numIndexed;
		//long startTime = System.currentTimeMillis();	
		//System.out.println("here path "+dataDir1);
		//numIndexed = 
				indexer.createIndex(dataDir1, new XmlFileFilter());
		//long endTime = System.currentTimeMillis();
		indexer.close();
		/*System.out.println(numIndexed+" File indexed, time taken: "
				+(endTime-startTime)+" ms");*/		
	}

	public List<String> search(String searchQuery) throws IOException, ParseException{
		searcher.initSearcher(v21Properties.getIndexDir());
		//long startTime = System.currentTimeMillis();
		hits = searcher.search(searchQuery);
		//long endTime = System.currentTimeMillis();
		String filePath=null;
		List<String> fileListNew=new ArrayList<String>();
		//System.out.println("FileList before clear"+fileList_first.size());
		fileList_first.clear();
	/*	System.out.println("FileList after clear"+fileList_first.size());
		System.out.println(hits.totalHits +" documents found. Time :" + (endTime - startTime));*/
		for(ScoreDoc scoreDoc : hits.scoreDocs) {
			Document doc = searcher.getDocument(scoreDoc);
			filePath=doc.get(LuceneConstants.FILE_PATH);
		/*	System.out.println("File: "+ filePath);*/
			fileList_first.add(filePath);
			fileListNew.add(filePath);
			/*System.out.println("fileList_first her "+fileList_first.size());
			System.out.println("fileListNew her "+fileListNew.size());
*/

		}
		searcher.close();
		return fileListNew;

	}  

}
