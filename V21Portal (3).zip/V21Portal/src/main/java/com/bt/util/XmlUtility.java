package com.bt.util;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;


/**
 * Hello world!
 *
 */
public class XmlUtility 
{


	public static String getEMSID(File xmlFile, boolean forEmail) throws Exception{
		String emsId=null;

	//	System.out.println("inputFile name while gettingMEid "+xmlFile);



		DocumentBuilderFactory dbFactory 
		= DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;

		dBuilder = dbFactory.newDocumentBuilder();

		Document doc = dBuilder.parse(xmlFile);
		doc.getDocumentElement().normalize();

		XPath xPath =  XPathFactory.newInstance().newXPath();

		String expressionForECI_matrix = "//deleteMatrixFlowDomainRequest/mfdRef/name/rdn[type='MD']/value/text()";

		String expressionForECI_floating = "//deleteFloatingTerminationPointRequest/tpDataListToModify/tpData[1]/tpRef/rdn[1]/value/text()";  

		String expressionForECI_another = "//rdn[1]/value/text()";

		// String secondExpressionForHWE = "//transactionResponse/mtosiObjectsActionResponse/mtosiObjectsResponse/provisionMtosiObjectResponse[1]/name/mdNm/text()";

		String expressionForHWE = "//transaction/mtosiObjectsAction/mtosiObjects/TP[1]/ctp/name/mdNm/text()";

		NodeList nodeListECI = (NodeList) xPath.compile(expressionForECI_matrix).evaluate(doc, XPathConstants.NODESET);
		NodeList nodeListECI2 = (NodeList) xPath.compile(expressionForECI_floating).evaluate(doc, XPathConstants.NODESET);
		NodeList nodeListECI3 = (NodeList) xPath.compile(expressionForECI_another).evaluate(doc, XPathConstants.NODESET);


		//System.out.println("nodeListECI.getLength() : "+nodeListECI.getLength());
		//System.out.println("nodeListECI2.getLength() : "+nodeListECI2.getLength());

		if(nodeListECI.getLength()>0){

			for (int i = 0; i < nodeListECI.getLength(); i++) {

				Node nNode = nodeListECI.item(i);

				//System.out.println("MD value here is : "  + nNode.getNodeValue());
				emsId=nNode.getNodeValue();
				String tmpString="";
				if(emsId.contains("/") && !forEmail){

					String[] strArray=emsId.split("/");

					for(int j=0; j<strArray.length; j++){
						tmpString=tmpString+strArray[j];
					}
					emsId=tmpString;
					System.out.println("emsID afer replacing / :"+emsId);
				}
				System.out.println("emsID for ECI: "+emsId);           
			}	  
		}
		else if(nodeListECI2.getLength()>0) {
			for (int i = 0; i < nodeListECI2.getLength(); i++) {

				Node nNode = nodeListECI2.item(i);

				//System.out.println("MD value here is : "  + nNode.getNodeValue());
				emsId=nNode.getNodeValue();
				String tmpString="";
				if(emsId.contains("/") && !forEmail){

					String[] strArray=emsId.split("/");

					for(int j=0; j<strArray.length; j++){
						tmpString=tmpString+strArray[j];
					}
					emsId=tmpString;
					System.out.println("emsID afer replacing / :"+emsId);
				}
				System.out.println("emsID for ECI: "+emsId);           
			}	  
		}
		else{


			for (int i = 0; i < nodeListECI3.getLength(); i++) {

				Node nNode = nodeListECI3.item(i);

				//System.out.println("MD value here is : "  + nNode.getNodeValue());
				emsId=nNode.getNodeValue();
				String tmpString="";
				if(emsId.contains("/") && !forEmail){

					String[] strArray=emsId.split("/");

					for(int j=0; j<strArray.length; j++){
						tmpString=tmpString+strArray[j];
					}
					emsId=tmpString;
					System.out.println("emsID afer replacing / :"+emsId);
				}
				System.out.println("emsID for ECI: "+emsId);           
			}	  


		}


		if(emsId==null){

			NodeList nodeListHWe = (NodeList) xPath.compile(expressionForHWE).evaluate(doc, XPathConstants.NODESET);

			for (int hweNode = 0; hweNode < nodeListHWe.getLength(); hweNode++) {

				Node nNodeHwe = nodeListHWe.item(hweNode);

				//System.out.println("MD value here is : "  + nNodeHwe.getNodeValue());
				emsId=nNodeHwe.getNodeValue();  
			}
			System.out.println("emsId for HWE: "+emsId);
		}


		if(null!=emsId){
			return emsId;	        	
		}
		return emsId;
	}



	public static String getNEID(File xmlFile) throws Exception{
		String NEId=null;

		DocumentBuilderFactory dbFactory 
		= DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;

		dBuilder = dbFactory.newDocumentBuilder();


		Document doc = dBuilder.parse(xmlFile);
		doc.getDocumentElement().normalize();

		XPath xPath =  XPathFactory.newInstance().newXPath();

		String expressionForECI = "//deleteMatrixFlowDomainRequest/mfdRef/name/rdn[type='ME']/value/text()"; 
		String expressionForECI_floating = "//deleteFloatingTerminationPointRequest/tpDataListToModify/tpData[1]/tpRef/rdn[2]/value/text()";
		String expressionForECI_another = "//rdn[2]/value/text()";

		//String secondExpressionForHWE = "//transactionResponse/mtosiObjectsActionResponse/mtosiObjectsResponse/provisionMtosiObjectResponse[1]/name/meNm/text()";
		String expressionForHWE = "//transaction/mtosiObjectsAction/mtosiObjects/TP[1]/ctp/name/meNm/text()";

		NodeList nodeListForECI = (NodeList) xPath.compile(expressionForECI).evaluate(doc, XPathConstants.NODESET);
		NodeList nodeListForECI2 = (NodeList) xPath.compile(expressionForECI_floating).evaluate(doc, XPathConstants.NODESET);
		NodeList nodeListForECI3 = (NodeList) xPath.compile(expressionForECI_another).evaluate(doc, XPathConstants.NODESET);

		if(nodeListForECI.getLength()>0){

			for (int i = 0; i < nodeListForECI.getLength(); i++) {

				Node nNode = nodeListForECI.item(i);

			//	System.out.println("ME value here is : "  + nNode.getNodeValue());
				NEId=nNode.getNodeValue();          

				System.out.println("nodeListForECI: NEId for ECI is nodeListForECI:"+NEId);

			}
		}
		else if(nodeListForECI2.getLength()>0){

			for (int i = 0; i < nodeListForECI2.getLength(); i++) {

				Node nNode = nodeListForECI2.item(i);

				//System.out.println("ME value here is : "  + nNode.getNodeValue());
				NEId=nNode.getNodeValue();          

				System.out.println("nodeListForECI2: NEId for ECI is :"+NEId);

			}	        	
		}
		else {

			for (int i = 0; i < nodeListForECI3.getLength(); i++) {

				Node nNode = nodeListForECI3.item(i);

				//System.out.println("ME value here is : "  + nNode.getNodeValue());
				NEId=nNode.getNodeValue();          

				System.out.println("nodeListForECI3: NEId for ECI is :"+NEId);

			}	   

		}

		if(null==NEId){
			NodeList nodeListForHwe = (NodeList) xPath.compile(expressionForHWE).evaluate(doc, XPathConstants.NODESET);

			for (int i = 0; i < nodeListForHwe.getLength(); i++) {

				Node nNode = nodeListForHwe.item(i);

				//System.out.println("ME value for HWE is : "  + nNode.getNodeValue());
				NEId=nNode.getNodeValue();          

				System.out.println("NEId for HWE is :"+NEId);

			}
		}
		if(null!=NEId){
			return NEId;
		}


		return NEId;
	}

}
