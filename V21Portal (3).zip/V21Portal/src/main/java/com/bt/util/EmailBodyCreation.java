package com.bt.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class EmailBodyCreation 
{

	public StringBuilder stringBuilder = new StringBuilder();		

	public void clearFileContent() throws FileNotFoundException{
		stringBuilder=new StringBuilder();

	}


	public StringBuilder createEmailBody(List<File> fileList, String zipFilename) throws Exception{


		String errorReason=getErrorReason(fileList, zipFilename);;

		stringBuilder.append(errorReason);
		stringBuilder.append('\n');
		stringBuilder.append("------------------------------------------------------------------------------");
		stringBuilder.append('\n');	
		return stringBuilder;


	}

	public String  getErrorReason(List<File> filePathList, String zipFilename) throws Exception{

		String emsID="";
		String NEId="";

		List<String> errorReasons=new ArrayList<String>();

		String errorReason="";

		StringBuilder emailBodyText=new StringBuilder();
		
		//Extract missing flowId's
		
	
		
		

		LinkedList<File> ll =   new LinkedList<File>(filePathList);

		Collections.sort(ll, new FileLastModifiedComparator());

		Iterator<File> it = ll.iterator();

		for(int i=0;i<ll.size();i++){

			//System.out.println("FileName for Error Reason extraction:"+ll.get(i).getName()+" "+formatDate(ll.get(i).lastModified()));

			File xmlFile=ll.get(i);	

			if(null==NEId || ""==NEId || null==emsID || ""==emsID){		        
				emsID=XmlUtility.getEMSID(xmlFile, true);
				NEId=XmlUtility.getNEID(xmlFile);
			}

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder;

			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			XPath xPath =  XPathFactory.newInstance().newXPath();    	

			String expressionForErrorReasonECI = "//deleteMatrixFlowDomainException/invalidInput/reason/text()";

			String expressionForErrorReasonHwe = "//mtosiObjectsActionResponse/mtosiObjectsResponse/provisionMtosiObjectResponse[1]/processingFailureException/reason/text()";

			NodeList nodeListECI = (NodeList) xPath.compile(expressionForErrorReasonECI).evaluate(doc, XPathConstants.NODESET);

			NodeList nodeListHWE = (NodeList) xPath.compile(expressionForErrorReasonHwe).evaluate(doc, XPathConstants.NODESET);

			if(nodeListECI.getLength()>0){
				for (int nodeIterator = 0; nodeIterator < nodeListECI.getLength(); nodeIterator++) {

					Node nNode = nodeListECI.item(nodeIterator);

					System.out.println("Error reason is : "  + nNode.getNodeValue());
					errorReason=nNode.getNodeValue();
					errorReasons.add(errorReason);

				}	
			}

			else{
				for (int nodeIterator = 0; nodeIterator < nodeListHWE.getLength(); nodeIterator++) {

					Node nNode = nodeListHWE.item(nodeIterator);

					System.out.println("Error reason is : "  + nNode.getNodeValue());
					errorReason=nNode.getNodeValue();
					errorReasons.add(errorReason);

				}	
			}

			if(null!= errorReason && ""!=errorReason && null!=NEId && ""!=NEId && null!=emsID && ""!=emsID){
				System.out.println("Breaking outer loop");	        	
				break;
			}
		}


		if(errorReasons.size()>1){
			emailBodyText.append(emsID);
			emailBodyText.append(" --> ");
			emailBodyText.append(NEId);
			emailBodyText.append(" --> ");
			emailBodyText.append(zipFilename);
			emailBodyText.append(" ======>> ");

			for(String reason:errorReasons){
				emailBodyText.append("Field ns2:reason: "+reason);
				emailBodyText.append('\n');
			}

		}
		else{
			emailBodyText.append(emsID);
			emailBodyText.append(" --> ");
			emailBodyText.append(NEId);
			emailBodyText.append(" --> ");
			emailBodyText.append(zipFilename);
			emailBodyText.append(" ======>> Field ns2:reason: ");
			emailBodyText.append(errorReason);
		}
		System.out.println("emailBodyText "+emailBodyText);
		return emailBodyText.toString();


	}


	static String formatDate(long dateInMillis) {
		Date date = new Date(dateInMillis);
		return DateFormat.getDateInstance().format(date);
	}

}


