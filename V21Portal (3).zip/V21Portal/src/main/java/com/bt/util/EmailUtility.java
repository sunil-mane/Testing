package com.bt.util;

import java.io.*;
import java.util.*;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;

import com.bt.exceptions.InvalidRequestException;
import com.bt.services.V21Properties;

@org.springframework.stereotype.Service
//@Scope("prototype")
public class EmailUtility {

	private int count=0;
	@Autowired
	private V21Properties v21Properties;

	public synchronized void sendMail(String subject, String body, HashMap<String, byte[]> filesList, String EmailAdd )throws Exception {	
		try{
			String toAdd = "";
			String ccAdd = "";

			String mailServer = v21Properties.getMailServer();
			String from = v21Properties.getFrom();
			String toAddresses = EmailAdd;
			String ccAddresses = v21Properties.getCcAddresses();

			Properties properties = System.getProperties();
			properties.setProperty("mail.smtp.host", mailServer);

			Session session = Session.getInstance(properties);
			//                  Session session = Session.getDefaultInstance(properties);
			MimeMessage message = new MimeMessage(session);
			StringTokenizer toList = new StringTokenizer(toAddresses, ";");
			StringTokenizer ccList = new StringTokenizer(ccAddresses, ";");
			int i = 0;
			while (toList.hasMoreTokens()) {
				i++;

				toAdd = toList.nextToken();
				InternetAddress address = new InternetAddress(toAdd);
				message.addRecipient(Message.RecipientType.TO, address);
			}

			i = 0;
			while (ccList.hasMoreTokens()) {
				i++;
				ccAdd = ccList.nextToken();
				InternetAddress address = new InternetAddress(ccAdd);
				message.addRecipient(Message.RecipientType.CC, address);
			}

			message.setFrom(new InternetAddress(from));
			message.setSubject(subject);
			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			mimeBodyPart.setText(body);
			mimeBodyPart.setContent(body, "text/plain");
			Multipart multiPart = new MimeMultipart();
			multiPart.addBodyPart(mimeBodyPart);

			Set<String> zipFilesList=filesList.keySet();

			Iterator<String> fileNames=zipFilesList.iterator();
			while(fileNames.hasNext()){
				String fileName=fileNames.next();
				System.out.println("iterating over :"+fileName);
				DataSource dataSource = new ByteArrayDataSource(filesList.get(fileName), "application/zip");
				MimeBodyPart zipBodyPart = new MimeBodyPart();
				zipBodyPart.setDataHandler(new DataHandler(dataSource));
				zipBodyPart.setFileName(fileName+".zip");            
				multiPart.addBodyPart(zipBodyPart);
			}


			message.setContent(multiPart);
			message.setSentDate(new Date());

			Transport.send(message);


			System.out.println("Sent message successfully....");
			count=0;
		}catch (MessagingException mex) {
			mex.printStackTrace();

			boolean sent = false;
			System.out.println("Resending email");

			if(count<15){
				count++;
				Thread.sleep(3000);
				System.out.println("Email Re-tried count: "+count);
				sendMail(subject, body, filesList, EmailAdd );
				sent=true;
				

			}

			count=0;
			if (!sent) {
				throw new InvalidRequestException("Error while sending Email to "+EmailAdd);
			}
		}
	}
	public String getHtmlMessageBody()throws Exception {
		File file = new File(v21Properties.getPathToReportHtml());


		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line= null;
		while ((line = reader.readLine()) != null) {
			stringBuilder.append(line);
			stringBuilder.append('\n');
		}
		System.out.println(stringBuilder.toString());


		return stringBuilder.toString();
	}

	public String getMailSubject()throws Exception {
		File file = new File("SUBJECT.dat");
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line= null;
		while ((line = reader.readLine()) != null) {
			stringBuilder.append(line);
		}
		//System.out.println(stringBuilder.toString());
		//return stringBuilder.toString();
		String sub = stringBuilder.toString();
		sub= "["+ sub+"]:New HE - EC Diagnostics Report";
		return sub;
	}



	public static void main(String a[])throws Exception {
		EmailUtility gm = new EmailUtility();
		String body = gm.getHtmlMessageBody();
		String subject = "V21 request and response xmls";
		//List fileList = gm.getFileList();
		// gm.sendMail(subject, body,fileList, "");
	}
}



