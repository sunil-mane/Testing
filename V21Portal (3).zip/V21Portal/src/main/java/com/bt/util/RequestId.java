package com.bt.util;

public final class RequestId
{
  private static int current = (int)(System.currentTimeMillis() / 1000L);

  public static synchronized String getId()
  {
    return Integer.toString(current++);
  }
}