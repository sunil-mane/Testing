package com.bt.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;

import com.bt.jsonBean.EmailBody;

public class ZipFileUtility {
	
	
       
         
    public static EmailBody  zipFile(List<File> filesList, List<String> flowIds) throws Exception { 
   	 
   	 filesList.size();
   	 HashMap<String, byte[]> map=new HashMap<String, byte[]>();
   	 EmailBody emailBody=new EmailBody();   	 
   	List<String> presentflowIds=new ArrayList<String>();
			
   	 System.out.println("Inside ZipFile method ....");
   	 EmailBodyCreation emailBodyCreation=new EmailBodyCreation();
   	 emailBodyCreation.clearFileContent();
   	 
   	 for(File directoryToZip:filesList){
	
	 		List<File> fileList = new ArrayList<File>();
	 		System.out.println("---Getting references to all files in: " + directoryToZip.getCanonicalPath());
	 		//System.out.println("Getting all files from Directory "+directoryToZip);
	 		getAllFiles(directoryToZip, fileList);
	 		
	 		if(null!=flowIds){
		 		for(String flowID:flowIds){
		 			
		 			String fileFlowId=getFlowID(directoryToZip.getName());
		 			if(fileFlowId.equals(flowID)){
		 				presentflowIds.add(flowID);
		 				flowIds.remove(flowID);
		 			}
		 		}
	 		}
	 		//System.out.println("---Getting Zip file Name");	 		
	 		String zipFileName=getZipFileName(directoryToZip.getName(), fileList);
	 		
	 		//System.out.println("ZipfileName here is "+zipFileName);
	 		
	 		
	 		StringBuilder emailBodyText=emailBodyCreation.createEmailBody(fileList, zipFileName);	 		
	 		
	 		
	 		
	 		byte[] byteArray=writeZipFile(directoryToZip, fileList, zipFileName);

	 		map.put(zipFileName, byteArray);
	 		
	 		emailBody.setBodyText(emailBodyText);
	 		emailBody.setMap(map);
	 		
	 		File currentFile = new File(".");
	 		currentFile.listFiles();
   	 }
   	
   	 if(null!=flowIds && flowIds.size()>0){
   		 for(String flowId:flowIds){
	   		StringBuilder stringBuilder = emailBody.getBodyText();
	   		stringBuilder.append("V21 either did not receive a request with the mentioned flow id :"+flowId);
			stringBuilder.append('\n');
			stringBuilder.append("------------------------------------------------------------------------------");
			stringBuilder.append('\n');
			emailBody.setBodyText(stringBuilder);
   		 }
   		 
   		 
   	 }
   	 
   	 return emailBody;
	   } 

    
    
    private static String getZipFileName(String filepath, List<File> fileList) throws Exception {
    	
   	 String zipFileName="";
   	
   	 String emsId="";
   	 String NEid="";
   	 
   	 for(int i=0;i<fileList.size();i++){    	
   		// System.out.println("inside get zip file name");
	    	  emsId=XmlUtility.getEMSID(fileList.get(i), false);
	    	  NEid=XmlUtility.getNEID(fileList.get(i));
	    	  if(null!=emsId && null!=NEid && ""!=emsId && ""!=NEid){
	    		  break;
	    	  }
   	 }
   	 
   	 String flowId=getFlowID(filepath);
   	 zipFileName=emsId+"_"+NEid+"_"+flowId;
   	 System.out.println(zipFileName);
   	 return zipFileName;
		
	}
	public static void getAllFiles(File dir, List<File> fileList) {
		try {
			File[] files = dir.listFiles();
			for (File file : files) {
				fileList.add(file);
				if (file.isDirectory()) {
					//System.out.println("directory:" + file.getCanonicalPath());
					getAllFiles(file, fileList);
				} else {
					//System.out.println(" file:" + file.getCanonicalPath());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static byte[] writeZipFile(File directoryToZip, List<File> fileList, String zipFileName) {

		try {			
			
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(byteArrayOutputStream);
	        ZipOutputStream zos = new ZipOutputStream(bufferedOutputStream);
			for (File file : fileList) {
				if (!file.isDirectory()) { // we only zip files, not directories
					addToZip(directoryToZip, file, zos);
				}
			}
			
			
			if (zos != null) {
				zos.finish();
				zos.flush();
	            IOUtils.closeQuietly(zos);
	        }
	        IOUtils.closeQuietly(bufferedOutputStream);
	        IOUtils.closeQuietly(byteArrayOutputStream);
	        return byteArrayOutputStream.toByteArray();	
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void addToZip(File directoryToZip, File file, ZipOutputStream zos) throws FileNotFoundException,	IOException {

		FileInputStream fis = new FileInputStream(file);

		
		// we want the zipEntry's path to be a relative path that is relative
		// to the directory being zipped, so chop off the rest of the path
		String zipFilePath = file.getCanonicalPath().substring(directoryToZip.getCanonicalPath().length() + 1,
				file.getCanonicalPath().length());
		//System.out.println("Writing '" + zipFilePath + "' to zip file");
		ZipEntry zipEntry = new ZipEntry(zipFilePath);
		zos.putNextEntry(zipEntry);

		byte[] bytes = new byte[1024];
		int length;
		while ((length = fis.read(bytes)) >= 0) {
			zos.write(bytes, 0, length);
		}

		zos.closeEntry();
		fis.close();
	}


	public static String getFlowID(String filePath){
		
	   String[] filenames=filePath.split("/");
	   String flowId="";
			   
  		System.out.println("filenames--len"+filenames.length);
		  for(int i=filenames.length-1;i>=0;i--){
			  
			  flowId=filenames[i];
			   System.out.println("flowId--len"+flowId);
			   return flowId;
  
		  }
		  return flowId;		  
	}
	
	
}
	



