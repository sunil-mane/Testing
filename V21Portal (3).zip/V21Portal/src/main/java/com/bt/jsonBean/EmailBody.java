package com.bt.jsonBean;

import java.util.HashMap;

public class EmailBody {

	public HashMap<String, byte[]> map=new HashMap<String, byte[]>();
	
	public StringBuilder bodyText=new StringBuilder();
	
	public StringBuilder getBodyText() {
		return bodyText;
	}

	public void setBodyText(StringBuilder bodyText) {
		this.bodyText = bodyText;
	}

	public HashMap<String, byte[]> getMap() {
		return map;
	}

	public void setMap(HashMap<String, byte[]> map) {
		this.map = map;
	}

	
	
	
}
