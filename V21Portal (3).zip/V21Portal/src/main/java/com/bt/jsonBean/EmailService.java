package com.bt.jsonBean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class EmailService {
	
	private String flowId;

	private SearchResponse result;
	public String getFlowId() {
		return flowId;
	}

	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}

	public SearchResponse getResult() {
		return result;
	}

	public void setResult(SearchResponse result) {
		this.result = result;
	}

	
	
	

}	
    
    
	