package com.bt.jsonBean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class SearchResponse {
	
	private SearchCriteria search;
	private SearchResult result;
	
	public SearchCriteria getSearch() {
		return search;
	}
	public void setSearch(SearchCriteria search) {
		this.search = search;
	}
	public SearchResult getResult() {
		return result;
	}
	public void setResult(SearchResult result) {
		this.result = result;
	}
	
	
	
}
