package com.bt.services;

import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

 
@Service
@Scope("singleton")
public class V21Properties{

	
	//Properties for data

	@Value("${dataDir}")
	private String dataDir;

	@Value("${indexDir}")
	private String indexDir;

	//Properties for user validation
	@Value("${credentials}")
	private String credentials; 

	//Properties for error codes
	@Value("${1100_Error_Txt}")
	private String error_1100_Txt; 

	@Value("${600_Erro_txt_NGA}")
	private String error_600_txt_NGA; 

	@Value("${600_Erro_txt_DSLM}")
	private String erro_600_txt_DSLM;
	
	
	//Properties for mail server
	@Value("${mailServer}")
	private String mailServer;

	@Value("${from}")
	private String from;

	@Value("${ccAddresses}")
	private String ccAddresses;

	@Value("${pathToReportHtml}")
	private String pathToReportHtml;

	
	public Map<String, String> getAllUsers(){
		String users[]=this.credentials.split(",");
		Map<String , String> allUsers = new TreeMap<String, String>();
		for (int i = 0; i < users.length; i++) {
			String userList[]=users[i].split("#");
			allUsers.put(userList[0], userList[1]);

		}

		return allUsers;

	}



	public String getDataDir() {
		return dataDir;
	}


	public void setDataDir(String dataDir) {
		this.dataDir = dataDir;
	}


	public String getIndexDir() {
		return indexDir;
	}


	public void setIndexDir(String indexDir) {
		this.indexDir = indexDir;
	}


	public String getCredentials() {
		return credentials;
	}


	public void setCredentials(String credentials) {
		this.credentials = credentials;
	}


	public String getError_1100_Txt() {
		return error_1100_Txt;
	}


	public void setError_1100_Txt(String error_1100_Txt) {
		this.error_1100_Txt = error_1100_Txt;
	}


	public String getError_600_txt_NGA() {
		return error_600_txt_NGA;
	}


	public void setError_600_txt_NGA(String error_600_txt_NGA) {
		this.error_600_txt_NGA = error_600_txt_NGA;
	}


	public String getErro_600_txt_DSLM() {
		return erro_600_txt_DSLM;
	}


	public void setErro_600_txt_DSLM(String erro_600_txt_DSLM) {
		this.erro_600_txt_DSLM = erro_600_txt_DSLM;
	}


	public String getMailServer() {
		return mailServer;
	}


	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}


	public String getFrom() {
		return from;
	}


	public void setFrom(String from) {
		this.from = from;
	}


	public String getCcAddresses() {
		return ccAddresses;
	}


	public void setCcAddresses(String ccAddresses) {
		this.ccAddresses = ccAddresses;
	}


	public String getPathToReportHtml() {
		return pathToReportHtml;
	}


	public void setPathToReportHtml(String pathToReportHtml) {
		this.pathToReportHtml = pathToReportHtml;
	}



}