package com.bt.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.commons.Constants;
import com.bt.exceptions.InvalidRequestException;
import com.bt.jsonBean.Credentials;
import com.bt.jsonBean.ErrorResponce;
import com.bt.jsonBean.SearchCriteria;
import com.bt.jsonBean.SearchList;
import com.bt.jsonBean.SearchResponse;
import com.bt.jsonBean.SearchResult;

@Service
public class V21SearchServices {

	@Autowired
	private V21Properties v21Properties;
	@Autowired
	private V21SearchHelper v21SearchHelper;
	@Autowired
	private SearchResponse response;
	@Autowired
	private SearchCriteria criteria;
	@Autowired
	private ErrorResponce errorResponce;
	@Autowired
	private SearchResult result; 

	private static String FS = File.separator;

	public String getXml(String emsId, String date, String flowId, String fileName) {
		String xmlFile="";
		System.out.println("executing searchFile");
		if (emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && flowId!=null || !"".equals(flowId)&& fileName!=null || !"".equals(fileName)) {
			System.out.println("inside searchFile :"+fileName);

			date=v21SearchHelper.dateForOperation(date);
			String newPath=v21Properties.getDataDir()+FS+date+FS+emsId+FS+flowId+FS+fileName;
			System.out.println("newPath :"+newPath);
			File file = new File(v21Properties.getDataDir()+FS+date+FS+emsId+FS+flowId+FS+fileName);
			if (file.exists()) {
				try {

					BufferedReader br = new BufferedReader(new FileReader(file));
					String sCurrentLine;
					while ((sCurrentLine = br.readLine()) != null) {
						xmlFile+=sCurrentLine;
					}
					br.close();
				} catch (Exception e) {
				}
			}else {
				System.out.println("dir not exist");
				throw new InvalidRequestException("Invalid Entry", "emsId: "+emsId);
			}

		}else {
			throw new InvalidRequestException("");
		}
		return xmlFile;
	}


	public SearchResponse fourthUseCase(String dateForOperation, String[] flowIds, boolean b) {

		List<String> flows = new ArrayList<String>();
		for (int i = 0; i < flowIds.length; i++) {
			flows.add(flowIds[i].trim());
		}
		
		SearchResult result=v21SearchHelper.searchWithFlowIDs(dateForOperation, flows);
		response.setResult(result);
		return response;
	}



	public SearchResponse thirdUseCase(String dateForOperation, List<String> errors) {
		SearchResult result=	v21SearchHelper.searchErrorFiles(dateForOperation, errors);
		response.setResult(result);
		return response;
	}



	public SearchResponse secondUseCase(String date, String flowId,Boolean errorCode) {
		SearchResult  result=null;

		List<String> flowIds=new ArrayList<String>();
		flowIds.add(flowId);

		if (errorCode) {
			result=v21SearchHelper.searchWithFlowIDsSecondUseCase(date, flowIds, false,true);
		} else {
			result=v21SearchHelper.searchWithFlowIDsSecondUseCase(date, flowIds, false,false);
		} 

		response.setResult(result);
		return response;

	}


	public SearchResponse secondUseCase(String date, String flowId,String error) {
		
		String emsId="";
		String href="";
		String fileName="";
		List<SearchList> searchLists=new ArrayList<SearchList>();			

		List<String> errorFileList=new ArrayList<String>();
		List<String> flowIds=new ArrayList<String>();
		flowIds.add(flowId);

		errorFileList=v21SearchHelper.searchWithFlowIDs(date, flowIds, error,true);


		int count=0;
		HashMap<String, String> map=new HashMap<String, String>();
		for(String filePath:errorFileList){

			String[] filenames=filePath.split(FS+Constants.fileConstant);

			//System.out.println("filenames--len"+filenames.length);
			for(int j=filenames.length-1;j>=0;j--){

				fileName=filenames[j];
				//System.out.println("filename--len"+fileName);

				flowId=filenames[j-1];
				//System.out.println("flowId--len"+flowId);									   

				emsId=filenames[j-2];
				//System.out.println("emsId--len"+emsId);

				date=filenames[j-3];	
				//System.out.println("date--len"+date);

				href="searchFile?date="+v21SearchHelper.dateToUser(date)+"&emsId="+emsId+"&flowId="+flowId+"&fileName="+fileName;;
				//System.out.println("href--len"+href);
				map.put(fileName, href);

				break;
			}


		}	

		Set<String> keys=map.keySet();
		for(String s:keys){
			SearchList searchList = new SearchList();
			searchList.setHref(map.get(s));
			searchList.setId(s);
			searchList.setLabel(fileName);	
			searchLists.add(searchList);
			count++;
		}	

		 
		SearchResponse response = prepareSearchResponce(emsId, date, new ArrayList<SearchList>(searchLists));
		
		/*for(SearchList ad:searchLists){
			System.out.println("--------"+ad.getHref().substring(ad.getHref().length()/2, ad.getHref().length()));
			System.out.println(ad.getLabel());
		}*/
		
		
		return response;

	}


	public List<String> ThurdUseCaseWithFlowID(String date, List<String> flowIds, String errorCode) {
		SearchResult  result=null;	

		List<String> errorFileList=new ArrayList<String>();

		errorFileList=v21SearchHelper.searchWithFlowIDs(date, flowIds, errorCode,true);
		return errorFileList;
	}
	public List<String> thirdUseCaseShowFiles(String date, List<String> flowIds, String errorCode) {
		SearchResult  result=null;	

		List<String> errorFileList=new ArrayList<String>();

		errorFileList=v21SearchHelper.searchWithFlowIDs(date, flowIds, errorCode,true);
		return errorFileList;
	}

	
	
	public SearchResponse firstSearchCall(String emsId, String date) {
		System.out.println("firstSearchCall");
		List<SearchList> searchLists = new ArrayList<SearchList>();
		
		//date=v21SearchHelper.dateForOperation(date);
		String dir=v21Properties.getDataDir()+FS+date+FS+emsId;
		//System.out.println("First search call 1"+dir);
		File emsIdDir = new File(dir);
		
			if (emsIdDir.exists()) {
				//System.out.println(searchLists);
				File listOfFiles[]=emsIdDir.listFiles();
				//System.out.println("ListOfFiles---1"+listOfFiles.length);

				for (int i = 0; i < listOfFiles.length; i++) {
					File flowIdFile=listOfFiles[i];
					//searchList=new SearchList();
					SearchList searchList = new SearchList();
					if (flowIdFile.isDirectory()) {

						String id=flowIdFile.getName();

						String tmpStr[]=flowIdFile.getName().split("_");
						String label=tmpStr[0];

						//System.out.println("label---1"+label);

						searchList.setLabel(label);

						//String flowPath=flowIdFile.getPath();

						String href="search?date="+v21SearchHelper.dateToUser(date)+"&&emsId="+emsId+"&&flowId="+id+"";
						//System.out.println("href---1"+href);
						//search?date=01-10-2016&emsId=emsId-100&flowId=100_111
						searchList.setId(flowIdFile.getName());
						searchList.setHref(href);

						
						searchLists.add(searchList);
						//System.out.println("Serachlist size: "+searchLists.size());
						/*for(SearchList searc:searchLists){
							System.out.println(searc.getHref());
						}*/
						
					}else {
						continue;
					}
				}
				//System.out.println(searchLists.size());

			}else {
				System.out.println("emsId dir not exist");
				throw new InvalidRequestException("V21 has not received the request with the desired EMS id within the specified date range or please check if the EMS Id : " +emsId+ " is correct or not.", "emsId: "+emsId);
			}
		/*}else {
			System.out.println("date dir not exist");
			throw new InvalidRequestException("Invalid Date", "Date: "+v21SearchHelper.dateToUser(date));
		}*/
		
		//System.exit(3);
		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		return response;
	}


	public SearchResponse firstSearchCall(String emsId, String date, String error) {
		System.out.println("firstSearchCall with ErrorCode");
		List<SearchList> searchLists = new ArrayList<SearchList>();
		List<String> flowIdPath = new ArrayList<String>();
		
		//date=v21SearchHelper.dateForOperation(date);
		String dir=v21Properties.getDataDir()+FS+date+FS+emsId;
		System.out.println("First search call 1"+dir);
		
		
		File emsIdDir = new File(dir);
		String flowId="";
		String href="";

		/*if (dateDir.exists()) {

			File emsIdDir = new File(dir+FS+emsId);
*/
			//System.out.println("emsIdDir-Here"+emsIdDir);

			if (emsIdDir.exists()) {

				File listOfFiles[]=emsIdDir.listFiles();

				List<String> flowIdList=new ArrayList<String>();
				//System.out.println("ListOfFiles---1"+listOfFiles.length);

				for (int i = 0; i < listOfFiles.length; i++) {
					File flowIdFile=listOfFiles[i];
					if (flowIdFile.isDirectory()) {	
						flowIdPath.add(flowIdFile.getAbsolutePath());
						flowIdList.add(flowIdFile.getName());
						
						//System.out.println("==========="+flowIdFile.getAbsolutePath());
					}

				}

				/*List<String> fileListNew = new ArrayList<String>();
				for (String flId : flowIdList) {
					fileListNew.addAll(v21SearchHelper.searchErrorCodes1(Arrays.asList(error), flId));
				}*/
				
				List<String> fileListNew=ThurdUseCaseWithFlowID(date, flowIdList, error);						

				int count=0;
				HashMap<String, String> map=new HashMap<String, String>();
				for(String filePath:fileListNew){				   

					String[] filenames=filePath.split(FS+Constants.fileConstant);

					//System.out.println("filenames--len"+filenames.length);
					for(int j=filenames.length-1;j>=0;j--){

						flowId=filenames[j-1];
						//System.out.println("flowId--len"+flowId);									   

						emsId=filenames[j-2];
						//System.out.println("emsId--len"+emsId);

						date=filenames[j-3];	
						//System.out.println("date--len->"+date);

						href="search?date="+v21SearchHelper.dateToUser(date)+"&emsId="+emsId+"&flowId="+flowId;
						//System.out.println("href--len"+href);
						map.put(flowId, href);

						break;
					}


				}	

				Set<String> keys=map.keySet();
				for(String s:keys){
					SearchList searchList = new SearchList();
					searchList.setHref(map.get(s));
					searchList.setId(s);
					searchList.setLabel(s);	
					searchLists.add(searchList);
					count++;
				}						

				//System.out.println("href "+href);

				//System.out.println(searchLists.size());

			}else {
				System.out.println("emsId dir not exist");
				throw new InvalidRequestException("V21 has not received the request with the desired EMS id within the specified date range or please check if the EMS Id : " +emsId+ " is correct or not.", "emsId: "+emsId);
			}
		/*}else {
			System.out.println("date dir not exist");
			throw new InvalidRequestException("Invalid Date", "Date: "+v21SearchHelper.dateToUser(date));
		}*/

		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		return response;
		
	}


	public SearchResponse secondSearchCall(String emsId, String date,String flowId) {
		List<SearchList> searchLists = new ArrayList<SearchList>();

		date=v21SearchHelper.dateForOperation(date);
		String dir=v21Properties.getDataDir()+FS+date;

		System.out.println("SecondSearch"+dir);

		File flowIdDir=new File(dir+FS+emsId+FS+flowId);
		//System.out.println("flowIdDir"+dir);

		if (flowIdDir.exists() && flowIdDir.isDirectory()) {

			File listOfFiles[]=flowIdDir.listFiles();



			//System.out.println("listOfFiles"+listOfFiles.length);

			for (int i = 0; i < listOfFiles.length; i++) {
				SearchList searchList = new SearchList();
				//System.out.println(listOfFiles[i].getName());

				String id=listOfFiles[i].getName();

				//String tmpStr[]=flowIdFile.getName().split("_");
				String label=listOfFiles[i].getName();


				searchList.setLabel(label);

				//String flowPath=flowIdFile.getPath();

				String href="searchFile?date="+v21SearchHelper.dateToUser(date)+"&&emsId="+emsId+"&&flowId="+flowId+"&&fileName="+listOfFiles[i].getName();
				//search?date=01-10-2016&emsId=emsId-100&flowId=100_111
				searchList.setId(id);
				searchList.setHref(href);

				searchLists.add(searchList);
			}

		//	System.out.println("searchLists"+searchLists.size());

		}else {
//			System.out.println("Directory do not exists");
			throw new InvalidRequestException("Invalid Flow Id", "flowId: "+flowId);
		}



		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		return response;
	}

	public SearchResponse prepareSearchResponce(String emsId, String date, List<SearchList> searchLists) {

		response=new SearchResponse();
		result=new SearchResult();
		criteria=new SearchCriteria();
		criteria.setDate(v21SearchHelper.dateToUser(date));
		criteria.setEmsId(emsId);

		response.setSearch(criteria);

		result.setCount(searchLists.size());
		result.setData(searchLists);
		response.setResult(result);
		System.out.println("Responce prepared and sent");
		return response;
	}



	public ErrorResponce sendEmail(String emailResult, SearchResponse searchResponse, String[] flowIds) {

		// TODO Auto-generated method stub

		errorResponce.setMessage(v21SearchHelper.sendEmail(emailResult, searchResponse, flowIds));
		return errorResponce;

	}

	public boolean validateUser(Credentials credentials, Map<String, String> mapOfUsers) {

		String password=mapOfUsers.get(credentials.getUsername());
		System.out.println("Password: "+password);
		if (credentials.getPassword().equals(password)) {
			return true;
		} else {
			return false;
		}

	}

}
