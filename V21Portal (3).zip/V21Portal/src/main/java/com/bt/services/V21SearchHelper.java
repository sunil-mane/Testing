package com.bt.services;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.lucene.search.TopDocs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.commons.Constants;
import com.bt.exceptions.InvalidRequestException;
import com.bt.jsonBean.SearchList;
import com.bt.jsonBean.SearchResponse;
import com.bt.jsonBean.SearchResult;
import com.bt.lucene.LuceneTester;
import com.bt.util.EmailUtility;
import com.bt.util.V21FileUtility;

@Service
public class V21SearchHelper {

	@Autowired
	private V21Properties v21Properties;
	@Autowired
	private LuceneTester tester;
	@Autowired
	private SearchResult searchResult;
	@Autowired
	private EmailUtility emailUtility;
	@Autowired
	private V21FileUtility fileUtility;
	public TopDocs hits;
	/*  static List<String> fileList=new ArrayList<String>();
	  static List<String> pathList=new ArrayList<String>();*/
	public List<SearchList> searchListData=new ArrayList<SearchList>();

	public  String dataDir =null;
	public static  String pathToReportHtml="";
	static String FS = File.separator;      
	//initializing dir path variables

	public void initSearchHelper(){
		dataDir=v21Properties.getDataDir();
		pathToReportHtml=v21Properties.getPathToReportHtml();
		System.out.println("Search helper initiated");
	}

/*	public void searchErrorCodes(List<String> errorCodes, String path) {
		List<String> fileList=new ArrayList<String>();
	    List<String> pathList=new ArrayList<String>();
		System.out.println("Inside method searchErrorCodes..."+errorCodes);
		String error_1100=v21Properties.getError_1100_Txt();
		String error_600_NGA=v21Properties.getError_600_txt_NGA();
		String error_600_DSLM=v21Properties.getErro_600_txt_DSLM();
		try{
			dataDir=path;
			System.out.println("path received : "+path);
			tester.createIndex(dataDir);       

			List<String> errorfileList=new ArrayList<String>();
			// fileList.clear();

			for(String errorCode:errorCodes){
				System.out.println("errorCode : "+errorCode);

				if(errorCode.equals("1100")){
					System.out.println("Searching for error code 1100");			   

					tester.search(error_1100);
					// fileList=LuceneTester.fileList_first;
					List<String> fileListNew=new ArrayList<String>();

					fileListNew=LuceneTester.fileList_first;
					System.out.println("fileList_first in 1100: "+LuceneTester.fileList_first);

					for(String file:fileListNew){
						System.out.println("FileList in 1100--"+file);
						fileList.add(file);
					}

					System.out.println("fileList in 1100: "+fileList);

				}

				if(errorCode.equals("600")){

					System.out.println("Searching for error code 600" + error_600_NGA);
					errorfileList=tester.search(error_600_NGA);	
					// fileList=LuceneTester.fileList_first;
					System.out.println("errorfileList in 600_NGA: "+errorfileList);

					List<String> fileListNew=new ArrayList<String>();

					fileListNew=LuceneTester.fileList_first;
					System.out.println("fileList_first in 600_NGA: "+LuceneTester.fileList_first);

					for(String file:fileListNew){
						System.out.println("FileList in 600_NGA--"+file);

						fileList.add(file);
					}
					System.out.println("fileList in 600_NGA: "+fileList);


					// System.out.println("fileList size for erros "+fileList);
					for(String fileName:errorfileList){				
						if(!fileName.contains("_NGA")){
							for(int i=0;i<fileList.size();i++){
								if(fileList.get(i).equals(fileName)){
									fileList.remove(i);
								}

							}
						}

					}
					errorfileList.clear();
					tester.search(error_600_DSLM);	
					//fileList=LuceneTester.fileList_first;
					List<String> fileListNew1=new ArrayList<String>();

					fileListNew1=LuceneTester.fileList_first;
					System.out.println("fileList in 600_DSLM: "+LuceneTester.fileList_first);

					for(String file:fileListNew1){
						System.out.println("FileList in 600_DSLM--"+file);

						fileList.add(file);
					}
					System.out.println("fileList in 600_DSLM: "+fileList);

					for(String fileName:errorfileList){
						System.out.println("filename for error 1"+fileName);
						if(!fileName.contains("_Him_DSLM")){
							for(int i=0;i<fileList.size();i++){
								if(fileList.get(i).equals(fileName)){
									fileList.remove(i);
								}

							}
						}

					}			   
				}	
			}
		}
		catch(Exception e){
			e.printStackTrace();
			System.err.println("Exception occured inside method searchErrorCodes");
		}
	}*/

	public List<String> searchErrorCodes(List<String> errorCodes, String path) {
		List<String> fileList=new ArrayList<String>();
	    
		//System.out.println("Inside method searchErrorCodes..."+errorCodes);
		String error_1100=v21Properties.getError_1100_Txt();
		String error_600_NGA=v21Properties.getError_600_txt_NGA();
		String error_600_DSLM=v21Properties.getErro_600_txt_DSLM();
		try{
			dataDir=path;
			//System.out.println("path received : "+path);
			tester.createIndex(dataDir);       

			List<String> errorfileList=new ArrayList<String>();
			// fileList.clear();

			for(String errorCode:errorCodes){
				//System.out.println("errorCode : "+errorCode);

				if(errorCode.equals("1100")){
					//System.out.println("Searching for error code 1100");			   

					tester.search(error_1100);
					// fileList=LuceneTester.fileList_first;
					List<String> fileListNew=new ArrayList<String>();

					fileListNew=LuceneTester.fileList_first;
					//System.out.println("fileList_first in 1100: "+LuceneTester.fileList_first);

					for(String file:fileListNew){
						//System.out.println("FileList in 1100--"+file);
						fileList.add(file);
					}

					//System.out.println("fileList in 1100: "+fileList);

				}

				if(errorCode.equals("600")){

					//System.out.println("Searching for error code 600" + error_600_NGA);
					errorfileList=tester.search(error_600_NGA);	
					// fileList=LuceneTester.fileList_first;
					//System.out.println("errorfileList in 600_NGA: "+errorfileList);

					List<String> fileListNew=new ArrayList<String>();

					fileListNew=LuceneTester.fileList_first;
					//System.out.println("fileList_first in 600_NGA: "+LuceneTester.fileList_first);

					for(String file:fileListNew){
						//System.out.println("FileList in 600_NGA--"+file);

						fileList.add(file);
					}
					//System.out.println("fileList in 600_NGA: "+fileList);


					// System.out.println("fileList size for erros "+fileList);
					for(String fileName:errorfileList){				
						if(!fileName.contains("_NGA")){
							for(int i=0;i<fileList.size();i++){
								if(fileList.get(i).equals(fileName)){
									fileList.remove(i);
								}

							}
						}

					}
					errorfileList.clear();
					tester.search(error_600_DSLM);	
					//fileList=LuceneTester.fileList_first;
					List<String> fileListNew1=new ArrayList<String>();

					fileListNew1=LuceneTester.fileList_first;
					//System.out.println("fileList in 600_DSLM: "+LuceneTester.fileList_first);

					for(String file:fileListNew1){
						//System.out.println("FileList in 600_DSLM--"+file);

						fileList.add(file);
					}
					//System.out.println("fileList in 600_DSLM: "+fileList);

					for(String fileName:errorfileList){
						//System.out.println("filename for error 1"+fileName);
						if(!fileName.contains("_Him_DSLM")){
							for(int i=0;i<fileList.size();i++){
								if(fileList.get(i).equals(fileName)){
									fileList.remove(i);
								}

							}
						}

					}			   
				}	
			}
		}
		catch(Exception e){
			e.printStackTrace();
			System.err.println("Exception occured inside method searchErrorCodes");
		}
		return fileList;
	}

	public List<String> searchFlowIDForSecond(List<String> flowIds, String path){

		System.out.println("Inside method searchFlowID..."+flowIds);
		
		ArrayList<String> pathListNew =  new ArrayList<String>();
	   
		try{
			// LuceneTester tester = new LuceneTester();
			// dataDir=path;
			// tester.createIndex(dataDir);     
			List<String> pathList=walk(path);  
			

			for(String flowId:flowIds){

				//pathList.clear();
//				List<String> newPathIds=new ArrayList<String>();
        
				//System.out.println( "pathList:" + pathList );

				for(int i=0; i<pathList.size();i++){
					//System.out.println("pathlist after split : " + i + " " + pathList.get(i));
					String[] filenames = pathList.get(i).split(FS+Constants.fileConstant);
					//System.out.println("filenames list size : " + i + " " + filenames.length);
					String[] flowIdNew = filenames[filenames.length-1].split("_");
					//System.out.println("flowIdNew after split by underscore : " + i + " " + filenames[0]);
					for (String flId : flowIdNew){
						//System.out.println("flowId check flId " + flId);

						if (flId.equals(flowId)) {
							//System.out.println("flowId check " + flowId);
							// pathList.remove(i);
//							newPathIds.add(pathList.get(i));
							pathListNew.add(pathList.get(i));
							//System.out.println("sizeeeeeeeeeeeee->"+pathListNew.size());
						}       
					}
				}
//				for(int i=0; i<newPathIds.size();i++){
//					pathListNew.add(newPathIds.get(i));
//				}                                 
				//System.out.println( "pathList after filtering" + pathListNew );

//				if(pathList.isEmpty()){
//					flowIds.remove(flowId);
//					System.out.println("removed flow if "+flowId);
//				}
			}
//			pathList=pathListNew;
		}
		catch(Exception e){
			e.printStackTrace();
			System.err.println("Exception occured inside method searchFlowId..");
		}

		return pathListNew;
	}
	
	
	public List<String> searchFlowIDDirpath(List<String> flowIds, String path){

		System.out.println("Inside method searchFlowID..."+flowIds);		
		List<String> pathList=new ArrayList<String>();
				
		try{	   
			
			
			for(String flowId:flowIds){								
				
				String flowidDir=walkForFlowIDs(path, flowId);
				if(null!=flowidDir && !"".equals(flowidDir)){
					pathList.add(flowidDir);
				}
				
			}
			
			
		}
		catch(Exception e){
			e.printStackTrace();
			System.err.println("Exception occured inside method searchFlowId..");
		}

		return pathList;
	}


	public List<String> searchFlowID(List<String> flowIds, String path){

		System.out.println("Inside method searchFlowID..."+flowIds);
		List<String> pathList=new ArrayList<String>();
		List<String> dummy = new ArrayList<String>(flowIds);
		
		
		try{
			ArrayList<String> pathListNew =  new ArrayList<String>();
			for(String flowId:dummy){

				List<String> newPathIds=new ArrayList<String>();
				walk(path);          
				//System.out.println( "pathList:" + pathList );

				for(int i=0; i<pathList.size();i++){
					//System.out.println("pathlist after split : " + i + " " + pathList.get(i));
					if (pathList.get(i).contains(flowId)) {
						//System.out.println("flowId check " + flowId);
						// pathList.remove(i);
						newPathIds.add(pathList.get(i));
					}	  
				}
				for(int i=0; i<newPathIds.size();i++){
					pathListNew.add(newPathIds.get(i));
				}	             	             
				//System.out.println( "pathList after filtering" + pathListNew );

				if(pathList.isEmpty()){
					flowIds.remove(flowId);
					//System.out.println("removed flow if "+flowId);
				}
			}
			pathList=pathListNew;
		}
		catch(Exception e){
			e.printStackTrace();
			System.err.println("Exception occured inside method searchFlowId..");
		}

		return flowIds;
	}




	@SuppressWarnings("unchecked")
	public SearchResult searchErrorFiles(String date, List<String> errorCodes ) {
		List<String> fileList=new ArrayList<String>();
	    List<String> pathList=new ArrayList<String>();
		//fileList.clear();
		//System.out.println("Path list cleared");

		searchResult= new SearchResult();
		//System.out.println("Inside method searchErroFiles .... ");
		
		//searchDateFolder(date);
		File root = new File(v21Properties.getDataDir()+FS+date);
		if(root.exists() && null!=root.listFiles()){
			File emsIds[]=root.listFiles();
			for (int j = 0; j < emsIds.length; j++) {
				File flowIds[]=emsIds[j].listFiles();
				
				for (int k = 0; k < flowIds.length; k++) {				
				
				File flow=flowIds[k];
				
				//System.out.println("-----------------"+flow.getName());

				String fIdPath=flow.getAbsolutePath();
				
				//tester.createIndex(fIdPath);
				pathList.add(fIdPath);
				
			/*	for (int l = 0; l < files.length; l++) {
					File xml = files[l];
					String name = xml.getName()	;
					//System.out.println(name);
				}*/
				
			}
			
		}
		
		try{
			searchListData.clear();
			for(String path:pathList){
				fileList.addAll(searchErrorCodes(errorCodes, path));		   
			}

			//System.out.println("Filelist size is returned after Error codes file search: "+fileList.size());
			//System.out.println("FileList in searchErrorFiles  "+fileList);
			if(fileList.size()>0){

				int count=getHrefForEMSId(fileList);		   

				searchResult.setCount(count);
				ArrayList<SearchList> searchListDataNew =  (ArrayList<SearchList>) ((ArrayList<SearchList>) searchListData).clone();
				//Collections.copy(searchListDataNew, searchListData);
				searchResult.setData(searchListDataNew);

				/*for(SearchList searchres:searchListDataNew){
					//System.out.println("searchListDataNew in searchErroFiles "+searchres.getHref());			   
				}*/
			}

			else{
				//System.out.println("Empty list");
				throw new InvalidRequestException("V21 either did not receive a request with the mentioned error code or the request was not valid");
			}
		}finally{
			System.out.println("Exiting method  searchErrorFiles...");
			fileList.clear();
			LuceneTester.fileList_first.clear();
			searchListData.clear();


			}
		}
			else{
				throw new InvalidRequestException("V21 either did not receive a request with the mentioned error code or the request was not valid");
			}
		return searchResult;

	}


	@SuppressWarnings({ "unchecked" })
	public SearchResult searchWithFlowIDsSecondUseCase(String date, List<String> flowIds ,boolean sendMail, boolean errorCode){
		List<String> fileList=new ArrayList<String>();
//	    List<String> pathList=new ArrayList<String>();
		// errorCode=true;
		System.out.println("Inside method searchWithFlowIDs"+errorCode);
		boolean errorResponseException=false;

		List<String> filesFlowIdSpec=new ArrayList<String>();
		//for checking error codes
		
		ArrayList<SearchList> searchListDataNew =null;
		//fileList.clear();
		
		String dir=v21Properties.getDataDir()+FS+date;
		File dateDir = new File(dir);
		
			if(dateDir.exists()){			
			
			try{
	
			List<String> pathList= searchFlowIDDirpath(flowIds, dateDir.getAbsolutePath());	
				
			//System.out.println("pathList size is "+pathList.size());

			if(pathList.size()>0){	  

				for(String flowIdDirPath:pathList){			   

					File root = new File( flowIdDirPath );
					File[] list = root.listFiles();
					if (list == null) continue;

					for ( File f : list ) {
						if ( f.isFile() && f.getName().endsWith(".xml")) {		        	   
							filesFlowIdSpec.add(f.getAbsolutePath());

						}
					}		       

				}	


				//System.out.println("filesFlowIdSpec size is :"+filesFlowIdSpec.size());
				searchListData.clear();

				int count=getHref(filesFlowIdSpec);		 

				searchResult.setCount(count);
				searchListDataNew =  (ArrayList<SearchList>) ((ArrayList<SearchList>) searchListData).clone();
				searchResult.setData(searchListDataNew);

				/*for(SearchList searchres:searchListDataNew){
					System.out.println("searchListDataNew "+searchres.getHref());

				}*/

			}		   

			else{
				System.out.println("Empty list");
				throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id or the request was not valid", "flowId: "+flowIds);
			}
			if (errorCode) {
				searchListData.clear();
					
					List<String> errorCodes = new ArrayList<String>();
	
					errorCodes.add("600");
	
					errorCodes.add("1100");
					for(String path:pathList){	
	
						fileList=searchErrorCodes(errorCodes, path);			
	
					}
					if(fileList.size()>0){
	
						int count=getHref(fileList);		   
	
						searchResult.setCount(count);
						searchListDataNew =  (ArrayList<SearchList>) ((ArrayList<SearchList>) searchListData).clone();
	
						searchResult.setData(searchListDataNew);
					}
	
					else{
						System.out.println("No error response");
						errorResponseException=true;
						throw new InvalidRequestException("V21 did not receive failure response for flow id: "+flowIds);
					}	
	
				}
	
			}	
			
			catch(Exception e){
				if(errorResponseException){
					throw new InvalidRequestException("V21 did not receive failure response for flow id: "+flowIds);
				}
				else{
					throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id or the request was not valid", "flowId: "+flowIds);
				}
			}
			finally{
				searchListData.clear();
				fileList.clear();
			}
		}
		else{
			throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id or the request was not valid", "flowId: "+flowIds);
		}
		
		return searchResult;
	}



	@SuppressWarnings("unchecked")
	public List<String> searchWithFlowIDs(String date, List<String> flowIds , String error,boolean errorCode){

		File datePath = new File(dataDir+FS+date);
		
		    List<String> fileList=new ArrayList<String>();
		    List<String> pathList=walk(datePath.getAbsolutePath());
		
		// errorCode=true;
		//System.out.println("Inside method searchWithFlowIDs"+errorCode);

		List<String> filesFlowIdSpec=new ArrayList<String>();
		//for checking error codes
		List<String> fileNames=new ArrayList<String>();
		ArrayList<SearchList> searchListDataNew =null;
	
		String dateFolderpath= searchDateFolder(date);

		List<String> errorFileList=new ArrayList<String>();
		try{

			flowIds= searchFlowID(flowIds, dateFolderpath);	

			//System.out.println("pathList size is "+pathList.size());

			if(pathList.size()>0){	  

				for(String flowIdDirPath:pathList){			   

					File root = new File( flowIdDirPath );
					File[] list = root.listFiles();
					if (list == null) continue;

					for ( File f : list ) {
						if ( f.isFile() && f.getName().endsWith(".xml")) {		        	   
							filesFlowIdSpec.add(f.getAbsolutePath());

						}
					}		       

				}	


				//System.out.println("filesFlowIdSpec size is :"+filesFlowIdSpec.size());
				searchListData.clear();

				int count=getHref(filesFlowIdSpec);		 

				searchResult.setCount(count);
				searchListDataNew =  (ArrayList<SearchList>) ((ArrayList<SearchList>) searchListData).clone();
				searchResult.setData(searchListDataNew);

				/*for(SearchList searchres:searchListDataNew){
					System.out.println("searchListDataNew "+searchres.getHref());

				}*/

			}		   

			else{
				System.out.println("Empty list");
				throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id or the request was not valid", "flowId: "+flowIds);
			}
			if (errorCode) {
				searchListData.clear();
				for (Iterator<String> iterator = filesFlowIdSpec.iterator(); iterator.hasNext();) {
					String flowPath = iterator.next();
					int lastIndex=flowPath.lastIndexOf(FS)+1;

					String fileName=flowPath.substring(lastIndex, flowPath.length());
					fileNames.add(fileName);		
					//System.out.println("Added file: "+fileName);


				}
				List<String> errorCodes = new ArrayList<String>();

				if(null!=error && !error.equals("")){
					errorCodes.add(error);
				}
				else{
					errorCodes.add("600");

					errorCodes.add("1100");
				}

				//System.out.println("filesFlowIdSpec while errorcode : "+filesFlowIdSpec.size());
				for(String path:pathList){						

					//System.out.println("Error codes::"+errorCodes);
					//System.out.println("Path::"+path);
					fileList.addAll(searchErrorCodes(errorCodes, path));			

				}
				if(fileList.size()>0){

					errorFileList=(List<String>) ((ArrayList<String>) fileList).clone();

					int count=getHref(fileList);		   

					searchResult.setCount(count);
					searchListDataNew =  (ArrayList<SearchList>) ((ArrayList<SearchList>) searchListData).clone();

					searchResult.setData(searchListDataNew);

					/*for(SearchList searchres:searchListDataNew){
						System.out.println("searchListDataNew "+searchres.getHref());			   
					}*/
				}

				else{
					System.out.println("Empty list");
					throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id or the request was not valid", "flowId: "+flowIds);
				}


				//System.out.println("searchRes: "+searchResult.getCount());
			}

		}
		catch(Exception e){
			e.printStackTrace();
			throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id or the request was not valid", "flowId: "+flowIds);
		}finally{
			searchListData.clear();
			fileList.clear();
		}
		System.out.println("Done ...");		

		return errorFileList;
	}



	public String sendEmail(String emailAdd, SearchResponse searchResponse, String[] flowIds){	   

		try {
			System.out.println("Received email Add : "+emailAdd);
			HashMap<String, byte[]> map=new HashMap<String, byte[]>();

			com.bt.jsonBean.EmailBody emailBody=fileUtility.getZipAsByteArray(searchResponse, flowIds);
			map=emailBody.getMap();
			
			String body = emailBody.getBodyText().toString();		
			String subject = "EMS LOGS";
			emailUtility.sendMail(subject, body,map, emailAdd);
			return "Success";

		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Exception while sending email");
			e.printStackTrace();

			return "Failure";
		}


	}

	public SearchResult searchWithFlowIDs(String date, List<String> flowIds){
		
	    List<String> pathList=new ArrayList<String>();
		new ArrayList<String>();		
		
		String dir=v21Properties.getDataDir()+FS+date;
		File dateDir = new File(dir);
		
		if(dateDir.exists()){
						
			try{
	
			pathList= searchFlowIDDirpath(flowIds, dateDir.getAbsolutePath());	
	
			if(pathList.size()>0){  
	
				searchListData.clear();
	
				int count=0;	
	
				count=getHrefForFlowID(pathList);	
	
				searchResult.setCount(count);
				searchResult.setData(searchListData);
	
			}		   
	
			else{
				System.out.println("Empty list");
				throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id�s or the request was not valid");
			}
			}
			catch(Exception e){
				e.printStackTrace();
				throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id�s or the request was not valid");
			}
			 
		}
		else{
			throw new InvalidRequestException("V21 either did not receive a request with the mentioned flow id�s or the request was not valid");
		}
		
		System.out.println("Done ...");


		return searchResult;
	}



	@SuppressWarnings("unused")
	public int getHref(List<String> fileList){

		String href=null;
		String fileName=null;
		String flowId=null;
		String emsId=null;
		String date=null;
		int count=0;
		for(String filePath:fileList){
			SearchList searchList=new SearchList();

			String[] filenames=filePath.split(FS+Constants.fileConstant);

			//System.out.println("filenames--len"+filenames.length);
			for(int i=filenames.length-1;i>=0;i--){

				fileName=filenames[i];
				//System.out.println("fileName--len"+fileName);

				flowId=filenames[i-1];
				//System.out.println("flowId--len"+flowId);

				emsId=filenames[i-2];
				//System.out.println("emsId--len"+emsId);

				date=filenames[i-3];	
				//System.out.println("date--len"+date);

				href="searchFile?date="+dateToUser(date)+"&emsId="+emsId+"&flowId="+flowId+"&fileName="+fileName;
				//System.out.println("href--len"+href);

				break;
			}

			searchList.setHref(href);
			searchList.setId(fileName);
			searchList.setLabel(fileName);				   
			count++;
			searchListData.add(searchList);
		}	
		return count;

	}

	@SuppressWarnings("unused")
	public int getHrefForFlowID(List<String> fileList){

		String href=null;
		String flowId=null;
		String emsId=null;
		String date=null;
		int count=0;
		HashMap<String, String> map=new HashMap<String, String>();
		for(String filePath:fileList){

			String[] filenames=filePath.split(FS+Constants.fileConstant);

			//System.out.println("filenames--len"+filenames.length);
			for(int i=filenames.length-1;i>=0;i--){


				flowId=filenames[i];
				//System.out.println("flowId--len"+flowId);


				emsId=filenames[i-1];
				//System.out.println("emsId--len"+emsId);

				date=filenames[i-2];	
				//System.out.println("date--len"+date);

				href="search?date="+dateToUser(date)+"&emsId="+emsId+"&flowId="+flowId;
				//System.out.println("href--len"+href);
				map.put(flowId, href);

				break;
			}


		}	

		Set<String> keys=map.keySet();
		for(String s:keys){
			SearchList searchList = new SearchList();
			searchList.setHref(map.get(s));
			searchList.setId(s);
			searchList.setLabel(s);				   
			count++;
			searchListData.add(searchList);
		}


		return count;

	}


	@SuppressWarnings("unused")
	public int getHrefForEMSId(List<String> fileList){

		String href=null;
		String fileName=null;
		String flowId=null;
		String emsId=null;
		String date=null;
		int count=0;

		HashMap<String, String> map=new HashMap<String, String>();
		for(String filePath:fileList){


			String[] filenames=filePath.split(FS+Constants.fileConstant);

			//System.out.println("filenames--len"+filenames.length);
			for(int i=filenames.length-1;i>=0;i--){

				fileName=filenames[i];
				//System.out.println("fileName--len"+fileName);

				flowId=filenames[i-1];
				//System.out.println("flowId--len"+flowId);

				emsId=filenames[i-2];
				//System.out.println("emsId--len"+emsId);

				date=filenames[i-3];	
				//System.out.println("date--len"+date);

				href="search?date="+dateToUser(date)+"&emsId="+emsId;
				map.put(emsId, href);
				//System.out.println("href under emsid--len"+href);

				break;
			}


		}

		Set<String> keys=map.keySet();
		for(String s:keys){
			SearchList searchList = new SearchList();
			searchList.setHref(map.get(s));
			searchList.setId(s);
			searchList.setLabel(s);	
			count++;
			searchListData.add(searchList);
		}



		return count;

	}

	@SuppressWarnings("rawtypes")
	public List walk( String path ) {
	    List<String> pathList=new ArrayList<String>();
		File root = new File( path );
		File[] list = root.listFiles();


		if (list == null) return null;

		for ( File f : list ) {
			if ( f.isDirectory() ) {
				walk( f.getAbsolutePath(), pathList);
				//System.out.println( "Dir:" + f.getAbsoluteFile() );
			}
			else {
				//System.out.println( "File:" + f.getAbsoluteFile() );
				pathList.add(path);
				break;
			}
		}
		return pathList;
	}
	
	
	@SuppressWarnings("rawtypes")
	public String walkForFlowIDs( String path, String flowId ) {	 
		//System.out.println("path her "+path);
		File root = new File( path );
		File[] list = root.listFiles();
		String flowIdDirpath=null;
		
		if (list == null) return null;

		outer: for ( File f : list ) {
			if ( f.isDirectory()) {				
				File root1 = new File( f.getAbsolutePath() );
				File[] list1 = root1.listFiles();
				for ( File flowIdDir : list1 ) {
					String[] flowIdNew = flowIdDir.getName().split("_");
					
					if ( flowIdDir.isDirectory() && flowIdNew[0].equals(flowId)) {
						flowIdDirpath=flowIdDir.getAbsolutePath();
						break outer;
					}									
				}
				
			}			
		}
		return flowIdDirpath;
	}

	
	
	

	@SuppressWarnings("rawtypes")
	public List walk( String path, List<String> pathList ) {
//	    List<String> pathList=new ArrayList<String>();
		File root = new File( path );
		File[] list = root.listFiles();


		if (list == null) return null;

		for ( File f : list ) {
			if ( f.isDirectory() ) {
				walk( f.getAbsolutePath(),pathList );
				//System.out.println( "Dir:" + f.getAbsoluteFile() );
			}
			else {
				//System.out.println( "File:" + f.getAbsoluteFile() );
				pathList.add(path);
				break;
			}
		}
		return pathList;
	}
	
	public String searchDateFolder(String date){

		File root = new File(dataDir+FS+date);
		//System.out.println("datedir : "+dataDir);
		//System.out.println("inside seachDateFlder :"+date+" "+root.getAbsolutePath());
		File[] list = root.listFiles();
		String dateFolderpath=null;

		//System.out.println("list her "+list);
		if (list == null){
			System.out.println("fileList is empty");
			return null;
		}
		//pathList.clear();
		//for ( File root : list ) {
			//System.out.println(":::::::"+root.getAbsolutePath());
			if ( root.isDirectory() && root.getName().equals(date)) {

				dateFolderpath=root.getAbsolutePath();
				walk( root.getAbsolutePath() );
				//System.out.println( "walk Dir:" + root.getAbsoluteFile() );
				//System.out.println( "walk pathList:" + pathList );
				//break;
			}
		//}
		return dateFolderpath;

	}


	public String dateForOperation(String oldDateString) {
		final String  NEW_FORMAT = "dd_M_yy";
		final String  OLD_FORMAT= "dd-M-yyyy";
		String newDateString;

		SimpleDateFormat sdf = new SimpleDateFormat(OLD_FORMAT);
		Date d = null;
		try {
			d = sdf.parse(oldDateString.replace("_", "-"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sdf.applyPattern(NEW_FORMAT);
		newDateString = sdf.format(d);
		return newDateString;
	}


	public String dateToUser(String oldDateString) {
		final String OLD_FORMAT = "dd_M_yy";
		final String NEW_FORMAT = "dd-M-yyyy";
		//oldDateString = "01_10_16";
		String newDateString;

		SimpleDateFormat sdf = new SimpleDateFormat(OLD_FORMAT);
		Date d = null;
		try {
			d = sdf.parse(oldDateString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sdf.applyPattern(NEW_FORMAT);
		newDateString = sdf.format(d);
		return newDateString;
	}

	public void checkDateDir(String date){
		String newPath=v21Properties.getDataDir()+FS+date;
		if (!new File(newPath).exists()) {
			throw new InvalidRequestException("V21 either did not receive a request with the mentioned date or the request was not valid");
		}

	}
}
