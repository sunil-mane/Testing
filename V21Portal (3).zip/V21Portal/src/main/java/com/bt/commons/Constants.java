package com.bt.commons;

import java.io.File;

public class Constants {
	//for linux
	public static String fileConstant="";

	//for windows
	
	static{
		String os=System.getProperty("os.name");
		if (os.toLowerCase().contains("window")) {
			 fileConstant=File.separator;
		} 
	}
}
