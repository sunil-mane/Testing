package com.bt.commons;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PhraseQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

import com.bt.lucene.LuceneConstants;

public class HelloLucene {
  public static void main(String[] args) throws IOException, ParseException {
    // 0. Specify the analyzer for tokenizing text.
    //    The same analyzer should be used for indexing and searching
	  
	 Long start = System.currentTimeMillis(); 
    StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_36);

    // 1. create the index
    Directory index =  FSDirectory.open(new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\v21"));

    IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_36, analyzer);

//    IndexWriter w = new IndexWriter(index, config);
//
//    File flowFile = new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\02_10_16\\emsId-1002\\198738_646342");
//    
//    File xmls[] = flowFile.listFiles();
//    
//    for (int i = 0; i < xmls.length; i++) {
//    	//File xmlFile=xmls[i];
//    	
//		indexFile(xmls[i], w);
//	}
//    
//     flowFile = new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\02_10_16\\emsId-1002\\188738_646341");
//    
//    xmls = flowFile.listFiles();
//    
//    for (int i = 0; i < xmls.length; i++) {
//    	//File xmlFile=xmls[i];
//    	
//		indexFile(xmls[i], w);
//	}    
//    w.close();

    // 2. query
    String querystr = args.length > 0 ? args[0] : "lucene";


    // the "title" arg specifies the default field to use
    // when no field is explicitly specified in the query.
    BooleanQuery bQuery = new BooleanQuery();
    Query q = new QueryParser(Version.LUCENE_36, LuceneConstants.CONTENTS, analyzer).parse("ems.ConnectionException AND errorDescription");
    bQuery.add(q, BooleanClause.Occur.MUST);
//    Query q1 = new QueryParser(Version.LUCENE_36, LuceneConstants.CONTENTS, analyzer).parse("ActivityStatusType AND FAILURE");
//    bQuery.add(q1, BooleanClause.Occur.MUST_NOT);
//    Query q1 = new QueryParser(Version.LUCENE_36, LuceneConstants.FILE_PATH, analyzer).parse("C:/Users/611189996/Desktop/Sagar-Data/Projects/V21Portal/V21 Docs/archives_final_data/02_10_16/emsId-1002/198738_646342");
//     bQuery.add(q1, BooleanClause.Occur.MUST);
     PhraseQuery pq= new PhraseQuery();
//     pq.add(new Term(LuceneConstants.FILE_NAME, "Response_Him_DSLM_54868344_92815897_05_Aug_16_18_38_36_574Err_10021_93.xml"));
//     pq.add(new Term(LuceneConstants.FILE_PATH, "amol"));
//     bQuery.add(pq,  BooleanClause.Occur.MUST_NOT);
// 
//     PhraseQuery pq1= new PhraseQuery();
//     pq1.add(new Term(LuceneConstants.FILE_NAME, "Response_Him_DSLM_55193063_114088737_19_Aug_16_21_45_03_662Err_10024_96.xml"));
////     pq.add(new Term(LuceneConstants.FILE_PATH, "C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\02_10_16\\emsId-1002\\198738_646342"));
//     bQuery.add(pq1,  BooleanClause.Occur.MUST_NOT);
//     Query q2 = new QueryParser(Version.LUCENE_36, LuceneConstants.FILE_NAME, analyzer).parse("Response_Him_DSLM_54868344_92815897_05_Aug_16_18_38_36_574Err_10021_93.xml");
//     bQuery.add(q2, BooleanClause.Occur.MUST); 
     
     
    // 3. search
    int hitsPerPage = 10;
    IndexReader reader = IndexReader.open(index);
    IndexSearcher searcher = new IndexSearcher(reader);
    TopScoreDocCollector collector = TopScoreDocCollector.create(hitsPerPage, true);
    searcher.search(bQuery, collector);
    ScoreDoc[] hits = collector.topDocs().scoreDocs;

    // 4. display results
    System.out.println("Found " + hits.length + " hits.");
    for(int i=0;i<hits.length;++i) {
      int docId = hits[i].doc;
      Document d = searcher.doc(docId);
      System.out.println((i + 1) + ". " + d.get("title"));
      System.out.println(d.getFields().get(i));
    }

    // searcher can only be closed when there
    // is no need to access the documents any more. 
    searcher.close();
    
    Long responseTime= System.currentTimeMillis()-start;
    
    System.out.println("Time :"+responseTime);
  }

/*  private static void addDoc(IndexWriter w, String value) throws IOException {
    Document doc = new Document();
    doc.add(new Field("title", value, Field.Store.YES, Field.Index.ANALYZED));
    w.addDocument(doc);
  }
 */
  private static void indexFile(File file,IndexWriter w) throws IOException{
      System.out.println("Indexing "+file.getCanonicalPath());
      Document document = getDocument(file);
      w.addDocument(document);
   }
  
  private static Document getDocument(File file) throws IOException{
      Document document = new Document();

      //index file contents
      Field contentField = new Field(LuceneConstants.CONTENTS, 
         new FileReader(file));
      //index file name
      Field fileNameField = new Field(LuceneConstants.FILE_NAME,
         file.getName(),
         Field.Store.YES,Field.Index.NOT_ANALYZED);
      
//      System.out.println("File name:" + file.getName());
      //index file path
      Field filePathField = new Field(LuceneConstants.FILE_PATH,
         "amol",
         Field.Store.YES,Field.Index.NOT_ANALYZED);
      System.out.println("File Path:" + file.getParent());

      document.add(contentField);
      document.add(fileNameField);
      document.add(filePathField);

      return document;
   }  
}