package com.bt.commons;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

public class IndexGenerator {
	public static void main(String[] args) {
		 Long start = System.currentTimeMillis(); 

		String indexDirPath = "C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\v21";
		String date= "28_10_16";
		
		StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_36);
		
		File file[] = new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\02_10_16\\emsId-1002\\198738_646342")
				.listFiles();
		IndexerUtils indexerUtils = new IndexerUtils(); 
		Directory index;
		try {
			File flowFile = new File(indexDirPath+File.separator+date);

			index = FSDirectory.open(flowFile);

			IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_36, analyzer);

			IndexWriter w = new IndexWriter(index, config);

			 File[] flows = new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\02_10_16\\emsId-1002\\").listFiles();
			    for (int i = 0; i < flows.length; i++) {
					File xmls[] = flows[i].listFiles();
					
					for (int j = 0; j < xmls.length; j++) {
						indexerUtils.indexFile(xmls[0], w);
					}
				}
			
			/*for (int l = 0; l < file.length; l++) {
				indexerUtils.indexFile(file[0], w);
			}*/

			w.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    Long responseTime= System.currentTimeMillis()-start;
	    
	    System.out.println(indexerUtils.counter+" files indexed and time taken :"+responseTime);
	    
	   
	    
//		File file[] = new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\02_10_16\\emsId-1002\\198738_646342")
//				.listFiles();
//		IndexerUtils utils = new IndexerUtils();
//
//
//
//		for (int l = 0; l < file.length; l++) {
//			utils.createIndex("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\v21","28_10_16", file[l]);
//		}



	}
}
