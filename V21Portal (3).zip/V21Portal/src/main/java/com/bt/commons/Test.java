package com.bt.commons;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		File data = new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\");
		File responseXml=new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\03_10_16\\emsId-1003\32873_864650\\Response_Him_DSLM_54868344_92815897_05_Aug_16_18_38_36_703_147.xml");
		File requestXml=new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\03_10_16\\emsId-1003\32873_864650\\Request_Him_DSLM_54868344_92815863_05_Aug_16_18_38_29_702_146.xml");
		
		File dates[]=data.listFiles();
		List<String> dateList = new ArrayList<String>();
		for (int i = 0; i < 6; i++) {
			dateList.add(dates[i].getName());
		}
		
		for (String date : dateList) {
			new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\Huge Xmls\\"+date).mkdirs();
		}
		File flie2 = new File("C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\02_10_16");
	
		long start = System.currentTimeMillis();
		
		System.out.println(countFilesInDirectory(flie2));
		double total=System.currentTimeMillis()-start;
		System.out.println("Time taken: "+total/1000+"sec");
	}
	 public static int countFilesInDirectory(File directory) {
	      int count = 0;
	      for (File file : directory.listFiles()) {
	          if (file.isFile()) {
	              count++;
	            //  System.out.println(file.getName());
	          }
	          if (file.isDirectory()) {
	              count += countFilesInDirectory(file);
	          }
	      }
	      return count;
	  }


}
