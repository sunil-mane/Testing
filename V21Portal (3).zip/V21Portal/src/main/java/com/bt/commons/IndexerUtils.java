package com.bt.commons;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

import com.bt.lucene.LuceneConstants;

public class IndexerUtils {
	public int counter=0;
	public  void indexFile(File file,IndexWriter w) throws IOException{
//		System.out.println("Indexing "+file.getCanonicalPath());
		++counter;
		Document document = getDocument(file);
		w.addDocument(document);
	}

	private  Document getDocument(File file) throws IOException{
		Document document = new Document();

		//index file contents
		Field contentField = new Field(LuceneConstants.CONTENTS, 
				new FileReader(file));
		//index file name
		Field fileNameField = new Field(LuceneConstants.FILE_NAME,
				file.getName(),
				Field.Store.YES,Field.Index.NOT_ANALYZED);

		//	      System.out.println("File name:" + file.getName());
		//index file path
		Field filePathField = new Field(LuceneConstants.FILE_PATH,
				file.getParent(),
				Field.Store.YES,Field.Index.NOT_ANALYZED);
//		System.out.println("File Path:" + file.getParent());

		document.add(contentField);
		document.add(fileNameField);
		document.add(filePathField);

		return document;
	}  
	public void createIndex(String indexDirPath, String date,File xmlFile){
		StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_36);

		// 1. create the index
		Directory index;
		try {
			File flowFile = new File(indexDirPath+File.separator+date);

			index = FSDirectory.open(flowFile);

			IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_36, analyzer);

			IndexWriter w = new IndexWriter(index, config);

			indexFile(xmlFile, w);

			w.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
}
