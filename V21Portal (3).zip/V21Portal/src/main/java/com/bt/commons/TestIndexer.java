package com.bt.commons;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.lucene.Indexer;
import com.bt.lucene.LuceneTester;
import com.bt.services.V21Properties;
@Service
public class TestIndexer {

	@Autowired
	private V21Properties v21Properties;
	@Autowired
	private LuceneTester tester;
	@Autowired
	 static TestIndexer testIndexer;
	String dataDir ="dataDir=C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data";
	
	String error_1100="ems.ConnectionException AND errorDescription";
	String error_600_NGA="ActivityStatusType AND FAILURE";
	String error_600_DSLM="responseStatus AND failed";
	
	 
	public static void main(String[] args) {
		
		String path="C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data\\01_10_16";
		ArrayList< String> errorCodes = new ArrayList<String>();
		errorCodes.add("600");
		errorCodes.add("1100");
		
		List<String> fileList=testIndexer.searchErrorCodes1(errorCodes, path);
		System.out.println(fileList);
	}
	

	
	public List<String> searchErrorCodes1(List<String> errorCodes, String path) {
		String dataDir ="dataDir=C:\\Users\\611189996\\Desktop\\Sagar-Data\\Projects\\V21Portal\\V21 Docs\\archives_final_data";
		List<String> fileList=new ArrayList<String>();
		
		System.out.println("Inside method searchErrorCodes..."+errorCodes);
	
		try{
			dataDir=path;
			System.out.println("path received : "+path);
			tester.createIndex(dataDir);       

			List<String> errorfileList=new ArrayList<String>();
			// fileList.clear();

			for(String errorCode:errorCodes){
				System.out.println("errorCode : "+errorCode);

				if(errorCode.equals("1100")){
					System.out.println("Searching for error code 1100");			   

					tester.search(error_1100);
					// fileList=LuceneTester.fileList_first;
					List<String> fileListNew=new ArrayList<String>();

					fileListNew=LuceneTester.fileList_first;
					System.out.println("fileList_first in 1100: "+LuceneTester.fileList_first);

					for(String file:fileListNew){
						System.out.println("FileList in 1100--"+file);
						fileList.add(file);
					}

					System.out.println("fileList in 1100: "+fileList);

				}

				if(errorCode.equals("600")){

					System.out.println("Searching for error code 600" + error_600_NGA);
					errorfileList=tester.search(error_600_NGA);	
					// fileList=LuceneTester.fileList_first;
					System.out.println("errorfileList in 600_NGA: "+errorfileList);

					List<String> fileListNew=new ArrayList<String>();

					fileListNew=LuceneTester.fileList_first;
					System.out.println("fileList_first in 600_NGA: "+LuceneTester.fileList_first);

					for(String file:fileListNew){
						System.out.println("FileList in 600_NGA--"+file);

						fileList.add(file);
					}
					System.out.println("fileList in 600_NGA: "+fileList);


					// System.out.println("fileList size for erros "+fileList);
					for(String fileName:errorfileList){				
						if(!fileName.contains("_NGA")){
							for(int i=0;i<fileList.size();i++){
								if(fileList.get(i).equals(fileName)){
									fileList.remove(i);
								}

							}
						}

					}
					errorfileList.clear();
					tester.search(error_600_DSLM);	
					//fileList=LuceneTester.fileList_first;
					List<String> fileListNew1=new ArrayList<String>();

					fileListNew1=LuceneTester.fileList_first;
					System.out.println("fileList in 600_DSLM: "+LuceneTester.fileList_first);

					for(String file:fileListNew1){
						System.out.println("FileList in 600_DSLM--"+file);

						fileList.add(file);
					}
					System.out.println("fileList in 600_DSLM: "+fileList);

					for(String fileName:errorfileList){
						System.out.println("filename for error 1"+fileName);
						if(!fileName.contains("_Him_DSLM")){
							for(int i=0;i<fileList.size();i++){
								if(fileList.get(i).equals(fileName)){
									fileList.remove(i);
								}

							}
						}

					}			   
				}	
			}
		}
		catch(Exception e){
			e.printStackTrace();
			System.err.println("Exception occured inside method searchErrorCodes");
		}
		return fileList;
	}
}
