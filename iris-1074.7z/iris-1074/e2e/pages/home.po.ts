/**
   * Add specs for home page once ready
  */
