import { browser, by, element, $, $$ } from 'protractor';

/**
Application main landing page object
*/
export class AppPage {

  //#region Page Elements
  private searchInput = by.css('.top-header-search input');
  private searchButton = by.css('#searchBtn');
  private topNav = by.css('app-left-nav a');

  /**
   * Navigate to given page url
   */
  navigateTo() {
    return browser.get('/');
  }
  /**
   * Get title of page
   */
  getPageTitle() {
    return browser.getTitle();
  }
  /**
   * check if search button is displayed
   */
  checkSearchButtonDisplayed() {
    return element(this.searchButton).isDisplayed();
  }
  /**
   * check if search input is displayed
   */
  checkSearchInputDisplayed() {
    return element(this.searchInput).isDisplayed();
  }
  /**
   * get the active link from leftnav
   */
  getActiveLink() {
    return element(this.topNav).getText();
  }
  /**
   * Get all leftnav items
   */
  getLeftNavItems() {
    return element.all(this.topNav);
  }
}
