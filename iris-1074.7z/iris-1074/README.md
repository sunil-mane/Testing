# Data Platform IRIS Front-end Application

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.7.4.

## Add Dodge package registry to npm server

Run `npm config set @dodge:registry http://artifactory.construction.com/artifactory/api/npm/libs-npm/` for adding dodge in local npm manager then run `npm cache clear --force` to clear cache and then delete the `node_modules` folder and run `npm install`.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running mock server

Run `npm run mock-server` to start the mock server.

## Running application in development and connect to mock server via proxy 

Run `npm run mock` to start application in develoment mode and connect to mock server api via proxy.

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
