import { times, orderBy } from 'lodash';
import * as faker from 'faker';
import { BaseMock } from './baseMock';
import { Cacher } from './cacher';

export class Disposition extends BaseMock {

  static getProjects(req, total = 25) {
    let projects = this.createProjects(req, total);

    const mockedParams = this.setupMockedParams(req, total);

    if (mockedParams.sort) {
      projects = orderBy(projects, [mockedParams.sort.by], [mockedParams.sort.order]);
    }
    if (mockedParams.pagination) {
      mockedParams.successObj.data.projects = projects.slice(mockedParams.offset, (mockedParams.offset + mockedParams.count));
    } else {
      mockedParams.successObj.data.projects = projects;
    }
    return mockedParams.successObj;
  }

  static createProjects(req, total) {
    let projects = Cacher.get(req.url);

    if (!projects) {
      projects = times(total, () => {
        return {
          processDate: faker.date.past(),
          fileName: faker.system.fileName('', ''),
          feedName: faker.lorem.words(),
          recordId: faker.random.number({ min: 1000000000, max: 9999999999 }),
          projectTitle: faker.company.companyName(),
          reason: faker.lorem.words(),
          comment: faker.lorem.sentences(),
          state: faker.address.state(),
          discard: faker.date.past(),
          discardedBy: faker.name.firstName(),
        };
      });

      Cacher.add(req.url, projects);
    }

    return projects;
  }
}

