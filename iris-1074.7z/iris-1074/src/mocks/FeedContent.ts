import { times, orderBy } from 'lodash';
import * as faker from 'faker';
import { BaseMock } from './baseMock';
import { Cacher } from './cacher';

export class FeedContent extends BaseMock {

  static getFeedContent(req, total = 25) {
    let feedContent = this.createFeedContent(req, total);

    const mockedParams = this.setupMockedParams(req, total);

    if (mockedParams.sort) {
      feedContent = orderBy(feedContent, [mockedParams.sort.by], [mockedParams.sort.order]);
    }

    if (mockedParams.pagination) {
      mockedParams.successObj.data.feeds = feedContent.slice(mockedParams.offset, (mockedParams.offset + mockedParams.count));
    } else {
      mockedParams.successObj.data.feeds = feedContent;
    }
    return mockedParams.successObj;
  }

  static createFeedContent(req, total) {
    let feeds = Cacher.get(req.url);

    if (!feeds) {
      feeds = times(total, () => {
        return {
          id: faker.random.number({ min: 1000000000, max: 9999999999 }),
          fileId: faker.random.number({ min: 10000, max: 99999 }),
          title: faker.company.companyName(),
          errorText: null,
          routeStatus: faker.random.arrayElement(['Pushed to infACT', 'Rerouted']),
          pushed: faker.random.arrayElement(['Y', 'N']),
          processDate: faker.date.past(),
          country: faker.address.country(),
          state: faker.address.state(),
          county: faker.address.county(),
          owner: faker.name.firstName() + ', ' + faker.name.lastName(),
          recordId: faker.random.number({ min: 1000000000, max: 9999999999 }),
          submissionDate: faker.date.past(),
          preBidDate: faker.date.past(),
          projectStage: faker.random.arrayElement(['Pre-Design', 'Design', 'Construction', 'Bidding', 'Delayed', 'Abandoned']),
          discardReasonId: ''
        };
      });

      Cacher.add(req.url, feeds);
    }

    return feeds;
  }

  static getDRNumber() {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': 1,
          'start': 1,
          'total': 1
        },
        'drnumber': faker.random.number()
      }
    };
    return successObj;
  }

  static getFeedDetails() {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'project': {
          'description': faker.random.words(70),
          'title': 'Recovery - Timber Ridge Lake Improvements On Wayne Nf',
          'number': 'AG-24H8-S-10-0298',
          'type': '32423',
          'recordId': 'FEDBIZ_MHC_2009_12_53614',
          'reportNumber': null,
          'reportType': null,
          'originalRegion': '42',
          'currentRegion': '42',
          'routedBy': null,
          'valuation': null,
          'contractNumber': null,
          'deliverySystem': null,
          'ownerType': null,
          'stage': 'PRESOLICITATION / CANCELLED',
          'status': null,
          'remarks': 'Recovery',
          'exception': null,
          'contractAwardees': null,
          'location': {
            'address1': faker.address.streetAddress(),
            'address2': null,
            'address3': null,
            'city': faker.address.city(),
            'county': faker.address.country(),
            'state': faker.address.state(true),
            'country': faker.address.countryCode(),
            'zip': faker.address.zipCode()
          },
          'date': {
            'awardDate': null,
            'advertise': '12/10/2009',
            'submission': '01/27/2010',
            'submissionTime': null
          }
        },
        'biddingInformation': {
          'bid': {
            'bidDate': null,
            'bidTime': null,
            'submitBidTo': null
          },
          'preBid': {
            'preBidMeeting': null,
            'date': null,
            'time': null
          },
          'target': {
            'bidDate': null,
            'startDate': null,
            'completionDate': null
          }
        },
        'additionalInformation': {
          'typeOfWork': null,
          'additionalInfo1': null,
          'additionalInfo2': null,
          'additionalInfo3': null,
          'additionalInfo4': null,
          'bond': {
            'bid': null,
            'performance': null,
            'payment': null,
            'remark': null
          }
        },
        'details': {
          'noOfBuilding': null,
          'noOfStoriesAboveGrade': null,
          'noOfStoriesBelowGrade': null,
          'totalSquareFeet': null,
          'buildingFrame': null,
          'storeNumber': null,
          'url': {
            'pageUrl': faker.internet.url(),
            'otherUrl2': faker.internet.url(),
            'otherUrl3': faker.internet.url(),
            'otherUrl4': null
          },
          'plan': {
            'addenda': null,
            'deposit': null,
            'planReleaseDate': null,
            'planAvailableFrom': null,
            'planRemark': null
          },
          'category1': `Z -- Maintenance, Repair, And Alteration Of Real Property Naics Code: 237 --
                        Heavy And Civil Engineering Construction/237990 -- Other Heavy And Civil Engineering Construction`,
          'category2': null,
          'category3': null
        },
        'contactDetails': [
          {
            'name': 'Forest Service Location: Eroc East',
            'address1': null,
            'address2': null,
            'address3': null,
            'city': null,
            'state': null,
            'contact': 'Melissa A Conn Mconn@Fs.Fed.Us Phone: 814-728-6241 Fax: 814-726-1465',
            'phone': faker.phone.phoneNumber(),
            'fax': faker.phone.phoneNumber(),
          }
        ],
        'lastUpdatedOn': null
      }
    };
    return successObj;
  }
}
