import { times } from 'lodash';
import * as faker from 'faker';

export class Lookups {

  static getValuation(count) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metadata': {
          'count': count,
          'start': 1,
          'total': count
        },
        'valuations': null
      }
    };

    successObj.data.valuations = times(count, function () {
      return {
        'id': faker.random.arrayElement(['N', 'M', 'L', 'K', 'J', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A']),
        'low': faker.random.number({ min: 0, max: 50000000 }),
        'high': faker.random.number({ min: 99999, max: 999999999999999 })
      };
    });
    return successObj;
  }

  static getCountry() {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': 9,
          'start': 1,
          'total': 9
        },
        'countries': [
          { 'id': 'USA', 'name': 'UNITED STATES OF AMERICA' },
          { 'id': 'CAN', 'name': 'CANADA' },
          { 'id': 'MEX', 'name': 'MEXICO' },
          { 'id': 'PRI', 'name': 'PUERTO RICO' },
          { 'id': 'VIR', 'name': 'VIRGIN ISLANDS' },
          { 'id': 'GUM', 'name': 'GUAM' },
          { 'id': 'AFG', 'name': 'AFGHANISTAN' },
          { 'id': 'AUS', 'name': 'AUSTRALIA' },
          { 'id': 'BRA', 'name': 'BRAZIL' }
        ]
      }
    };

    return successObj;
  }

  static getStates(id) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metadata': {
          'count': 51,
          'start': 1,
          'total': 51
        },
        'states': null
      }
    };

    successObj.data.states = times(51, function () {
      return {
        'id': id + faker.address.stateAbbr(),
        'code': faker.address.stateAbbr(),
        'name': faker.address.state()
      };
    });

    return successObj;
  }

  static getCities(id) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metadata': {
          'count': 51,
          'start': 1,
          'total': 51
        },
        'states': [{
          'id': id + faker.address.stateAbbr(),
          'name': faker.address.state(),
          'cities': null
        }]
      }
    };

    successObj.data.states[0].cities = times(51, function () {
      return {
        'name': faker.address.city()
      };
    });

    return successObj;
  }

  static getCounties(id) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metadata': {
          'count': 51,
          'start': 1,
          'total': 51
        },
        'states': [{
          'id': id + faker.address.stateAbbr(),
          'name': faker.address.state(),
          'counties': null
        }]
      }
    };

    successObj.data.states[0].counties = times(51, function () {
      return {
        'id': id + faker.random.number(51),
        'name': faker.address.city()
      };
    });

    return successObj;
  }

  static getCompanyType(count = 51) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metadata': {
          'count': count,
          'start': 1,
          'total': count
        },
        'companyTypes': null
      }
    };

    successObj.data.companyTypes = times(count, function () {
      return {
        'id': faker.random.number(count),
        'name': faker.commerce.productName()
      };
    });

    return successObj;
  }

  static getProjectStage(count = 6) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metadata': {
          'count': count * 3,
          'start': 1,
          'total': count * 3
        },
        'stages': null
      }
    };

    successObj.data.stages = times(count, function () {
      return {
        'id': faker.random.number(count),
        'name': faker.commerce.product(),
        'stage': null
      };
    });


    successObj.data.stages.forEach((element) => {
      element.stage = times(3, () => {
        return {
          'id': faker.random.number(20),
          'name': faker.commerce.color()
        };
      });
    });
    return successObj;
  }

  static getProjectType(count = 6) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metadata': {
          'count': count * 3,
          'start': 1,
          'total': count * 3
        },
        'types': null
      }
    };

    successObj.data.types = times(count, function () {
      return {
        'code': faker.random.number(count),
        'name': faker.commerce.product(),
        'subtypes': null
      };
    });

    successObj.data.types.forEach((element) => {
      element.subtypes = times(3, () => {
        return {
          'code': faker.random.number(20),
          'name': faker.commerce.productName(),
          'subtypes': null
        };
      });
      element.subtypes.forEach((subelement) => {
        subelement.subtypes = times(3, () => {
          return {
            'code': faker.random.number(20),
            'name': faker.commerce.productName(),
            'subtypes': faker.commerce.productName()
          };
        });
      });
    });
    return successObj;
  }

  static getCompanies(id) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': 2,
          'start': 1,
          'total': 2
        },
        'companies': null
      }
    };
    successObj.data.companies = times(5, function () {
      return {
        'projectNumber': faker.finance.account(6),
        'version': faker.random.number(10),
        'title': faker.random.words(3),
        'titleCode': faker.random.word(),
        'contractRole': faker.random.word(),
        'bidderType': faker.random.word(),
        'bidderCode': faker.random.number(1000),
        'name': faker.commerce.department(),
        'contactName': faker.name.firstName() + faker.name.lastName(),
        'addressLine1': faker.address.streetAddress(false),
        'addressLine2': null,
        'state': faker.address.stateAbbr(),
        'city': faker.address.city(),
        'county': faker.address.county(),
        'phone': faker.phone.phoneNumber(),
        'fax': faker.phone.phoneNumber(),
        'email': faker.internet.email(),
        'website': faker.internet.domainSuffix(),
        'sortOrder': faker.random.number(10)
      };
    });
    return successObj;
  }

  static getFeeds() {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': 3,
          'start': 1,
          'total': 3
        },
        'feeds': [
          {
            'id': '168',
            'name': 'BIDDERS'
          },
          {
            'id': '1',
            'name': 'REGULAR'
          },
          {
            'id': '21',
            'name': 'FEDERAL'
          }
        ]
      }
    };

    return successObj;
  }

  static getRegions() {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': 3,
          'start': 1,
          'total': 3
        },
        'regions': [
          {
            'id': 4735,
            'name': 'CENTRAL'
          },
          {
            'id': 44,
            'name': 'CN'
          },
          {
            'id': 4715,
            'name': 'EAST'
          },
          {
            'id': 15,
            'name': 'ERROR'
          }
        ]
      }
    };

    return successObj;
  }

  static getReporters() {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': 3,
          'start': 1,
          'total': 3
        },
        'reporters': times(5, function () {
          return {
            'id': faker.finance.account(6),
            'description': faker.lorem.words(5),
            'managerId': faker.finance.account(6),
            'user': faker.name.firstName(6),
            'type': faker.finance.account(4),
            'region': faker.random.number(99),
            'isManager': 'Y'
          };
        })
      }
    };

    return successObj;
  }

  static getDispositionReasons() {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': 3,
          'start': 1,
          'total': 3
        },
        'dispositions': times(5, function () {
          return {
            'id': faker.finance.account(6),
            'description': faker.lorem.words(5)
          };
        })
      }
    };

    return successObj;
  }
}
