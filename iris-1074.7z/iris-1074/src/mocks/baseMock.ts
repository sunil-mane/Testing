export class BaseMock {

  static setupMockedParams(req, total) {
    let count = 0;
    let start = 1;
    let offset = 0;
    let sort: any = null;

    let successObj: any = {};
    let pagination = false;

    if (req.body) {
      if (req.body.pagination) {
        count = req.body.pagination.limit;
        offset = req.body.pagination.offset;
        start = req.body.pagination.offset + 1;
        pagination = true;
      }

      if (req.body.sort) {
        sort = req.body.sort;
      }
    }

    successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': count,
          'start': start,
          'total': total
        }
      }
    };

    return {
      pagination: pagination,
      successObj: successObj,
      offset: offset,
      count: count,
      sort: sort
    };
  }


}

