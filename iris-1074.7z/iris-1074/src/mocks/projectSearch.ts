import { times, orderBy } from 'lodash';
import * as faker from 'faker';
import { Cacher } from './cacher';
import { BaseMock } from './baseMock';

export class ProjectSearch extends BaseMock {

  static getProjects(req, total = 25) {
    let projects = this.createProjects(req, total);

    const mockedParams = this.setupMockedParams(req, total);

    if (mockedParams.sort) {
      projects = orderBy(projects, [mockedParams.sort.by], [mockedParams.sort.order]);
    }
    if (mockedParams.pagination) {
      mockedParams.successObj.data.projects = projects.slice(mockedParams.offset, (mockedParams.offset + mockedParams.count));
    } else {
      mockedParams.successObj.data.projects = projects;
    }
    return mockedParams.successObj;
  }

  static createProjects(req, total) {
    let projects = Cacher.get(req.url);

    if (!projects) {
      projects = times(total, () => {
        return {
          id: faker.random.number({min: 1000000000, max: 9999999999}),
          architectName: faker.name.firstName() + ', ' + faker.name.lastName(),
          bidDate: faker.date.past(),
          city: faker.address.city(),
          gcName: null,
          issuedDate: faker.date.past(),
          name: faker.company.companyName(),
          ownerName: faker.name.firstName() + ', ' + faker.name.lastName(),
          stage: faker.random.arrayElement(['Pre-Design', 'Design', 'Construction', 'Bidding', 'Delayed', 'Abandoned']),
          state: faker.address.state(),
          street: faker.address.streetAddress(),
          valuation: {
            low: faker.random.number({min: 1000000000, max: 9999999999}),
            high: faker.random.number({min: 1000000000, max: 9999999999})
          },
          version: faker.random.number({min: 1, max: 9})
        };
      });

      Cacher.add(req.url, projects);
    }

    return projects;
  }

}
