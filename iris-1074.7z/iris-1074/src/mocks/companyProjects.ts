import { times } from 'lodash';
import * as faker from 'faker';

export class CompanyProjects {

  static getProjects(count = 25) {
    const successObj = {
      'status': 'success',
      'code': 200,
      'data': {
        'metaData': {
          'count': count,
          'start': 1,
          'total': count
        },
        'projects': null
      }
    };

    successObj.data.projects = times(count, () => {
      return {
        title: faker.company.companyName(),
        stage: faker.random.arrayElement(['Pre-Design', 'Design', 'Construction', 'Bidding', 'Delayed', 'Abandoned']),
        projectNumber: faker.random.number({ min: 1000000000, max: 9999999999 }),
        valuation: faker.random.number({ min: 1000000000, max: 9999999999 }),
        bidDate: faker.date.past(),
        role: faker.random.arrayElement(['Contractor', 'Architect', 'Designer']),
        addressLine1: faker.address.streetAddress(),
        addressLine12: faker.address.secondaryAddress(),
        city: faker.address.city(),
        county: faker.address.county(),
        state: faker.address.state(),
        zipCode: faker.address.zipCode(),
        lastIssueDate: faker.date.past(),
      };
    });

    return successObj;
  }
}
