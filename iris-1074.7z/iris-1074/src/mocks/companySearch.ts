import { times, orderBy } from 'lodash';
import * as faker from 'faker';
import { BaseMock } from './baseMock';
import { Cacher } from './cacher';

export class CompanySearch extends BaseMock {
  static getCompanies(req, total = 25) {
    let companies = this.createCompanies(req, total);

    const mockedParams = this.setupMockedParams(req, total);

    if (mockedParams.sort) {
      companies = orderBy(companies, [mockedParams.sort.by], [mockedParams.sort.order]);
    }

    if (mockedParams.pagination) {
      mockedParams.successObj.data.companies = companies.slice(mockedParams.offset, (mockedParams.offset + mockedParams.count));
    } else {
      mockedParams.successObj.data.companies = companies;
    }
    return mockedParams.successObj;

  }

  static createCompanies(req, total) {
    let companies = Cacher.get(req.url);
    if (!companies) {
      companies = times(total, () => {
        return {
          id: faker.random.number({ min: 1000000000, max: 9999999999 }),
          name: faker.company.companyName(),
          version: faker.random.number({ min: 1, max: 9 }),
          code: faker.random.number({ min: 10000, max: 99999 }),
          state: faker.address.state(),
          street: faker.address.streetAddress(),
          city: faker.address.city(),
          phone: faker.phone.phoneNumber(),
          contact: {
            name: faker.name.firstName() + ' ' + faker.name.lastName(),
            email: faker.internet.email()
          },
          type: faker.name.jobType(),
          isSource: faker.random.boolean(),
          isSpecialSource: faker.random.boolean(),
          companies: null
        };
      });

      Cacher.add(req.url, companies);
    }

    return companies;

  }
}
