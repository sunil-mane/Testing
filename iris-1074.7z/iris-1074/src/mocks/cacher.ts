import { find, findIndex } from 'lodash';

export class Cacher {

  static cached = [];

  static add(url, obj) {
    if (obj && url) {
      this.cached.push({url: url, obj: obj});
    }
  }

  static remove(url) {
    const index = findIndex(this.cached, (item) => {
      return item.url === url;
    });

    return this.cached.splice(index);
  }

  static get(url) {
    const obj1 = find(this.cached, (item) => {
      return item.url === url;
    });

    return (obj1 ? obj1.obj : obj1);
  }
}
