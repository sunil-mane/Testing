import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './shared/guards/auth.guard';

import { MainComponent } from './main/main.component';
import { DashboardComponent } from './dashboard/dashboard.component';

/**
const routes: Routes = [
  { path: 'projects', loadChildren: './projects/projects.module#ProjectsModule', canActivate: [AuthGuard] },
  { path: 'companies', loadChildren: './companies/companies.module#CompaniesModule', canActivate: [AuthGuard] },
  { path: '', redirectTo: '/projects/search', pathMatch: 'full', canActivate: [AuthGuard]  },
  { path: 'login', component: LoginComponent },
  { path: '**', loadChildren: './errors/errors.module#ErrorsModule' }
];
**/

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '',
    component: MainComponent,
    canActivate: [],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
      { path: 'projects', loadChildren: './projects/projects.module#ProjectsModule' },
      { path: 'companies', loadChildren: './companies/companies.module#CompaniesModule' },
      { path: 'feed', loadChildren: './feed-content/feed-content.module#FeedContentModule' }
    ]
  },
  { path: '**', loadChildren: './errors/errors.module#ErrorsModule' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
