import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../shared/shared.module';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from '../../reducers';
import { FeedProjectInformationComponent } from './feed-project-information.component';
import { TreeviewModule } from 'ngx-treeview';

describe('FeedProjectInformationComponent', () => {
  let component: FeedProjectInformationComponent;
  let fixture: ComponentFixture<FeedProjectInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), RouterTestingModule, HttpClientTestingModule, TreeviewModule.forRoot(),
      StoreModule.forRoot(reducers, { metaReducers })],
      providers: [LocationStrategy, PathLocationStrategy, NgbActiveModal],
      declarations: [FeedProjectInformationComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedProjectInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
