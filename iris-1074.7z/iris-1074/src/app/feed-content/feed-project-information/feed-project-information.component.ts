import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { FeedProjectData } from '../../shared/models/FeedProjectDetail';
import * as feedContentSelector from '../../shared/store/feed-content/feed-content.reducer';
import { isEmpty } from 'lodash';
import { AppState } from '../../shared/store/app-state';

@Component({
  selector: 'app-feed-project-information',
  templateUrl: './feed-project-information.component.html',
  styleUrls: ['./feed-project-information.component.scss']
})
export class FeedProjectInformationComponent implements OnInit, OnDestroy {
  /** Project Detail Object */
  projectDetails: FeedProjectData;

  /** Store Subscription */
  feedContentStoreSubscription: Subscription;

  constructor(public store: Store<AppState>) {
    this.projectDetails = null;
  }

  ngOnInit() {
    this.feedContentStoreSubscription = this.store.select(feedContentSelector.selectFeedContent).subscribe(
      (feed) => {
        if (!isEmpty(feed.value)) {
          this.projectDetails = feed.value;
        }
      }
    );
  }

  ngOnDestroy() {
    if (this.feedContentStoreSubscription) {
      this.feedContentStoreSubscription.unsubscribe();
    }
  }
}
