import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../shared/shared.module';
import { TreeviewModule } from 'ngx-treeview';
import { APP_BASE_HREF } from '@angular/common';
import { QualificationMatchedComponent } from './qualification-matched.component';

describe('QualificationMatchedComponent', () => {
  let component: QualificationMatchedComponent;
  let fixture: ComponentFixture<QualificationMatchedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), TreeviewModule.forRoot(), RouterTestingModule, HttpClientTestingModule],
      declarations: [QualificationMatchedComponent],
      providers: [{ provide: LocationStrategy, useClass: PathLocationStrategy },
      { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualificationMatchedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
