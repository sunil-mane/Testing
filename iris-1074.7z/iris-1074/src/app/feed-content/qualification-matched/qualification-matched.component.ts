import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qualification-matched',
  templateUrl: './qualification-matched.component.html',
  styleUrls: ['./qualification-matched.component.scss']
})
export class QualificationMatchedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
