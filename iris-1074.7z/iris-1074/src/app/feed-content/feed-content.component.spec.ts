import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LocationStrategy, PathLocationStrategy, Location } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../shared/shared.module';
import { TreeviewModule } from 'ngx-treeview';
import { FeedContentComponent } from './feed-content.component';
import { APP_BASE_HREF } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from '../reducers';

describe('FeedContentComponent', () => {
  let component: FeedContentComponent;
  let fixture: ComponentFixture<FeedContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), TreeviewModule.forRoot(),
        RouterTestingModule, HttpClientTestingModule, StoreModule.forRoot(reducers, { metaReducers })],
      declarations: [FeedContentComponent],
      providers: [{ provide: LocationStrategy, useClass: PathLocationStrategy },
      { provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
