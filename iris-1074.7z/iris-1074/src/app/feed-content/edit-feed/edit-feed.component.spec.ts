import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../shared/shared.module';
import { TreeviewModule } from 'ngx-treeview';

import { EditFeedComponent } from './edit-feed.component';

describe('EditFeedComponent', () => {
  let component: EditFeedComponent;
  let fixture: ComponentFixture<EditFeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), TreeviewModule.forRoot(), RouterTestingModule, HttpClientTestingModule],
      providers: [LocationStrategy, PathLocationStrategy, NgbActiveModal],
      declarations: [EditFeedComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
