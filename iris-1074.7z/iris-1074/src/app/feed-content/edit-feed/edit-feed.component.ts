import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-feed',
  templateUrl: './edit-feed.component.html',
  styleUrls: ['./edit-feed.component.scss']
})
export class EditFeedComponent {
  /** page Identifier */
  pageIdentifier: string;

  /** Back route */
  backRoute: string;

  constructor(private activatedRoute: ActivatedRoute, private router: Router) {
    this.activatedRoute.paramMap.subscribe((params) => {
      const feedId = params.get('id');
      this.backRoute = '/feed/' + feedId + '/qualification/matched';
    });

    this.pageIdentifier = (this.router.url.endsWith('edit')) ? 'editFeed' : (this.router.url.endsWith('create')) ? 'createFeedProject' : '';
  }

}
