import { Component } from '@angular/core';
import { LeftSidebarService } from '../shared/services/left-sidebar.service';
import { GridColumn } from '../shared/models/GridColumn';
import { PageTabNavigation } from '../shared/models/PageTabNavigation';

@Component({
  selector: 'app-disposition',
  templateUrl: './disposition.component.html',
  styleUrls: ['./disposition.component.scss']
})
/**
 * Feed disposition component
 */
export class DispositionComponent {

  /** Page indetifier used by left sidebar and grid action buttons component */
  pageIdentifier: string;

  /** Grid column settings */
  columns: GridColumn[] = [];

  /** Tab Configuration */
  pageTabs: PageTabNavigation[];

  constructor(public leftSidebarService: LeftSidebarService) {
    this.pageIdentifier = 'disposition';
    this.columns = [
      { name: 'DATE', name2: 'DATE', prop: 'processDate', isVisible: true, type: 'date', sortable: true, width: 100 },
      { name: 'FILE NAME', name2: 'FILE NAME', prop: 'fileName', isVisible: true, sortable: true },
      { name: 'FEED NAME', name2: 'FEED NAME', prop: 'feedName', isVisible: true, sortable: true },
      { name: 'RECORD IDENTIFIER', name2: 'RECORD IDENTIFIER', prop: 'recordId', isVisible: true, sortable: true },
      {
        name: 'PROJECT TITTLE', name2: 'PROJECT TITTLE', prop: 'projectTitle', isVisible: true,
        sortable: true, type: 'feedTitle', width: 500
      },
      { name: 'STATE', name2: 'STATE', prop: 'state', isVisible: true, sortable: true, width: 80 },
      { name: 'REASON', name2: 'REASON', prop: 'reason', isVisible: true, sortable: true },
      { name: 'COMMENTS', name2: 'COMMENTS', prop: 'comment', isVisible: true, sortable: false },
      { name: 'DISCARD DATE', name2: 'DISCARD DATE', prop: 'discard', isVisible: true, type: 'date', sortable: true, width: 100 },
      { name: 'DISCARDED BY', name2: 'DISCARDED BY', prop: 'discardedBy', isVisible: true, sortable: true }
    ];
    /** Page Tab Configuration */
    this.pageTabs = [
      { label: 'Feed Content', route: ['/feed/content'] },
      { label: 'Disposition', route: ['/feed/disposition'] }
    ];
  }

}
