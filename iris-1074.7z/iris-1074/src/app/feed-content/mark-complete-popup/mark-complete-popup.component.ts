import { Component, Output, EventEmitter, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { GridColumn } from '../../shared/models/GridColumn';
import { BaseFormGroup } from '../../shared/forms/base-form-group';
import { SumoLoggerService } from '../../shared/services/sumo-logger.service';
import { AlertService } from '../../shared/services/alert.service';
import { LeftSidebarService } from '../../shared/services/left-sidebar.service';
import { LookupApiService } from '../../shared/services/lookup-api.service';
import { BaseFormControl } from '../../shared/forms/base-form-control';
import { isNil, isString, isObject, isArray, remove, get, isEqual, isEmpty } from 'lodash';

/**
 * Mark complete project popup component
 * This component will be used with bootstrap popup service and return selected value when popup is closed.
 */

@Component({
  selector: 'app-mark-complete-popup',
  templateUrl: './mark-complete-popup.component.html',
  styleUrls: ['./mark-complete-popup.component.scss']
})
export class MarkCompletePopupComponent implements OnInit {

  reasonColumns: GridColumn[];
  reasons = [];
  // reroute Info Form
  markCompleteProjectBaseForm: BaseFormGroup;
  sourceControl: BaseFormControl;
  sourceTypeControlSubscription: Subscription;
  // dr number which will be sent if single item is selected in grid
  public DRNumber = 0;
  constructor(private logger: SumoLoggerService, private alertService: AlertService, public leftSidebarService: LeftSidebarService,
    private lookupApiService: LookupApiService, public activeModal: NgbActiveModal) {
    // reporter dropdown config
    this.reasonColumns = [
      { name: 'REASON', prop: 'description' }
    ];
    this.markCompleteProjectBaseForm = new BaseFormGroup('markCompleteProjectBaseForm', {
      dispositionId: new FormControl('', [], []),
      comment: new FormControl('', [], [])
    });
  }

  ngOnInit() {
    this.getReasons();
    if (this.DRNumber !== 0) {
      this.markCompleteProjectBaseForm.get('comment').setValue(this.DRNumber.toString());
    }
  }
  /**
   * Submit form action
   */
  submitForm() {
    const markFeedData = this.markCompleteProjectBaseForm.value;
    if (markFeedData.dispositionId) {
      this.activeModal.close(markFeedData);
    }
  }
  /**
   * Regions lookup api call
   */
  getReasons() {
    this.lookupApiService.getDispostionReasons().subscribe(
      (res) => {
        this.reasons = res.data.dispositions;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
}
