import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../shared/shared.module';
import { TreeviewModule } from 'ngx-treeview';

import { MarkCompletePopupComponent } from './mark-complete-popup.component';

describe('MarkCompletePopupComponent', () => {
  let component: MarkCompletePopupComponent;
  let fixture: ComponentFixture<MarkCompletePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), TreeviewModule.forRoot(), RouterTestingModule, HttpClientTestingModule],
      providers: [LocationStrategy, PathLocationStrategy, NgbActiveModal],
      declarations: [MarkCompletePopupComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkCompletePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
