import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../shared/shared.module';
import { TreeviewModule } from 'ngx-treeview';
import { APP_BASE_HREF } from '@angular/common';
import { QualificationToolComponent } from './qualification-tool.component';
import { FeedProjectInformationComponent } from '../feed-project-information/feed-project-information.component';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from '../../reducers';

describe('QualificationToolMatchedComponent', () => {
  let component: QualificationToolComponent;
  let fixture: ComponentFixture<QualificationToolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), TreeviewModule.forRoot(),
        RouterTestingModule, HttpClientTestingModule, StoreModule.forRoot(reducers, { metaReducers })],
      declarations: [QualificationToolComponent, FeedProjectInformationComponent],
      providers: [{ provide: LocationStrategy, useClass: PathLocationStrategy },
      { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualificationToolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
