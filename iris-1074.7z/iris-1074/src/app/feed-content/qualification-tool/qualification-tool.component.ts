import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PageTabNavigation } from '../../shared/models/PageTabNavigation';
import { ApiService } from '../../shared/services/api.service';
import { FeedProjectDetails, FeedProjectDetailsResponse, FeedProjectOtherDetails } from '../../shared/models/FeedProjectDetail';
import { SumoLoggerService } from '../../shared/services/sumo-logger.service';
import { Store } from '@ngrx/store';
import { AppState } from '../../shared/store/app-state';
import * as feedContentActions from '../../shared/store/feed-content/feed-content.actions';

@Component({
  selector: 'app-qualification-tool',
  templateUrl: './qualification-tool.component.html',
  styleUrls: ['./qualification-tool.component.scss']
})
export class QualificationToolComponent {
  pageIdentifier = 'feedDetails';
  pageContentTabConfig: PageTabNavigation[];
  feedId: string;
  constructor(private activatedRoute: ActivatedRoute, private apiService: ApiService, private logger: SumoLoggerService,
    public store: Store<AppState>) {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.feedId = params.get('id');
      this.getFeedProjectDetails(parseInt(this.feedId, 0));
      this.pageContentTabConfig = [
        { label: 'Matched', route: ['/feed/' + this.feedId + '/qualification/matched'] },
        { label: 'Project Search', route: ['/feed/' + this.feedId + '/qualification/projects'] }
      ];
    });
  }
  /**
   * get feed project details api call
   */
  getFeedProjectDetails(feedNumber: number) {
    this.apiService.get(`feed/${feedNumber}`).subscribe(
      (res: FeedProjectDetailsResponse) => {
        this.store.dispatch(new feedContentActions.SaveFeedContentAction({ name: this.pageIdentifier, value: res.data }));
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
}
