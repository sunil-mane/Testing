import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { FeedContentComponent } from './feed-content.component';
import { DispositionComponent } from './disposition.component';
import { RerouteProjectPopupComponent } from './reroute-project-popup/reroute-project-popup.component';
import { MarkCompletePopupComponent } from './mark-complete-popup/mark-complete-popup.component';
import { QualificationToolComponent } from './qualification-tool/qualification-tool.component';
import { QualificationMatchedComponent } from './qualification-matched/qualification-matched.component';
import { QualificationProjectsComponent } from './qualification-projects/qualification-projects.component';
import { FeedProjectInformationComponent } from './feed-project-information/feed-project-information.component';
import { EditFeedComponent } from './edit-feed/edit-feed.component';
/**
 * Routes inside feed content module
 */
const routes: Routes = [
  { path: '', redirectTo: 'content', pathMatch: 'full' },
  { path: 'content', component: FeedContentComponent },
  { path: 'disposition', component: DispositionComponent },
  {
    path: ':id/qualification',
    component: QualificationToolComponent,
    children: [
      { path: 'matched', component: QualificationMatchedComponent },
      { path: 'projects', component: QualificationProjectsComponent },
    ]
  },
  { path: ':id/edit', component: EditFeedComponent },
  { path: ':id/create', component: EditFeedComponent }
];
/**
 * Feed Content Module
 */
@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [FeedContentComponent, DispositionComponent, RerouteProjectPopupComponent, MarkCompletePopupComponent,
    QualificationToolComponent, QualificationMatchedComponent, QualificationProjectsComponent, EditFeedComponent,
    FeedProjectInformationComponent],
  entryComponents: [RerouteProjectPopupComponent, MarkCompletePopupComponent]
})

export class FeedContentModule { }
