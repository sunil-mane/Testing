import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../shared/shared.module';
import { TreeviewModule } from 'ngx-treeview';
import { APP_BASE_HREF } from '@angular/common';
import { QualificationProjectsComponent } from './qualification-projects.component';
import { LeftSidebarService } from '../../shared/services/left-sidebar.service';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from '../../reducers';

describe('QualificationProjectsComponent', () => {
  let component: QualificationProjectsComponent;
  let fixture: ComponentFixture<QualificationProjectsComponent>;
  let leftSidebarService: LeftSidebarService;
  let identifier: string;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), TreeviewModule.forRoot(),
        RouterTestingModule, HttpClientTestingModule, StoreModule.forRoot(reducers, { metaReducers })],
      declarations: [QualificationProjectsComponent],
      providers: [{ provide: LocationStrategy, useClass: PathLocationStrategy },
      { provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();

    fixture = TestBed.createComponent(QualificationProjectsComponent);
    component = fixture.componentInstance;
    leftSidebarService = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'projectSearch';
    leftSidebarService.initMainForm('projectSearch');
    fixture.detectChanges();
  }));

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
