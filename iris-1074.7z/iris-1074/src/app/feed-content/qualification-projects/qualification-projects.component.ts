import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { GridColumn } from '../../shared/models/GridColumn';
import { LeftSidebarService } from '../../shared/services/left-sidebar.service';
import { LeftSidebarComponent } from '../../shared/components/left-sidebar/left-sidebar.component';
import { GridComponent } from '../../shared/components/grid/grid.component';

@Component({
  selector: 'app-qualification-projects',
  templateUrl: './qualification-projects.component.html',
  styleUrls: ['./qualification-projects.component.scss']
})
export class QualificationProjectsComponent implements OnInit, OnDestroy {
  /** Grid column settings */
  columns: GridColumn[] = [];

  /** Column information to show on mouse over */
  information: GridColumn[] = [];

  /** External pagination flag */
  externalPaging: boolean;

  /** Left Sidebar Visibility Change Subscriptio */
  leftSidebarVisibilitySubscription: Subscription;

  @ViewChild('projectDataGrid') projectDataGrid: GridComponent;

  constructor(public leftSidebarService: LeftSidebarService) {
    this.externalPaging = true;
    this.columns = [
      { name: 'TITLE', name2: 'Title', prop: 'name', isVisible: true, type: 'projectTitle', width: 500, sortable: true },
      { name: 'ISSUE DATE', name2: 'IssueDate', prop: 'issuedDate', isVisible: true, type: 'date', sortable: true },
      { name: 'PROJECT STAGE', name2: 'ProjectStage', prop: 'stage', isVisible: true, sortable: true },
      { name: 'PROJECT #', name2: 'Project', prop: 'id', isVisible: true, sortable: true },
      { name: 'VERSION #', name2: 'VersionNumber', prop: 'version', isVisible: true, width: 100, sortable: true },
      { name: 'STATE', name2: 'State', prop: 'state', isVisible: true, sortable: true },
      { name: 'COMPANIES', name2: 'Companies', prop: 'company', isVisible: true, width: 100, type: 'companies', sortable: false },
      { name: 'CITY', name2: 'City', prop: 'city', isVisible: true, sortable: true },
      { name: 'ADDRESS', name2: 'Address', prop: 'street', isVisible: true, sortable: true },
      { name: 'PROJECT TYPE', name2: 'ProjectType', prop: 'type', isVisible: false, sortable: true },
      { name: 'BID DATE', name2: 'BidDate', prop: 'bidDate', isVisible: false, type: 'date', sortable: true },
      { name: 'HIGH VALUE', name2: 'HighValue', prop: 'valuation.high', isVisible: false, sortable: true },
      { name: 'LOW VALUE', name2: 'LowValue', prop: 'valuation.low', isVisible: false, sortable: true },
      { name: 'OWNER NAME', name2: 'OwnerName', prop: 'ownerName', isVisible: false, sortable: true },
      { name: 'ARCHITECT NAME', name2: 'ArchitectName', prop: 'architectName', isVisible: false, sortable: true },
      { name: 'GC NAME', name2: 'GeneralContractor', prop: 'gcName', isVisible: false, sortable: true },
      { name: 'COUNTY', name2: 'County', prop: 'county', isVisible: false, sortable: true },
      { name: 'COUNTRY', name2: 'Country', prop: 'country', isVisible: false, sortable: true },
      { name: 'ZIP', name2: 'ZipCode', prop: 'zip', isVisible: false, sortable: true }
    ];
    this.information = [
      { name: 'DR #', prop: 'id' },
      { name: 'Title', prop: 'name' },
      { name: 'Address', prop: 'street' },
      { name: 'State', prop: 'state' },
      { name: 'City', prop: 'city' },
      { name: 'Zip code', prop: 'zip' },
      { name: 'Primary Project Type', prop: 'type' },
      { name: 'Project Stage(s)', prop: 'stage' },
      { name: 'Owner', prop: 'ownerName' },
      { name: 'Issue Date', prop: 'issuedDate', type: 'date' },
      { name: 'Bid Date', prop: 'bidDate', type: 'date' },
      { name: 'Valuation', prop: 'valuation' },
      { name: 'Architect', prop: 'architectName' },
      { name: 'General Contractor', prop: 'gcName' }
    ];
  }

  ngOnInit() {
    this.leftSidebarService.visibleChange$.subscribe(status => {
      if (this.projectDataGrid) {
        this.projectDataGrid.grid.recalculate();
      }
    });
  }

  ngOnDestroy() {
    if (this.leftSidebarVisibilitySubscription) {
      this.leftSidebarVisibilitySubscription.unsubscribe();
    }
  }
}
