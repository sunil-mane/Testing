import { Component } from '@angular/core';
import { LeftSidebarService } from '../shared/services/left-sidebar.service';
import { GridColumn } from '../shared/models/GridColumn';
import { PageTabNavigation } from '../shared/models/PageTabNavigation';

@Component({
  selector: 'app-feed-content',
  templateUrl: './feed-content.component.html',
  styleUrls: ['./feed-content.component.scss']
})
/**
 * Feed content component
 */
export class FeedContentComponent {

  /** Page indetifier used by left sidebar and grid action buttons component */
  pageIdentifier: string;

  /** Grid column settings */
  columns: GridColumn[] = [];

  /** Extra columns for export */
  columnsForExport: GridColumn[] = [];

  /** Tab Configuration */
  pageTabs: PageTabNavigation[];

  constructor(public leftSidebarService: LeftSidebarService) {
    this.pageIdentifier = 'feedContent';
    this.columns = [
      { name: 'STATUS', name2: 'STATUS', prop: 'routeStatus', isVisible: true, sortable: true, width: 100 },
      { name: 'PROJECT TITLE', name2: 'PROJECT TITLE', prop: 'title', isVisible: true, sortable: true, type: 'feedTitle', width: 500 },
      { name: 'STATE', name2: 'STATE', prop: 'state', isVisible: true, sortable: true, width: 80 },
      { name: 'COUNTY', name2: 'COUNTY', prop: 'county', isVisible: true, sortable: true },
      { name: 'OWNER', name2: 'OWNER', prop: 'owner', isVisible: true, sortable: true },
      {
        name: 'SUBMISSION DATE', name2: 'SUBMISSION DATE', prop: 'submissionDate', isVisible: true,
        type: 'date', sortable: true, width: 100
      },
      { name: 'PREBID DATE', name2: 'PREBID DATE', prop: 'preBidDate', isVisible: true, type: 'date', sortable: true, width: 100 },
      { name: 'PROJECT STAGE', name2: 'PROJECT STAGE', prop: 'projectStage', isVisible: true, sortable: true },
      { name: 'RECORD ID', name2: 'RECORD ID', prop: 'recordId', isVisible: true, sortable: true },
      { name: 'RECEIVED DATE', name2: 'RECEIVED DATE', prop: 'submissionDate', isVisible: true, type: 'date', sortable: true, width: 100 }
    ];
    /** Fields for feed content export feature */
    this.columnsForExport = [
      { name: 'PROCESS DATE', name2: 'FILE PROCESS DATE', prop: 'processDate', type: 'date' },
      { name: 'ASSIGNED TO', name2: 'ASSIGNED TO', prop: 'assignedTo' }
    ];

    /** Page Tab Configuration */
    this.pageTabs = [
      { label: 'Feed Content', route: ['/feed/content'] },
      { label: 'Disposition', route: ['/feed/disposition'] }
    ];
  }

}
