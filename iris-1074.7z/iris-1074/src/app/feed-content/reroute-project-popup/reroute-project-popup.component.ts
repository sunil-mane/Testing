import { Component, Output, EventEmitter, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { GridColumn } from '../../shared/models/GridColumn';
import { BaseFormGroup } from '../../shared/forms/base-form-group';
import { SumoLoggerService } from '../../shared/services/sumo-logger.service';
import { AlertService } from '../../shared/services/alert.service';
import { LeftSidebarService } from '../../shared/services/left-sidebar.service';
import { LookupApiService } from '../../shared/services/lookup-api.service';
import { BaseFormControl } from '../../shared/forms/base-form-control';
import { isNil, isString, isObject, isArray, remove, get, isEqual, isEmpty } from 'lodash';

/**
 * Reroute project popup component
 * This component will be used with bootstrap popup service and return selected value when popup is closed.
 */

@Component({
  selector: 'app-reroute-project-popup',
  templateUrl: './reroute-project-popup.component.html',
  styleUrls: ['./reroute-project-popup.component.scss']
})
export class RerouteProjectPopupComponent implements OnInit {
  reporterColumns: GridColumn[];
  regionColumns: GridColumn[];
  regions = [];
  reporters = [];
  reporterGridData = [];
  selected = [];
  selectedReporter = 0;
  // reroute Info Form
  rerouteProjectBaseForm: BaseFormGroup;
  sourceControl: BaseFormControl;
  sourceTypeControlSubscription: Subscription;

  constructor(private logger: SumoLoggerService, private alertService: AlertService, public leftSidebarService: LeftSidebarService,
    private lookupApiService: LookupApiService, public activeModal: NgbActiveModal) {
    // reporter dropdown config
    this.reporterColumns = [
      { name: 'Reporter ID', prop: 'id' },
      { name: 'User ID', prop: 'user' }
    ];
    // Region dropdown config
    this.regionColumns = [
      { name: 'REGION NAME', prop: 'name' }
    ];
    this.rerouteProjectBaseForm = new BaseFormGroup('rerouteProjectBaseForm', {
      id: new FormControl('', [], []),
      type: new FormControl('REGION', [], [])
    });
    this.sourceTypeControlSubscription = this.rerouteProjectBaseForm.get('type').valueChanges.subscribe((newval) => {
      if (newval === 'REPORTER') {
        this.rerouteProjectBaseForm.get('id').reset();
      }
      if (newval === 'REGION') {
        if (this.selected.length) {
          this.selected = [...[]];
        }
      }
    });
  }
  /**
   * Single select action from grid
   * @param row selected row
   */
  singleSelectCheck(row: any) {
    return this.selected.indexOf(row) === -1;
  }
  ngOnInit() {
    this.getRegions();
    this.getReporters();
  }
  /**
   * Submit form action
   */
  submitForm() {
    const json = this.rerouteProjectBaseForm.value;
    if (this.rerouteProjectBaseForm.get('type').value === 'REPORTER') {
      json.id = this.selectedReporter.toString();
    } else {
      json.id = json.id.toString();
    }
    // if id is selected then close popup and send value to grid action button
    if (json.id.length) {
      this.activeModal.close(json);
    }
  }
  /**
   * filter values in grid
   * @param event text entered in search filter
   */
  updateFilter(event) {
    const val = event.target.value.toLowerCase();

    // filter our data
    const temp = this.reporters.filter(function (d) {
      return (d.user ? d.user.toLowerCase().indexOf(val) !== -1 : val) || !val;
    });

    // update the rows
    this.reporterGridData = temp;
  }
  /**
   * Reporter grid row select event
   * @param $event selected row
   */
  onSelect($event: any) {
    this.selectedReporter = $event.selected[0].id;
  }
  /**
   * Regions lookup api call
   */
  getRegions() {
    this.lookupApiService.getRegions().subscribe(
      (res) => {
        this.regions = res.data.regions;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * Reporters lookup api call
   */
  getReporters() {
    this.lookupApiService.getReporters().subscribe(
      (res) => {
        const temp = res.data.reporters;
        this.reporters = temp;
        this.reporterGridData = temp;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
}
