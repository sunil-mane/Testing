import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ErrorsComponent } from './errors.component';
import { ErrorsRoutingModule } from './errors-routing.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    SharedModule,
    ErrorsRoutingModule
  ],
  declarations: [ErrorsComponent]
})
export class ErrorsModule { }
