import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MessageService } from '../shared/services/message.service';

@Component({
  selector: 'app-error',
  templateUrl: './errors.component.html'
})
export class ErrorsComponent implements OnInit {
  errorCode: number;
  errorMessage: string;

  constructor(
    private msg: MessageService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    const routeData = this.activatedRoute.snapshot.data;
    this.errorCode = (routeData.error) ? routeData.error : 404;
    this.errorMessage = this.msg.getAPIErrorMessage(this.errorCode);
  }

}
