import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { ErrorsComponent } from './errors.component';
import { MessageService } from '../shared/services/message.service';
import * as messages from '../shared/config/messages.json';

describe('ErrorsComponent', () => {
  let component: ErrorsComponent;
  let fixture: ComponentFixture<ErrorsComponent>;
  let element: DebugElement;
  let dom: HTMLElement;
  let apiMessages: any;
  let messageService: MessageService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [ErrorsComponent],
      providers: [MessageService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    apiMessages = (<any>messages).apiMessages;
    messageService = fixture.debugElement.injector.get(MessageService);
  });

  it('should create', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should have errorCode 404 when there is no snapshot error code', async(() => {
    component.ngOnInit();
    fixture.whenStable().then(() => {
      element = fixture.debugElement.query(By.css('.text-center h1'));
      dom = element.nativeElement;
      expect(component.errorCode).toBe(404);
      expect(dom.textContent.includes('404')).toBeTruthy();
    });
  }));

  it('should have errorMessage', async(() => {
    component.ngOnInit();
    fixture.whenStable().then(() => {
      element = fixture.debugElement.query(By.css('.text-center h5'));
      dom = element.nativeElement;
      expect(component.errorMessage).toBe(apiMessages['404']);
      expect(dom.textContent.includes(apiMessages['404'])).toBeTruthy();
    });
  }));

  it('should have call MessageService', async(() => {
    spyOn(messageService, 'getAPIErrorMessage').and.callThrough();
    component.ngOnInit();
    fixture.whenStable().then(() => {
      expect(messageService.getAPIErrorMessage).toHaveBeenCalledTimes(1);
    });
  }));
});
