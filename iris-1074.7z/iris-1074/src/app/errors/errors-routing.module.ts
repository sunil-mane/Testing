import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorsComponent } from './errors.component';

const routes: Routes = [
  { path: '401', component: ErrorsComponent, data: { error: 401 } },
  { path: '403', component: ErrorsComponent, data: { error: 403 } },
  { path: '404', component: ErrorsComponent, data: { error: 404 } },
  { path: '', component: ErrorsComponent, data: { error: 404 } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ErrorsRoutingModule { }
