import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { SearchComponent } from './search.component';
import { ProjectPopupComponent } from './project-popup/project-popup.component';
/**
 * Routes inside projects module
 */
const routes: Routes = [
  { path: '', redirectTo: 'search', pathMatch: 'full' },
  { path: 'search', component: SearchComponent }
];
/**
 * Companies Module
 */
@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [SearchComponent, ProjectPopupComponent]
})

export class CompaniesModule { }
