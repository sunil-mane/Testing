import { Component } from '@angular/core';
import { LeftSidebarService } from '../shared/services/left-sidebar.service';
import { GridColumn } from '../shared/models/GridColumn';

/**
 * Company Search Page
 */
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent {
  /** Page indetifier used by left sidebar and grid action buttons component */
  pageIdentifier: string;

  /** Grid column settings */
  columns: GridColumn[] = [];

  /** Extra columns for export */
  columnsForExport: GridColumn[] = [];

  /** Constructor */
  constructor(public leftSidebarService: LeftSidebarService) {
    this.pageIdentifier = 'companySearch';
    this.columns = [
      { name: 'COMPANY', name2: 'CompanyName', prop: 'name', isVisible: true, width: 500, type: 'companyTitle', order: 2, sortable: true },
      { name: 'SOURCE', name2: 'Source', prop: 'source', isVisible: true, width: 100, type: 'source', sortable: false },
      { name: 'COMPANY CODE', name2: 'DcisFactorCode', prop: 'code', isVisible: true, order: 1, sortable: true },
      { name: 'LAST UPDATE', name2: 'LastUpdate', prop: 'lastUpdateDate', isVisible: true, type: 'date', order: 5, sortable: false },
      { name: 'PROJECT', name2: 'Project', prop: 'project', isVisible: true, width: 100, type: 'projects', sortable: false },
      { name: 'CONTACT NAME', name2: 'ContactName', prop: 'contact.name', isVisible: true, order: 3, sortable: true },
      { name: 'COMPANY TYPE/EMAIL', name2: 'CompanyType', prop: 'type', isVisible: true, type: 'email', order: 4, sortable: true },
      { name: 'PHONE', name2: 'PhoneNumber', prop: 'phone', isVisible: true, type: 'phone', order: 10, sortable: true },
      { name: 'ADDRESS', name2: 'Address', prop: 'street', isVisible: true, width: 200, order: 6, sortable: true },
      { name: 'STATE', name2: 'State', prop: 'state', isVisible: true, width: 100, order: 7, sortable: true },
      { name: 'CITY', name2: 'City', prop: 'city', isVisible: true, order: 8, sortable: true }
    ];
    /** Fields for company export feature */
    this.columnsForExport = [
      { name: 'AreaCode', name2: 'AreaCode', prop: 'phoneAreaCode', order: 9 },
      { name: 'PhoneExtension', name2: 'PhoneExtension', prop: 'phoneExt', order: 11 },
      { name: 'NumberOfContacts', name2: 'NumberOfContacts', prop: 'numberOfContacts', type: 'NumberOfContacts', order: 12 },
      { name: 'SpecialSourceIndicator', name2: 'SpecialSourceIndicator', prop: 'isSpecialSource', order: 13 },
      { name: 'SourceIndicator', name2: 'SourceIndicator', prop: 'isSource', order: 14 }
    ];
  }
}
