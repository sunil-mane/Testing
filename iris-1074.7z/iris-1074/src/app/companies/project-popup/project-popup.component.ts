import { Component, OnInit, OnDestroy } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';
import { Subscription } from 'rxjs';
import { RightSlidepanelService } from '../../shared/services/right-slidepanel.service';
import { Project } from '../../shared/models/ProjectPopupLookup';
import { Company } from '../../shared/models/CompanyTypeLookup';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'app-project-popup',
  templateUrl: './project-popup.component.html',
  styleUrls: ['./project-popup.component.scss'],
  animations: [
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({ transform: 'translateX(100%)', opacity: 0 }),
          animate('500ms', style({ transform: 'translateX(0)', opacity: 1 }))
        ]),
        transition(':leave', [
          style({ transform: 'translateX(0)', opacity: 1 }),
          animate('500ms', style({ transform: 'translateX(100%)', opacity: 0 }))
        ])
      ]
    )
  ]
})
export class ProjectPopupComponent implements OnInit, OnDestroy {
  // list of projects
  projectList: Project[] = [];
  // Observable subscription
  subscription: Subscription;
  // Comapny object
  company: Company;
  constructor(public rightPanelService: RightSlidepanelService, private alertService: AlertService) { }

  ngOnInit() {
    // subscribe for company id change from right panel service
    this.subscription = this.rightPanelService.Company$.subscribe((company: Company) => {
      this.alertService.clear();
      // if number is greater than 0 then call api
      if (company) {
        this.company = company;
        this.rightPanelService.getProjectsForCompany(company.code).then((projects: Project[]) => {
          this.rightPanelService.showRightPanel = true;
          this.projectList = projects;
        }).catch((reason) => {
          this.alertService.error(reason.error.data);
        });
      }
    });
  }

  ngOnDestroy() {
    // When component get destroy, unsubscribe
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    this.rightPanelService.showRightPanel = false;
    this.rightPanelService.setCompany(null);
  }

}
