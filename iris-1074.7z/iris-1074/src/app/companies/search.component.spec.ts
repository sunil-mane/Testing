import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { SearchComponent } from './search.component';
import { ProjectPopupComponent } from './project-popup/project-popup.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TreeviewModule } from 'ngx-treeview';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from '../reducers';

describe('CompanySearchComponent', () => {
  let component: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), TreeviewModule.forRoot(),
        RouterTestingModule, HttpClientTestingModule, StoreModule.forRoot(reducers, { metaReducers })],
      declarations: [SearchComponent, ProjectPopupComponent],
      providers: [LocationStrategy, PathLocationStrategy]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    // fixture.detectChanges();
    expect(component).toBeTruthy();
  });
});
