import { FormControl } from '@angular/forms';

/**
 * A common email validator which can be applied to form control.
 * This will return a validator message.
 */
export class IRISValidators {
  /**
    * This method will validate email with pattern and will return invalid if pattern is not matching.
    * @returns form control with validation message.
  */
  static Email() {
    return (control: FormControl): { [key: string]: any } => {
      const EMAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
      if (!EMAIL_REGEXP.test(control.value)) {
        return { 'email': { 'email': control.value, 'actualValue': control.value } };
      } else {
        return null;
      }
    };
  }
}
