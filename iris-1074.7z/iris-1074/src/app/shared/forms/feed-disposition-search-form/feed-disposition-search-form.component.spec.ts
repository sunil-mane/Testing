import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { SharedModule } from '../../shared.module';
import { TreeviewModule } from 'ngx-treeview';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { ApiService } from '../../services/api.service';
import { AlertService } from '../../services/alert.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LookupApiService } from '../../services/lookup-api.service';

import { FeedDispositionSearchFormComponent } from './feed-disposition-search-form.component';
import { APP_BASE_HREF } from '@angular/common';

describe('FeedDispositionSearchFormComponent', () => {
  let component: FeedDispositionSearchFormComponent;
  let fixture: ComponentFixture<FeedDispositionSearchFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, HttpClientTestingModule, RouterTestingModule,
        SharedModule.forRoot(), TreeviewModule.forRoot()],
      providers: [{ provide: LocationStrategy, useClass: PathLocationStrategy },
      { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedDispositionSearchFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
