import { Component, Input, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { GridColumn } from '../../models/GridColumn';
import { BaseFormGroup } from '../base-form-group';
import { SumoLoggerService } from '../../services/sumo-logger.service';
import { AlertService } from '../../services/alert.service';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { BaseFormControl } from '../base-form-control';
import { isNil, isString, isObject, isArray, remove, get, isEqual, isEmpty } from 'lodash';
import { FormGroup, FormControl } from '@angular/forms';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { environment } from '../../../../environments/environment';
import { DropdownGridComponent } from './../../components/dropdown-grid/dropdown-grid.component';
import * as moment from 'moment';
import { Feed } from '../../models/Feed';

@Component({
  selector: 'app-feed-disposition-search-form',
  templateUrl: './feed-disposition-search-form.component.html'
})
export class FeedDispositionSearchFormComponent implements OnInit, OnDestroy {
  // Form group title
  @Input() parentDisplayName: string;
  // Form group name
  @Input() parentControlName: string;
  reasonColumns: GridColumn[];
  reasons = [];
  // date controls
  // minDateValidation
  minValidationDate: NgbDateStruct = { year: 2009, month: 1, day: 1 };
  maxValidationDate: NgbDateStruct = { year: new Date().getFullYear() + 5, month: 1, day: 1 };
  // date controls
  maxFeedDate: NgbDateStruct;
  // date controls
  startDateDefault: string = moment().startOf('month').subtract(1, 'months').format(environment.apiDateFormat);
  endDateDefault: string = moment().format(environment.apiDateFormat);
  startDateControl: BaseFormControl = new BaseFormControl('Start', 'start', 'start', this.startDateDefault, [], []);
  endDateControl: BaseFormControl = new BaseFormControl('End', 'end', 'end', this.endDateDefault, [], []);
  // Company/Contact Info Form
  feedDispositionForm: BaseFormGroup;
  // Company keyword
  feedDispositionDateRangeFormGroup: BaseFormGroup;

  mainFormReadySubscription: Subscription;
  clearFormSubscription: Subscription;
  startDateControlSubcription: Subscription;
  constructor(private logger: SumoLoggerService, private alertService: AlertService, public leftSidebarService: LeftSidebarService,
    private lookupApiService: LookupApiService) {
    // reporter dropdown config
    this.reasonColumns = [
      { name: 'REASON', prop: 'description' }
    ];
    // efeed date form
    this.feedDispositionDateRangeFormGroup = new BaseFormGroup('discardDateRange', {
      dateRange: new FormGroup({
        start: this.startDateControl,
        end: this.endDateControl
      })
    });

    // efeed form
    this.feedDispositionForm = new BaseFormGroup('feedDispositionForm', {
      feedname: new BaseFormControl('Feed Name', 'feedname', 'text', '', [], []),
      discardReasonId: new BaseFormControl('Discard Reason', 'discardReasonId', 'text', '', [], []),
      projectTitle: new BaseFormControl('Project Title', 'projectTitle', 'text', '', [], []),
      recordId: new BaseFormControl('Record Name', 'recordId', 'text', '', [], []),
      discard: this.feedDispositionDateRangeFormGroup
    });
  }

  ngOnInit() {
    // Get all lookup list
    this.getReasons();
    // this.reporterDropdown.disabled = true;
    // Push form on ready
    this.mainFormReadySubscription = this.leftSidebarService.mainFormReady$.subscribe((status) => {
      if (status) {
        this.addRemoveControls(true);
      }
    });
    // Reset field
    this.clearFormSubscription = this.leftSidebarService.clearForm$.subscribe((control) => {
      if (!isNil(control)) {
        if (isString(control)) {
          if (control === 'all') {
            this.leftSidebarService.getMainForm.reset({
              feedname: '',
              discardReasonId: '',
              projectTitle: '',
              recordId: '',
              discard: {
                dateRange: {
                  start: this.startDateDefault,
                  end: this.endDateDefault
                }
              }
            });
          } else {
            this.leftSidebarService.getMainForm.get(control).reset();
          }
        }
      }
    });
    this.startDateControlSubcription = this.startDateControl.valueChanges.subscribe((newval: string) => {
      if (!newval) {
        this.endDateControl.disable();
        this.endDateControl.setValue('');
      } else {
        this.endDateControl.enable();
        // set start date as min date to issue max date
        const minDate = moment(newval, environment.apiDateFormat);
        // empty the field if date is already there and its invalid
        if (this.endDateControl.value) {
          const endDate = moment(this.endDateControl.value, environment.apiDateFormat);
          if (minDate.isAfter(endDate)) {
            this.endDateControl.setValue('');
          }
        }
        this.maxFeedDate = { year: minDate.get('year'), month: minDate.get('month') + 1, day: minDate.get('date') };
      }
    });
  }

  ngOnDestroy() {
    if (this.mainFormReadySubscription) {
      this.mainFormReadySubscription.unsubscribe();
    }
    if (this.clearFormSubscription) {
      this.clearFormSubscription.unsubscribe();
    }
    if (this.startDateControlSubcription) {
      this.startDateControlSubcription.unsubscribe();
    }
    this.addRemoveControls(false);
  }
  /**
   * Regions lookup api call
   */
  getReasons() {
    this.lookupApiService.getDispostionReasons().subscribe(
      (res) => {
        this.reasons = res.data.dispositions;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /** Add / Remove Controls */
  addRemoveControls(addControls: boolean) {
    if (addControls) {
      this.leftSidebarService.getMainForm.addControl('feedname', this.feedDispositionForm.controls['feedname']);
      this.leftSidebarService.getMainForm.addControl('discardReasonId', this.feedDispositionForm.controls['discardReasonId']);
      this.leftSidebarService.getMainForm.addControl('projectTitle', this.feedDispositionForm.controls['projectTitle']);
      this.leftSidebarService.getMainForm.addControl('discard', this.feedDispositionForm.controls['discard']);
      this.leftSidebarService.getMainForm.addControl('recordId', this.feedDispositionForm.controls['recordId']);
    } else {
      this.leftSidebarService.getMainForm.removeControl('feedname');
      this.leftSidebarService.getMainForm.removeControl('discardReasonId');
      this.leftSidebarService.getMainForm.removeControl('projectTitle');
      this.leftSidebarService.getMainForm.removeControl('discard');
      this.leftSidebarService.getMainForm.removeControl('recordId');
    }
  }
}
