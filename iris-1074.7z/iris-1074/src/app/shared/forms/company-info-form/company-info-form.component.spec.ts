import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CompanyInfoFormComponent } from './company-info-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { SharedModule } from '../../shared.module';

describe('CompanyInfoFormComponent', () => {
  let component: CompanyInfoFormComponent;
  let fixture: ComponentFixture<CompanyInfoFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, SharedModule.forRoot(), RouterTestingModule],
      providers: [LocationStrategy, PathLocationStrategy]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyInfoFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getCompanyTypes method', fakeAsync(() => {
    const spy = spyOn(component, 'getCompanyTypes');
    component.ngOnInit();
    tick(300);
    expect(spy).toHaveBeenCalled();
  }));

  it('should accept the phone number if entered correctly', fakeAsync(() => {
    const phoneNumber = '1234567890';
    component.companyInfoForm.get('phone').setValue(phoneNumber);
    tick(300);
    const companyInfo = component.companyInfoForm.value;
    expect(companyInfo.phone).toBe(phoneNumber);
  }));

  it('should clear the company keyword if entered less than 3 characters', fakeAsync(() => {
    component.companyKeywordFormGroup.get('term').setValue('ab');
    tick(300);
    const keyword = component.companyKeywordFormGroup.value;
    expect(keyword.term).toBe('');
  }));

  it('should accept the company keyword if entered more than 3 characters', fakeAsync(() => {
    const word = 'abcd';
    component.companyKeywordFormGroup.get('term').setValue(word);
    tick(300);
    const keyword = component.companyKeywordFormGroup.value;
    expect(keyword.term).toBe(word);
  }));
});
