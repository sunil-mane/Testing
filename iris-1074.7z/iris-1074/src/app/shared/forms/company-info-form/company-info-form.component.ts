import { Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy } from '@angular/core';
import { BaseFormGroup } from '../../forms/base-form-group';
import { BaseFormControl } from '../../forms/base-form-control';
import { Company } from '../../models/CompanyTypeLookup';
import { ApiService } from '../../services/api.service';
import { SumoLoggerService } from '../../services/sumo-logger.service';
import { IRISValidators } from '../../validators/validators';
import { AlertService } from '../../services/alert.service';
import { GridColumn } from '../../models/GridColumn';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { UtilService } from '../../services/util.service';
import { Subscription } from 'rxjs';
import { isNil, isString, isObject, isArray, remove } from 'lodash';

/**
 * Company/Contact Info Form Component
 */
@Component({
  selector: 'app-company-info-form',
  templateUrl: './company-info-form.component.html',
  styleUrls: ['./company-info-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class CompanyInfoFormComponent implements OnInit, OnDestroy {
  // Form group title
  @Input() parentDisplayName: string;
  // Form group name
  @Input() parentControlName: string;
  // Company Type columns
  companyTypeColumns: GridColumn[];
  // Company/Contact Info Form
  companyInfoForm: BaseFormGroup;
  // Company keyword
  companyKeywordFormGroup: BaseFormGroup;
  // Contact name
  contactFormGroup: BaseFormGroup;
  // Company type lookup
  companyTypes: Company[];

  // Subscription
  companyInfoFormSubscription: Subscription;
  companyKeywordFormGroupSubscription: Subscription;
  mainFormReadySubscription: Subscription;
  clearFormSubscription: Subscription;

  constructor(private api: ApiService, private logger: SumoLoggerService, private alertService: AlertService,
    public leftSidebarService: LeftSidebarService, private lookupApiService: LookupApiService, private utilService: UtilService) {
    // Company Type dropdown config
    this.companyTypeColumns = [
      { name: 'Company Type', prop: 'desc' },
    ];
    this.companyKeywordFormGroup = new BaseFormGroup('keyword', {
      term: new BaseFormControl('Keyword Term', 'term', 'text', '', [], []),
      exactMatch: new BaseFormControl('Keyword Option', 'exactMatch', 'radio', true, [], [])
    });
    this.contactFormGroup = new BaseFormGroup('contact', {
      name: new BaseFormControl('Name', 'name', 'text', '', [], []),
      code: new BaseFormControl('Code', 'code', 'text', '', [], [])
    });
    this.companyInfoForm = new BaseFormGroup('companyInfoForm', {
      name: new BaseFormControl('Company Name', 'name', 'text', '', [], []),
      code: new BaseFormControl('Company Code', 'code', 'text', '', [], []),
      keyword: this.companyKeywordFormGroup,
      phone: new BaseFormControl('Phone', 'phone', 'text', '', [], []),
      type: new BaseFormControl('Company Type', 'type', 'select', '', [], []),
      contact: this.contactFormGroup,
      email: new BaseFormControl('Email', 'email', 'text', '', [], [IRISValidators.Email()]),
    });
    // Company info form validations on blur event
    this.companyInfoFormSubscription = this.leftSidebarService.getMainForm.valueChanges.subscribe(
      (obj) => {
        if (obj.company && obj.company.phone) {
          obj.company.phone = obj.company.phone.replace(/\D+/g, '');
        }
      }
    );
    // Company keyword minimum 3 characters
    this.companyKeywordFormGroupSubscription = this.companyKeywordFormGroup.valueChanges.subscribe(
      (obj) => {
        if (obj.term) {
          if (obj.term.length < 3 && obj.term.length !== 0) {
            this.companyKeywordFormGroup.patchValue({
              term: ''
            });
          }
        }
      }
    );
  }

  ngOnInit() {
    // Get all company types
    this.getCompanyTypes();
    // Push form on ready
    this.mainFormReadySubscription = this.leftSidebarService.mainFormReady$.subscribe((status) => {
      if (status) {
        this.addRemoveControls(true);
      }
    });
    // Reset field
    this.clearFormSubscription = this.leftSidebarService.clearForm$.subscribe((control) => {
      if (!isNil(control)) {
        if (isString(control)) {
          if (control === 'all') {
            this.companyInfoForm.reset({
              name: '',
              code: '',
              keyword: {
                term: '',
                exactMatch: false
              },
              phone: '',
              type: '',
              contact: {
                name: '',
                code: ''
              },
              email: ''
            });
          } else {
            if (control.includes(this.parentControlName)) {
              const clearControl = control.split('.');
              remove(clearControl, val => val === this.parentControlName);
              if (!isNil(this.companyInfoForm.get(clearControl))) {
                this.companyInfoForm.get(clearControl).reset();
              }
            }
          }
        } else if (isObject(control)) {
          if (control.control.includes(this.parentControlName)) {
            const clearValue = control.value;
            const clearControl = control.control.split('.');
            remove(clearControl, val => val === this.parentControlName);
            if (!isNil(this.companyInfoForm.get(clearControl))) {
              const currentValue = this.companyInfoForm.get(clearControl).value;
              if (isArray(currentValue)) {
                remove(currentValue, val => val === clearValue);
                this.companyInfoForm.get(clearControl).setValue(currentValue);
              } else {
                if (clearControl[0] === 'phone') {
                  if (clearValue.length === 3) {
                    this.companyInfoForm.get(clearControl).setValue('(___) ' + currentValue.split(')')[1]);
                  } else {
                    this.companyInfoForm.get(clearControl).setValue(currentValue.split(')')[0] + ') ___-____');
                  }
                } else {
                  this.companyInfoForm.get(clearControl).reset();
                }
              }
            }
          }
        }
      }
    });
  }

  ngOnDestroy() {
    if (this.companyInfoFormSubscription) {
      this.companyInfoFormSubscription.unsubscribe();
    }
    if (this.companyKeywordFormGroupSubscription) {
      this.companyKeywordFormGroupSubscription.unsubscribe();
    }
    if (this.mainFormReadySubscription) {
      this.mainFormReadySubscription.unsubscribe();
    }
    if (this.clearFormSubscription) {
      this.clearFormSubscription.unsubscribe();
    }
    this.addRemoveControls(false);
  }

  /**
   * Get All Company type
   */
  getCompanyTypes() {
    this.lookupApiService.getCompanyTypes().subscribe(
      (res) => {
        this.companyTypes = this.utilService.removeDuplicateObjectByProperty(res.data.companyTypes, 'desc');
      },
      (err) => {
        this.logger.error(err);
        this.alertService.error(err.message);
      }
    );
  }

  /**
   * Change event handler for exactMacth checkbox
   * @param event the event object
   */
  exactMarchCheckHandler(event: MouseEvent) {
    const element = <HTMLInputElement>event.target;
    this.companyInfoForm.get('keyword.exactMatch').setValue(element.checked);
  }

  /** Add / Remove Controls */
  addRemoveControls(addControls: boolean) {
    if (addControls) {
      if (!this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentGroupControlName = this.parentControlName + 'FormGroup';
        const parentGroupControl = new BaseFormGroup(parentGroupControlName, {});
        this.leftSidebarService.getMainForm.addControl(this.parentControlName, parentGroupControl);
      }
      const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
      parentFormGroup.addControl('name', this.companyInfoForm.controls['name']);
      parentFormGroup.addControl('code', this.companyInfoForm.controls['code']);
      parentFormGroup.addControl('keyword', this.companyInfoForm.controls['keyword']);
      parentFormGroup.addControl('phone', this.companyInfoForm.controls['phone']);
      parentFormGroup.addControl('type', this.companyInfoForm.controls['type']);
      parentFormGroup.addControl('contact', this.companyInfoForm.controls['contact']);
      parentFormGroup.addControl('email', this.companyInfoForm.controls['email']);
    } else {
      if (this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
        parentFormGroup.removeControl('name');
        parentFormGroup.removeControl('code');
        parentFormGroup.removeControl('keyword');
        parentFormGroup.removeControl('phone');
        parentFormGroup.removeControl('type');
        parentFormGroup.removeControl('contact');
        parentFormGroup.removeControl('email');
        if (Object.keys((this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup).controls).length === 0) {
          this.leftSidebarService.getMainForm.removeControl(this.parentControlName);
        }
      }
    }
  }
}
