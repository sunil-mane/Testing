import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { GridColumn } from '../../models/GridColumn';
import { BaseFormGroup } from '../base-form-group';
import { Company } from '../../models/CompanyTypeLookup';
import { SumoLoggerService } from '../../services/sumo-logger.service';
import { AlertService } from '../../services/alert.service';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { BaseFormControl } from '../base-form-control';
import { IRISValidators } from '../../validators/validators';
import { isNil, isString, isObject, isArray, remove, get } from 'lodash';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-company-contact-info-form',
  templateUrl: './company-contact-info-form.component.html'
})
export class CompanyContactInfoFormComponent implements OnInit, OnDestroy {
  // Form group title
  @Input() parentDisplayName: string;
  // Form group name
  @Input() parentControlName: string;
  // Company Type columns
  companyTypeColumns: GridColumn[];
  // Company/Contact Info Form
  companyContactInfoForm: BaseFormGroup;
  // Company keyword
  companyKeywordFormGroup: BaseFormGroup;
  // Contact name
  contactFormGroup: BaseFormGroup;
  // Company type lookup
  companyTypes: Company[];

  mainFormReadySubscription: Subscription;
  clearFormSubscription: Subscription;
  companyContactInfoFormSubscription: Subscription;

  constructor(private logger: SumoLoggerService, private alertService: AlertService, public leftSidebarService: LeftSidebarService,
    private lookupApiService: LookupApiService) {
    // Company Type dropdown config
    this.companyTypeColumns = [
      { name: 'Code', prop: 'id' },
      { name: 'Company Type', prop: 'type' },
    ];
    this.companyKeywordFormGroup = new BaseFormGroup('keyword', {
      term: new BaseFormControl('Keyword Term', 'term', 'text', '', [], [Validators.minLength(3)]),
      exactMatch: new BaseFormControl('Keyword Option', 'exactMatch', 'radio', true, [], [])
    });
    this.contactFormGroup = new BaseFormGroup('contact', {
      name: new BaseFormControl('Name', 'name', 'text', '', [], []),
      email: new BaseFormControl('Email', 'email', 'text', '', [], [IRISValidators.Email()]),
    });
    this.companyContactInfoForm = new BaseFormGroup('companyContactInfoForm', {
      name: new BaseFormControl('Company Name', 'name', 'text', '', [], []),
      code: new BaseFormControl('Company Code', 'code', 'text', '', [], []),
      keyword: this.companyKeywordFormGroup,
      phone: new BaseFormControl('Phone', 'phone', 'text', '', [], []),
      type: new BaseFormControl('Company Type', 'type', 'select', '', [], []),
      contact: this.contactFormGroup,
      fax: new BaseFormControl('Fax', 'fax', 'text', '', [], []),
      website: new BaseFormControl('Website', 'website', 'text', '', [], [])
    });

    // Company info form validations on blur event
    this.companyContactInfoFormSubscription = this.leftSidebarService.getMainForm.valueChanges.subscribe(
      (obj) => {
        if (get(obj.company, 'phone')) {
          obj.company.phone = obj.company.phone.replace(/\D+/g, '');
        }
        if (get(obj.company, 'fax')) {
          obj.company.fax = obj.company.fax.replace(/\D+/g, '');
        }
      }
    );
  }

  ngOnInit() {
    this.getCompanyTypes();
    // Push form on ready
    this.mainFormReadySubscription = this.leftSidebarService.mainFormReady$.subscribe((status) => {
      if (status) {
        this.addRemoveControls(true);
      }
    });
    // Reset field
    this.clearFormSubscription = this.leftSidebarService.clearForm$.subscribe((control) => {
      if (!isNil(control)) {
        if (isString(control)) {
          if (control === 'all') {
            this.companyContactInfoForm.reset({
              keyword: {
                term: '',
                exactMatch: true
              }
            });
          } else {
            if (control.includes(this.parentControlName)) {
              const clearControl = control.split('.');
              remove(clearControl, val => val === this.parentControlName);
              if (!isNil(this.companyContactInfoForm.get(clearControl))) {
                this.companyContactInfoForm.get(clearControl).reset();
              }
            }
          }
        } else if (isObject(control)) {
          if (control.control.includes(this.parentControlName)) {
            const clearValue = control.value;
            const clearControl = control.control.split('.');
            remove(clearControl, val => val === this.parentControlName);
            if (!isNil(this.companyContactInfoForm.get(clearControl))) {
              if (isNil(clearValue)) {
                this.companyContactInfoForm.get(clearControl).reset();
              } else {
                const currentValue = this.companyContactInfoForm.get(clearControl).value;
                if (isArray(currentValue)) {
                  remove(currentValue, val => val === clearValue);
                  this.companyContactInfoForm.get(clearControl).setValue(currentValue);
                } else {
                  if (clearControl[0] === 'phone' || clearControl[0] === 'fax') {
                    if (clearValue.length === 3) {
                      this.companyContactInfoForm.get(clearControl).setValue('(___) ' + currentValue.split(')')[1]);
                    } else {
                      this.companyContactInfoForm.get(clearControl).setValue(currentValue.split(')')[0] + ') ___-____');
                    }
                  } else {
                    this.companyContactInfoForm.get(clearControl).reset();
                  }
                }
              }
            }
          }
        }
      }
    });
  }

  ngOnDestroy() {
    if (this.mainFormReadySubscription) {
      this.mainFormReadySubscription.unsubscribe();
    }
    if (this.clearFormSubscription) {
      this.clearFormSubscription.unsubscribe();
    }
    if (this.companyContactInfoFormSubscription) {
      this.companyContactInfoFormSubscription.unsubscribe();
    }
    this.addRemoveControls(false);
  }

  /**
   * Get All Company type
   */
  getCompanyTypes() {
    this.lookupApiService.getCompanyTypes().subscribe(
      (res) => {
        this.companyTypes = res.data.companyTypes;
      },
      (err) => {
        this.logger.error(err);
        this.alertService.error(err.message);
      }
    );
  }

  /**
   * Change event handler for exactMacth checkbox
   * @param event the event object
   */
  exactMarchCheckHandler(event: MouseEvent) {
    const element = <HTMLInputElement>event.target;
    this.companyContactInfoForm.get('keyword.exactMatch').setValue(element.checked);
  }

  /** Add / Remove Controls */
  addRemoveControls(addControls: boolean) {
    if (addControls) {
      if (!this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentGroupControlName = this.parentControlName + 'FormGroup';
        const parentGroupControl = new BaseFormGroup(parentGroupControlName, {});
        this.leftSidebarService.getMainForm.addControl(this.parentControlName, parentGroupControl);
      }
      const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
      parentFormGroup.addControl('name', this.companyContactInfoForm.controls['name']);
      parentFormGroup.addControl('code', this.companyContactInfoForm.controls['code']);
      parentFormGroup.addControl('keyword', this.companyContactInfoForm.controls['keyword']);
      parentFormGroup.addControl('phone', this.companyContactInfoForm.controls['phone']);
      parentFormGroup.addControl('type', this.companyContactInfoForm.controls['type']);
      parentFormGroup.addControl('contact', this.companyContactInfoForm.controls['contact']);
      parentFormGroup.addControl('fax', this.companyContactInfoForm.controls['fax']);
      parentFormGroup.addControl('website', this.companyContactInfoForm.controls['website']);
    } else {
      if (this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
        parentFormGroup.removeControl('name');
        parentFormGroup.removeControl('code');
        parentFormGroup.removeControl('keyword');
        parentFormGroup.removeControl('phone');
        parentFormGroup.removeControl('type');
        parentFormGroup.removeControl('contact');
        parentFormGroup.removeControl('fax');
        parentFormGroup.removeControl('website');
        if (Object.keys((this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup).controls).length === 0) {
          this.leftSidebarService.getMainForm.removeControl(this.parentControlName);
        }
      }
    }
  }
}
