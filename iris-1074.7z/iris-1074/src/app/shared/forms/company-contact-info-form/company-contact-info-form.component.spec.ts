import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { SharedModule } from '../../shared.module';

import { CompanyContactInfoFormComponent } from './company-contact-info-form.component';

describe('CompanyContactInfoFormComponent', () => {
  let component: CompanyContactInfoFormComponent;
  let fixture: ComponentFixture<CompanyContactInfoFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, SharedModule.forRoot(), RouterTestingModule],
      providers: [LocationStrategy, PathLocationStrategy]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyContactInfoFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });
  it('should initialize variables', () => {
    fixture.detectChanges();
    expect(component.companyKeywordFormGroup).toBeTruthy();
    expect(component.contactFormGroup).toBeTruthy();
  });
  it('should call getCompanyTypes method', fakeAsync(() => {
    const spy = spyOn(component, 'getCompanyTypes');
    component.ngOnInit();
    tick(300);
    expect(spy).toHaveBeenCalled();
  }));

  it('should accept the phone number if entered correctly', fakeAsync(() => {
    const phoneNumber = '1234567890';
    component.companyContactInfoForm.get('phone').setValue(phoneNumber);
    tick(300);
    const companyInfo = component.companyContactInfoForm.value;
    expect(companyInfo.phone).toBe(phoneNumber);
  }));

  it('should accept the company keyword if entered more than 3 characters', fakeAsync(() => {
    const word = 'abcd';
    component.companyKeywordFormGroup.get('term').setValue(word);
    tick(300);
    const keyword = component.companyKeywordFormGroup.value;
    expect(keyword.term).toBe(word);
  }));
});
