import { Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy } from '@angular/core';
import { BaseFormGroup } from '../../forms/base-form-group';
import { BaseFormControl } from '../../forms/base-form-control';
import { ApiService } from '../../services/api.service';
import { Country, CountryLookup } from '../../models/CountryLookup';
import { State } from '../../models/StatesLookup';
import { County } from '../../models/CountyLookup';
import { CityState } from '../../models/CityLookup';
import { GridColumn } from '../../models/GridColumn';
import { SumoLoggerService } from '../../services/sumo-logger.service';
import { TreeViewDataHelper } from '../../components/multi-checkbox-tree-dropdown/multi-checkbox-tree-dropdown.component';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { Subscription } from 'rxjs';
import { isNil, isString, isObject, isEqual, isEmpty, isArray, remove } from 'lodash';

/**
 * Address form component
 */
@Component({
  selector: 'app-address-form',
  templateUrl: './address-form.component.html',
  changeDetection: ChangeDetectionStrategy.Default
})
export class AddressFormComponent implements OnInit, OnDestroy {
  // Form group title
  @Input() parentDisplayName: string;
  // Form group name
  @Input() parentControlName: string;
  // Deafult Country
  @Input() defaultCountry: Array<string>;
  // Project/Company Address Form Group
  addressFormGroup: BaseFormGroup;
  // Location form group
  locationFormGroup: BaseFormGroup;
  // Country control
  countryFormGroup: BaseFormGroup;
  stateFormGroup: BaseFormGroup;
  countyFormGroup: BaseFormGroup;
  cityFormGroup: BaseFormGroup;
  codesFormControl: BaseFormControl;
  countryColumns: GridColumn[];
  stateColumns: GridColumn[];
  countries: Country[];
  states: State[];
  counties: County[];
  cities: CityState[];
  dropdownCounty = [];
  dropdownCity = [];
  selectedCountry: Array<any>;

  /** Subscription */
  mainFormReadySubscription: Subscription;
  clearFormSubscription: Subscription;
  countryFormSubscription: Subscription;
  stateFormSubscription: Subscription;

  constructor(private api: ApiService, private logger: SumoLoggerService, public leftSidebarService: LeftSidebarService,
    private lookupApiService: LookupApiService) {
    // Country dropdown config
    this.countryColumns = [
      { name: 'Country Name', prop: 'name' }
    ];

    // State dropdown config
    this.stateColumns = [
      { name: 'STATE NAME', prop: 'name' }
    ];

    this.countryFormGroup = new BaseFormGroup('countryForm', {
      codes: new BaseFormControl('Codes', 'codes', 'select', '', null, [])
    });
    this.stateFormGroup = new BaseFormGroup('stateForm', {
      codes: new BaseFormControl('Codes', 'codes', 'select', [], null, [])
    });
    this.countyFormGroup = new BaseFormGroup('countyForm', {
      codes: new BaseFormControl('Codes', 'codes', 'select', [], null, [])
    });
    this.cityFormGroup = new BaseFormGroup('cityForm', {
      codes: new BaseFormControl('Codes', 'codes', 'select', [], null, [])
    });

    // location form group
    this.locationFormGroup = new BaseFormGroup('locationForm', {
      address: new BaseFormControl('Address', 'address', 'text', '', [], []),
      zip: new BaseFormControl('Zip', 'zip', 'text', '', [], []),
      countries: this.countryFormGroup,
      states: this.stateFormGroup,
      counties: this.countyFormGroup,
      cities: this.cityFormGroup,
    });
    // bind all forms to base address form
    this.addressFormGroup = new BaseFormGroup('addressForm', {
      location: this.locationFormGroup
    });
  }
  ngOnInit() {
    // Get all countries list
    this.getCountries();
    // Push form on ready
    this.mainFormReadySubscription = this.leftSidebarService.mainFormReady$.subscribe((status) => {
      if (status) {
        this.addRemoveControls(true);
      }
    });
    // Reset field
    this.clearFormSubscription = this.leftSidebarService.clearForm$.subscribe((control) => {
      if (!isNil(control)) {
        if (isString(control)) {
          if (control === 'all') {
            this.addressFormGroup.reset({
              location: {
                address: '',
                zip: '',
                countries: {
                  codes: (this.defaultCountry) ? this.defaultCountry : []
                },
                states: {
                  codes: []
                },
                counties: {
                  codes: []
                },
                cities: {
                  codes: []
                }
              }
            });
          } else {
            if (control.includes(this.parentControlName)) {
              const clearControl = control.split('.');
              remove(clearControl, val => val === this.parentControlName);
              if (!isNil(this.addressFormGroup.get(clearControl))) {
                this.addressFormGroup.get(clearControl).reset();
              }
            }
          }
        } else if (isObject(control)) {
          if (control.control.includes(this.parentControlName)) {
            const clearValue = control.value;
            const clearControl = control.control.split('.');
            remove(clearControl, val => val === this.parentControlName);
            if (!isNil(this.addressFormGroup.get(clearControl))) {
              if (isNil(clearValue)) {
                this.addressFormGroup.get(clearControl).reset();
              } else {
                const currentValue = this.addressFormGroup.get(clearControl).value;
                if (isArray(currentValue)) {
                  remove(currentValue, val => val === clearValue);
                  this.addressFormGroup.get(clearControl).setValue(currentValue);
                } else {
                  this.addressFormGroup.get(clearControl).reset();
                }
              }
            }
          }
        }
      }
    });
    this.countryFormSubscription = this.countryFormGroup.valueChanges.subscribe((newval) => {
      if (!isEqual(this.selectedCountry, newval)) {
        this.selectedCountry = newval;
        this.states = [];
        this.counties = [];
        this.cities = [];
        this.dropdownCounty = [];
        this.dropdownCity = [];
        if (!isEmpty(newval.codes)) {
          this.getStates(newval.codes);
        }
      }
    });
    this.stateFormSubscription = this.stateFormGroup.valueChanges.subscribe((newval) => {
      if (!isEmpty(newval.codes)) {
        this.counties = [];
        this.cities = [];
        this.getCounties(newval.codes.join());
        this.getCities(newval.codes.join());
      } else {
        this.counties = [];
        this.cities = [];
        this.dropdownCounty = [];
        this.dropdownCity = [];
      }
    });
  }

  ngOnDestroy() {
    if (this.mainFormReadySubscription) {
      this.mainFormReadySubscription.unsubscribe();
    }
    if (this.clearFormSubscription) {
      this.clearFormSubscription.unsubscribe();
    }
    if (this.countryFormSubscription) {
      this.countryFormSubscription.unsubscribe();
    }
    if (this.stateFormSubscription) {
      this.stateFormSubscription.unsubscribe();
    }
    this.addRemoveControls(false);
  }

  /**
   * Country lookup api call
   */
  getCountries() {
    this.lookupApiService.getCountries().subscribe(
      (res) => {
        this.countries = this.arrangeCountries(res).data.countries;
        if (this.defaultCountry) {
          this.countryFormGroup.get('codes').setValue(this.defaultCountry);
        }
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * States lookup api call
   * @param country Country selected by user
   */
  getStates(country) {
    this.lookupApiService.getStates(country).subscribe(
      (res) => {
        this.states = res.data.states;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * County lookup api call
   * @param state States selected by user
   */
  getCounties(state) {
    this.lookupApiService.getCounties(state).subscribe(
      (res) => {
        this.counties = res.data.states;
        const tempArray = this.dropdownCounty;
        this.dropdownCounty = TreeViewDataHelper.formatCountyDropdown(this.counties, tempArray);
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * City lookup api call
   * @param state States selected by user
   */
  getCities(state) {
    this.lookupApiService.getCities(state).subscribe(
      (res) => {
        this.cities = res.data.states;
        const tempArray = this.dropdownCity;
        this.dropdownCity = TreeViewDataHelper.formatCityDropdown(this.cities, tempArray);
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  private arrangeCountries(lookupData: CountryLookup): CountryLookup {
    const priorityCountryIds: Array<string> = ['USA', 'CAN', 'MEX', 'PRI', 'VIR', 'GUM'];
    const countriesWithPriority: Array<Country> = [];
    const countriesWithoutPriority: Array<Country> = lookupData.data.countries.reduce((countries, currentCountry) => {
      if (!priorityCountryIds.includes(currentCountry.id)) {
        countries.push(currentCountry);
      }
      return countries;
    }, []);

    priorityCountryIds.forEach((val) => {
      countriesWithPriority.push(lookupData.data.countries.filter(country => country.id === val)[0]);
    });

    lookupData.data.countries = [...countriesWithPriority, ...countriesWithoutPriority];

    return lookupData;
  }

  /** Add / Remove Controls */
  addRemoveControls(addControls: boolean) {
    if (addControls) {
      if (!this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentGroupControlName = this.parentControlName + 'FormGroup';
        const parentGroupControl = new BaseFormGroup(parentGroupControlName, {});
        this.leftSidebarService.getMainForm.addControl(this.parentControlName, parentGroupControl);
      }
      const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
      parentFormGroup.addControl('location', this.locationFormGroup);
    } else {
      if (this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
        parentFormGroup.removeControl('location');
        if (Object.keys((this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup).controls).length === 0) {
          this.leftSidebarService.getMainForm.removeControl(this.parentControlName);
        }
      }
    }
  }
}
