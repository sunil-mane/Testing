import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { SharedModule } from '../../shared.module';
import { AddressFormComponent } from './address-form.component';
import { TreeviewModule } from 'ngx-treeview';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { ApiService } from '../../services/api.service';
import { AlertService } from '../../services/alert.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LookupApiService } from '../../services/lookup-api.service';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';

describe('AddressFormComponent', () => {
  let component: AddressFormComponent;
  let fixture: ComponentFixture<AddressFormComponent>;
  let leftSidebar: LeftSidebarService;
  let identifier: string;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, HttpClientTestingModule, RouterTestingModule,
        SharedModule.forRoot(), TreeviewModule.forRoot()],
      providers: [LocationStrategy, PathLocationStrategy, LeftSidebarService, ApiService, AlertService, LookupApiService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressFormComponent);
    component = fixture.componentInstance;

    leftSidebar = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'projectSearch';
    leftSidebar.pushFormControlStatusList(leftSidebarFilter[identifier]);

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getCountries method', fakeAsync(() => {
    const spy = spyOn(component, 'getCountries');
    component.ngOnInit();
    tick(300);
    expect(spy).toHaveBeenCalled();
  }));

  it('should call getStates when we change the country', fakeAsync(() => {
    const spy = spyOn(component, 'getStates');
    component.countryFormGroup.get('codes').setValue(['USA']);
    tick(300);
    expect(spy).toHaveBeenCalled();
  }));

  it('should call getCounty when we change the state', fakeAsync(() => {
    const spy = spyOn(component, 'getCounties');
    const spyCity = spyOn(component, 'getCities');
    component.stateFormGroup.get('codes').setValue(['USAAL']);
    tick(300);
    expect(spy).toHaveBeenCalled();
    expect(spyCity).toHaveBeenCalled();
  }));

});
