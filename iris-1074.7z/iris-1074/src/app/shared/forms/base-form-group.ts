import { FormControl, FormGroup } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { BaseFormControl } from './base-form-control';
import { Subscription } from 'rxjs';
/**
 * A common user form which will extend reactive form and also manage state of form..
 * This will return a reactive form with one to one mapping with user model properties
 */
export class BaseFormGroup extends FormGroup {
  // unique key to add form states
  key: string;
  // observable for form values
  formObservable: Subscription;
  /**
   * Constructor
   * @params key: unique key associated with form
   */
  constructor(private formKey: string, public controls: any) {
    super(controls);
    this.key = formKey;
  }
  /**
  * Initialize state management for forms
  */
  initializeFormStates() {
    // create the state service by using injector
    this.formObservable = this.valueChanges.pipe(debounceTime(1000)).pipe(distinctUntilChanged()).subscribe(form => {
      // todo: add logic to save state in redux.
    });
  }
  /**
   * Clear state of form when for is submitted.
   */
  clearFormState() {
    // remove form from states
    // unsubscribe for form observable
    if (this.formObservable) {
      this.formObservable.unsubscribe();
    }
    // todo: add logic to remove form state.
  }
  /**
   * Reset form state to previous state.
   */
  resetFormState() {
    // todo: Add logic to reset previous form state.
  }
  /**
   * Set values of form from previous state
   */
  public applyFormValues(group, formValues) {
    // iterate through each key
    Object.keys(formValues).forEach(key => {
      const formControl = <FormControl>group.controls[key];
      if (formControl instanceof FormGroup) {
        this.applyFormValues(formControl, formValues[key]);
      } else {
        if (formControl) {
          formControl.setValue(formValues[key]);
        }
      }
    });
  }
  /**
   * Get all form controls from form
   * @returns List of CommonFormControl from current form
   */
  get formControls(): BaseFormControl[] {
    return Object.keys(this.controls)
      .map(k => this.controls[k] as BaseFormControl);
  }
  /**
   * Get all form control validation messages
   * @returns List of string with all form validation messages.
   */
  getFormValidationMessages(): string[] {
    const messages: string[] = [];

    this.formControls.forEach((c) => {
      if (c instanceof BaseFormGroup) {
        c.formControls.forEach(control => control.getValidationMessages()
          .forEach(m => messages.push(m)));
      } else {
        this.formControls.forEach(control => control.getValidationMessages()
          .forEach(m => messages.push(m)));
      }
    });

    return messages;
  }
}
