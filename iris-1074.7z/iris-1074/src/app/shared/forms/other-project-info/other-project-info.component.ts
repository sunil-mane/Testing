import { Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy } from '@angular/core';
import { Subscription } from 'rxjs';
import { BaseFormGroup } from '../../forms/base-form-group';
import { BaseFormControl } from '../../forms/base-form-control';
import { LookupApiService } from '../../services/lookup-api.service';
import { TreeViewDataHelper } from '../../components/multi-checkbox-tree-dropdown/multi-checkbox-tree-dropdown.component';
import { Stages } from '../../models/ProjectStageLookup';
import { ProjectTypes } from '../../models/ProjectTypeLookup';
import { Valuation } from '../../models/ValuationLookup';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import * as moment from 'moment';
import { isEmpty, isNil, isString, isObject, isArray, remove } from 'lodash';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { environment } from '../../../../environments/environment';
/**
 * Project Search other info Form Group
 */
@Component({
  selector: 'app-other-project-info',
  templateUrl: './other-project-info.component.html',
  styleUrls: ['./other-project-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class OtherProjectInfoComponent implements OnInit, OnDestroy {

  // Form group title
  @Input() parentDisplayName: string;
  // Form group name
  @Input() parentControlName: string;
  // other info valuation group
  otherInfoValuationGroup: BaseFormGroup;
  // other info issue date group
  otherInfoIssueDateGroup: BaseFormGroup;
  // other info main project group
  otherInfoProjectGroup: BaseFormGroup;

  // form controls
  // project title controls
  otherInfoValuationMinControl: BaseFormControl = new BaseFormControl('Valuation Min', 'min', 'min', '', [], []);
  otherInfoValuationMaxControl: BaseFormControl = new BaseFormControl('Valuation Max', 'max', 'max', false, [], []);

  // project keyword controls
  otherInfoProjectStageControl: BaseFormControl = new BaseFormControl('Project Stage', 'stages', 'term', [], [], []);
  otherInfoProjectTypeControl: BaseFormControl = new BaseFormControl('Project Type', 'types', 'text', [], [], []);

  // date controls
  startDateDefault: string = moment().startOf('month').subtract(1, 'years').format(environment.apiDateFormat);
  endDateDefault: string = moment().format(environment.apiDateFormat);

  // minDateValidation
  minValidationDate: NgbDateStruct = { year: 1999, month: 2, day: 3 };
  maxValidationDate: NgbDateStruct = { year: new Date().getFullYear() + 5, month: 1, day: 1 };

  maxIssueDateStart: NgbDateStruct;
  startDateControl: BaseFormControl = new BaseFormControl('Start', 'start', 'text', this.startDateDefault, [], []);
  endDateControl: BaseFormControl = new BaseFormControl('End', 'end', 'text', this.endDateDefault, [], []);

  // dropdown data
  dropdownProjectStage = [];
  dropdownProjectType = [];

  valuationData = [];
  valuationMinData = [];
  valuationMaxData = [];
  // columns
  // Valuation Min dropdown config
  valuationLowColumns = [
    { name: 'Code', prop: 'id' },
    { name: 'Low Value', prop: 'low' }
  ];
  // Valuation Max dropdown config
  valuationHighColumns = [
    { name: 'Code', prop: 'id' },
    { name: 'High Value', prop: 'high' }
  ];

  // Subscriptions
  mainFormReadySubscription: Subscription;
  clearFormSubscription: Subscription;
  otherInfoValuationMinControlSubscription: Subscription;
  startDateControlSubscription: Subscription;

  constructor(private lookupApiService: LookupApiService, public leftSidebarService: LeftSidebarService) {
    // create other info valuation group
    this.otherInfoValuationGroup = new BaseFormGroup('otherInfoValuation', {
      range: new BaseFormGroup('otherInfoValuationRange', {
        min: this.otherInfoValuationMinControl,
        max: this.otherInfoValuationMaxControl
      })
    });
    // create issue data group
    this.otherInfoIssueDateGroup = new BaseFormGroup('otherInfoIssueDate', {
      dateRange: new BaseFormGroup('otherInfoDateRange', {
        start: this.startDateControl,
        end: this.endDateControl
      })
    });
    // create main form
    this.otherInfoProjectGroup = new BaseFormGroup('otherInfoProjectGroup', {
      valuation: this.otherInfoValuationGroup,
      issue: this.otherInfoIssueDateGroup,
      stages: this.otherInfoProjectStageControl,
      types: this.otherInfoProjectTypeControl
    });
  }
  /**
  * On init method
  */
  ngOnInit() {
    // When main form is ready push other project info form controls
    this.mainFormReadySubscription = this.leftSidebarService.mainFormReady$.subscribe((status) => {
      if (status) {
        this.addRemoveControls(true);
      }
    });
    // Reset field
    this.clearFormSubscription = this.leftSidebarService.clearForm$.subscribe((control) => {
      if (!isNil(control)) {
        if (isString(control)) {
          if (control === 'all') {
            this.otherInfoProjectGroup.reset({
              valuation: {
                range: {
                  min: '',
                  max: ''
                }
              },
              issue: {
                dateRange: {
                  start: this.startDateDefault,
                  end: this.endDateDefault
                }
              },
              stages: [],
              types: []
            });
          } else if (control === 'project.issue.dateRange.start' || control === 'project.issue.dateRange.end') {
            this.otherInfoIssueDateGroup.reset();
          } else {
            if (control.includes(this.parentControlName)) {
              const clearControl = control.split('.');
              remove(clearControl, val => val === this.parentControlName);
              if (!isNil(this.otherInfoProjectGroup.get(clearControl))) {
                this.otherInfoProjectGroup.get(clearControl).reset();
              }
            }
          }
        } else if (isObject(control)) {
          if (control.control.includes(this.parentControlName)) {
            const clearValue = control.value;
            const clearControl = control.control.split('.');
            remove(clearControl, val => val === this.parentControlName);
            if (!isNil(this.otherInfoProjectGroup.get(clearControl))) {
              const currentValue = this.otherInfoProjectGroup.get(clearControl).value;
              if (isArray(currentValue)) {
                remove(currentValue, val => val === clearValue);
                this.otherInfoProjectGroup.get(clearControl).setValue(currentValue);
              } else {
                this.otherInfoProjectGroup.get(clearControl).reset();
              }
            }
          }
        }
      }
    });

    // get project stage data from api
    this.getProjectStageData().then((stages: Stages[]) => {
      const currentStageDropdown = this.dropdownProjectStage;
      this.dropdownProjectStage = TreeViewDataHelper.formatProjectStageDropdown(stages, currentStageDropdown);
    });
    // get project stage data from api
    this.getProjectTypeData().then((types: ProjectTypes[]) => {
      const currentTypeDropdown = this.dropdownProjectType;
      this.dropdownProjectType = TreeViewDataHelper.formatProjectTypesDropdown(types, currentTypeDropdown);
    });
    // get project stage data from api
    this.getProjectValuationData().then((valuations: Valuation[]) => {
      this.valuationData = valuations;
      this.valuationMinData = valuations;
    });

    // validation logic
    // set max value bydefault disabled
    this.otherInfoValuationMaxControl.disable();
    // enable max dropdown once we select min value from min valuation.
    this.otherInfoValuationMinControlSubscription = this.otherInfoValuationMinControl.valueChanges.subscribe((newval) => {
      if (isEmpty(newval)) {
        this.valuationMaxData = [];
        this.otherInfoValuationMaxControl.disable();
      } else {
        const minObj = this.valuationData.find(x => x.id === newval);
        const maxValuation = this.valuationData.filter(x => x.high >= minObj.low);
        this.valuationMaxData = maxValuation;
        this.otherInfoValuationMaxControl.enable();
      }
    });

    // issue date
    this.startDateControlSubscription = this.startDateControl.valueChanges.subscribe((newval: string) => {
      if (!newval) {
        this.endDateControl.disable();
        this.endDateControl.setValue('');
      } else {
        this.endDateControl.enable();
        // set start date as min date to issue max date
        const minDate = moment(newval, environment.apiDateFormat);
        // empty the field if date is already there and its invalid
        if (this.endDateControl.value) {
          const endDate = moment(this.endDateControl.value, environment.apiDateFormat);
          if (minDate.isAfter(endDate)) {
            this.endDateControl.setValue('');
          }
        }
        this.maxIssueDateStart = { year: minDate.get('year'), month: minDate.get('month'), day: minDate.get('date') };
      }
    });
  }

  ngOnDestroy() {
    if (this.mainFormReadySubscription) {
      this.mainFormReadySubscription.unsubscribe();
    }
    if (this.clearFormSubscription) {
      this.clearFormSubscription.unsubscribe();
    }
    if (this.otherInfoValuationMinControlSubscription) {
      this.otherInfoValuationMinControlSubscription.unsubscribe();
    }
    if (this.startDateControlSubscription) {
      this.startDateControlSubscription.unsubscribe();
    }
    this.addRemoveControls(false);
  }

  /**
    * get project stage data from promise
    * @returns promise object with list of stages
    */
  getProjectStageData(): Promise<Stages[]> {
    // create a promise and send data back once response is received.
    const promise = new Promise<Stages[]>((resolve, reject) => {
      this.lookupApiService.getProjectStages().subscribe(
        (res) => {
          resolve(res.data.stages);
        },
        (err) => {
          reject([]);
        }
      );
    });
    return promise;
  }
  /**
    * get project type data from promise
    * @returns promise object with list of stages
    */
  getProjectTypeData(): Promise<ProjectTypes[]> {
    // create a promise and send data back once response is received.
    const promise = new Promise<ProjectTypes[]>((resolve, reject) => {
      this.lookupApiService.getProjectTypes().subscribe(
        (res) => {
          resolve(res.data.types);
        },
        (err) => {
          reject([]);
        }
      );
    });
    return promise;
  }
  /**
    * get project type data from promise
    * @returns promise object with list of stages
    */
  getProjectValuationData(): Promise<Valuation[]> {
    // create a promise and send data back once response is received.
    const promise = new Promise<Valuation[]>((resolve, reject) => {
      this.lookupApiService.getValuations().subscribe(
        (res) => {
          resolve(res.data.valuations);
        },
        (err) => {
          reject([]);
        }
      );
    });
    return promise;
  }

  /** Add / Remove Controls */
  addRemoveControls(addControls: boolean) {
    if (addControls) {
      if (!this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentGroupControlName = this.parentControlName + 'FormGroup';
        const parentGroupControl = new BaseFormGroup(parentGroupControlName, {});
        this.leftSidebarService.getMainForm.addControl(this.parentControlName, parentGroupControl);
      }
      const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
      parentFormGroup.addControl('valuation', this.otherInfoValuationGroup);
      parentFormGroup.addControl('issue', this.otherInfoIssueDateGroup);
      parentFormGroup.addControl('stages', this.otherInfoProjectStageControl);
      parentFormGroup.addControl('types', this.otherInfoProjectTypeControl);
    } else {
      if (this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
        parentFormGroup.removeControl('valuation');
        parentFormGroup.removeControl('issue');
        parentFormGroup.removeControl('stages');
        parentFormGroup.removeControl('types');
        if (Object.keys((this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup).controls).length === 0) {
          this.leftSidebarService.getMainForm.removeControl(this.parentControlName);
        }
      }
    }
  }
}
