import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { SharedModule } from '../../shared.module';
import { BaseFormControl } from '../../forms/base-form-control';
import { ApiService } from '../../services/api.service';
import { TreeViewDataHelper } from '../../components/multi-checkbox-tree-dropdown/multi-checkbox-tree-dropdown.component';
import { ProjectStageLookup, Stages } from '../../models/ProjectStageLookup';
import { environment } from '../../../../environments/environment';
import { OtherProjectInfoComponent } from './other-project-info.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LookupApiService } from '../../services/lookup-api.service';
import { Lookups } from '../../../../mocks/lookups';
import { LeftSidebarService } from '../../services/left-sidebar.service';
describe('OtherProjectInfoComponent', () => {
  let component: OtherProjectInfoComponent;
  let fixture: ComponentFixture<OtherProjectInfoComponent>;
  let httpMock: HttpTestingController;
  let leftSidebar: LeftSidebarService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), RouterTestingModule, HttpClientTestingModule],
      declarations: [],
      providers: [LookupApiService]
    })
      .compileComponents();
  }));
  afterEach(() => {
    // httpMock.verify();
  });
  beforeEach(() => {
    fixture = TestBed.createComponent(OtherProjectInfoComponent);
    component = fixture.componentInstance;
    httpMock = getTestBed().get(HttpTestingController);
    leftSidebar = fixture.debugElement.injector.get(LeftSidebarService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should initialize variables', () => {
    expect(component.otherInfoIssueDateGroup).toBeTruthy();
    expect(component.otherInfoProjectGroup).toBeTruthy();
    expect(component.otherInfoValuationGroup).toBeTruthy();
    expect(component.otherInfoProjectTypeControl).toBeTruthy();
  });
  it('should call api methods when init is called', async () => {
    const projectStageSpy = spyOn(component, 'getProjectStageData').and.returnValue(Promise.resolve([]));
    const projectTypeSpy = spyOn(component, 'getProjectTypeData').and.returnValue(Promise.resolve([]));
    const projectValuationSpy = spyOn(component, 'getProjectValuationData').and.returnValue(Promise.resolve([]));
    component.ngOnInit();
    expect(projectStageSpy).toHaveBeenCalled();
    expect(projectTypeSpy).toHaveBeenCalled();
    expect(projectValuationSpy).toHaveBeenCalled();
  });
  it('should receive project type when api is called', async () => {
    const mockProjectTypes: any = Lookups.getProjectType();
    component.getProjectTypeData().then((stages) => {
      expect(stages).toEqual(mockProjectTypes.data.types);
    });
    const req = httpMock.expectOne(`https://api.dodgedev.com/cc/iris/lookup/projectTypeWithParent`);
    expect(req.request.method).toBe('GET');
    req.flush(mockProjectTypes);
    httpMock.verify();
  });
  it('should receive project valuation when api is called', async () => {
    const mockValuationTypes: any = Lookups.getValuation(1);
    component.getProjectValuationData().then((valuations) => {
      expect(valuations).toEqual(mockValuationTypes.data.valuations);
    });
    const req = httpMock.expectOne(`https://api.dodgedev.com/cc/iris/lookup/valuation`);
    expect(req.request.method).toBe('GET');
    req.flush(mockValuationTypes);
    httpMock.verify();
  });
  it('should receive project stages when api is called', async () => {
    const mockValuationTypes: any = Lookups.getProjectStage(1);
    component.getProjectStageData().then((stages) => {
      expect(stages).toEqual(mockValuationTypes.data.stages);
    });
    const req = httpMock.expectOne(`https://api.dodgedev.com/cc/iris/lookup/projectStage`);
    expect(req.request.method).toBe('GET');
    req.flush(mockValuationTypes);
    httpMock.verify();
  });
  it('should set end date validation project when start date is selected', () => {
    component.ngOnInit();
    component.startDateControl.setValue('');
    // fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.endDateControl.value).toBe('');
      expect(component.endDateControl.enabled).toBe(false);
    });
  });
  it('should set end date validation project when start date is selected', () => {
    component.ngOnInit();
    component.startDateControl.setValue('2018-2-2');
    // fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.endDateControl.enabled).toBe(true);
      expect(component.maxIssueDateStart.year).toBe(2018);
    });
  });
  it('should set end date empty when future start date is selected', () => {
    component.ngOnInit();
    component.startDateControl.setValue('2018-2-2');
    component.endDateControl.setValue('2018-3-2');
    component.startDateControl.setValue('2018-4-2');
    // fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.endDateControl.value).toBe('');
    });
  });
  it('should disable max valuation when  empty min is set', () => {
    component.ngOnInit();
    expect(component.otherInfoValuationMaxControl.enabled).toBe(false);
    component.otherInfoValuationMinControl.setValue('');
    fixture.whenStable().then(() => {
      expect(component.otherInfoValuationMaxControl.enabled).toBe(false);
      expect(component.valuationMaxData.length).toBe(0);
    });
  });
  it('should enable max valuation when min is set', () => {
    component.ngOnInit();
    expect(component.otherInfoValuationMaxControl.enabled).toBe(false);
    component.otherInfoValuationMinControl.setValue('L');
    fixture.whenStable().then(() => {
      expect(component.otherInfoValuationMaxControl.enabled).toBe(true);
    });
  });
  it('should enable max valuation when min is set', async () => {
    component.ngOnInit();
    fixture.whenStable().then(() => {
      expect(component.otherInfoValuationMaxControl.enabled).toBe(false);
    });
  });
});
