import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule, FormArray } from '@angular/forms';
import { ProjectSearchFormComponent } from './project-search-form.component';
import { SharedModule } from '../../shared.module';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { ApiService } from '../../services/api.service';
import { AlertService } from '../../services/alert.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';

describe('ProjectSearchFormComponent', () => {
  let component: ProjectSearchFormComponent;
  let fixture: ComponentFixture<ProjectSearchFormComponent>;
  let leftSidebar: LeftSidebarService;
  let identifier: string;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, SharedModule.forRoot(), NgbDatepickerModule.forRoot(),
        HttpClientTestingModule, RouterTestingModule],
      providers: [LeftSidebarService, ApiService, AlertService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectSearchFormComponent);
    component = fixture.componentInstance;

    leftSidebar = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'projectSearch';
    leftSidebar.pushFormControlStatusList(leftSidebarFilter[identifier]);

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should create all variables', () => {
    component.ngOnInit();
    fixture.whenStable().then(() => {
      expect(component.projectContractNumber).toBeTruthy();
      expect(component.projectTitleFormGroup).toBeTruthy();
      expect(component.projectBidDateFormGroup).toBeTruthy();
      expect(component.projectInfoFormGroup).toBeTruthy();
    });
  });
  it('expect default values', () => {
    component.ngOnInit();
    fixture.whenStable().then(() => {
      // check default disabled status of end date to be true
      expect(component.endDateControl.disabled).toEqual(true);
      component.startDateControl.setValue('07/02/2018');
      expect(component.startDateControl.value).toEqual('07/02/2018');
    });
  });
  it('should set end date validation project when start date is selected', () => {
    component.ngOnInit();
    component.startDateControl.setValue('');
    // fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.endDateControl.value).toBe('');
      expect(component.endDateControl.enabled).toBe(false);
    });
  });
  it('should set end date validation project when start date is selected', () => {
    component.ngOnInit();
    component.startDateControl.setValue('2018-2-2');
    // fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.endDateControl.enabled).toBe(true);
      expect(component.maxBidDateStart.year).toBe(2018);
    });
  });
  it('should set end date empty when future start date is selected', () => {
    component.ngOnInit();
    component.startDateControl.setValue('2018-2-2');
    component.endDateControl.setValue('2018-3-2');
    component.startDateControl.setValue('2018-4-2');
    // fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.endDateControl.value).toBe('');
    });
  });
  it('should push item when ischecked is called', () => {
    component.ngOnInit();
    component.onCheckChange({ target: { checked: true, value: 'asap' } });
    fixture.whenStable().then(() => {
      expect(component.dateCodesControl.value.length).toBe(1);

      // reset control
      component.onCheckChange({ target: { checked: false, value: 'asap' } });
      expect(component.dateCodesControl.value.length).toBe(0);
    });
  });
});
