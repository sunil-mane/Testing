import { Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy } from '@angular/core';
import { BaseFormGroup } from '../../forms/base-form-group';
import { BaseFormControl } from '../../forms/base-form-control';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import * as moment from 'moment';
import { cloneDeep, isNil, isString, isObject, isArray, remove } from 'lodash';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-project-search-form',
  templateUrl: './project-search-form.component.html',
  changeDetection: ChangeDetectionStrategy.Default
})
export class ProjectSearchFormComponent implements OnInit, OnDestroy {

  // Form group title
  @Input() parentDisplayName: string;
  // Form group name
  @Input() parentControlName: string;
  // project info form group object
  projectInfoFormGroup: BaseFormGroup;
  // project title form group object
  projectTitleFormGroup: BaseFormGroup;
  // project bid date form group object
  projectBidDateFormGroup: BaseFormGroup;
  // project keyword form group object
  projectKeywordFormGroup: BaseFormGroup;

  public bidDateChoices: Array<any> = [
    { title: 'ASAP', value: 'asap', checked: false },
    { title: 'NDS', value: 'no-date-set', checked: false }
  ];

  // project title controls
  projectTitleControl: BaseFormControl = new BaseFormControl('Title', 'term', 'term', '', [], []);
  projectExactMatchControl: BaseFormControl = new BaseFormControl('Title Option', 'exactMatch', 'checkbox', true, [], []);

  // project keyword controls
  projectKeywordTitleControl: BaseFormControl = new BaseFormControl('Keyword', 'term', 'term', '', [], []);
  projectKeywordExactMatchControl: BaseFormControl = new BaseFormControl('Keyword Option', 'exactMatch', 'checkbox', true, [], []);

  // contract number
  projectContractNumber: BaseFormControl = new BaseFormControl('Contract #', 'projectContractNumber', 'text', '', [], []);
  // date controls
  // minDateValidation
  minValidationDate: NgbDateStruct = { year: 1998, month: 1, day: 1 };
  maxValidationDate: NgbDateStruct = { year: new Date().getFullYear() + 5, month: 1, day: 1 };

  maxBidDateStart: NgbDateStruct;
  startDateControl: BaseFormControl = new BaseFormControl('Start', 'start', 'start', '', [], []);
  endDateControl: BaseFormControl = new BaseFormControl('End', 'end', 'end', '', [], []);

  contractNumberControl: BaseFormControl = new BaseFormControl('Contract #', 'contractNumber', 'contractNumber', '', [], []);

  // form array for date codes
  dateCodesControl: FormArray = new FormArray([]);

  // Subscriptions
  private mainFormReadySubscrition: Subscription;
  private clearFormSubscription: Subscription;
  private startDateContronSubscription: Subscription;

  constructor(public leftSidebarService: LeftSidebarService) {
    // initialize all objects
    this.projectTitleFormGroup = new BaseFormGroup('projectTitle', {
      term: this.projectTitleControl,
      exactMatch: this.projectExactMatchControl
    });
    this.projectKeywordFormGroup = new BaseFormGroup('projectKeyword', {
      term: this.projectKeywordTitleControl,
      exactMatch: this.projectKeywordExactMatchControl
    });
    this.projectBidDateFormGroup = new BaseFormGroup('projectBidDate', {
      dateRange: new FormGroup({
        start: this.startDateControl,
        end: this.endDateControl
      }),
      dateCodes: this.dateCodesControl
    });
    // bind all forms to base info form
    this.projectInfoFormGroup = new BaseFormGroup('projectInfoForm', {
      title: this.projectTitleFormGroup,
      contractNumber: this.projectContractNumber,
      keyword: this.projectKeywordFormGroup,
      bid: this.projectBidDateFormGroup
    });
  }

  /**
   * On Init method
   */
  ngOnInit() {
    // When main form is ready push project search form controls
    this.mainFormReadySubscrition = this.leftSidebarService.mainFormReady$.subscribe((status) => {
      if (status) {
        this.addRemoveControls(true);
      }
    });

    // Reset field
    this.clearFormSubscription = this.leftSidebarService.clearForm$.subscribe((control) => {
      if (!isNil(control)) {
        if (isString(control)) {
          if (control === 'all') {
            this.resetDateCodeControl();
            this.projectInfoFormGroup.reset({
              title: {
                term: '',
                exactMatch: true
              },
              keyword: {
                term: '',
                exactMatch: true
              },
              contractNumber: '',
              bid: {
                dateRange: {
                  start: '',
                  end: ''
                },
                dateCodes: []
              }
            });
          } else {
            if (control.includes(this.parentControlName)) {
              const clearControl = control.split('.');
              remove(clearControl, val => val === this.parentControlName);
              if (clearControl[0] === 'bid') {
                this.projectInfoFormGroup.get('bid.dateRange.start').reset();
                this.projectInfoFormGroup.get('bid.dateRange.end').reset();
                this.resetDateCodeControl();
              } else {
                if (!isNil(this.projectInfoFormGroup.get(clearControl))) {
                  this.projectInfoFormGroup.get(clearControl).reset();
                }
              }
            }
          }
        } else if (isObject(control)) {
          if (control.control === 'project.bid.dateCodes') {
            this.resetDateCodeControl();
          } else if (control.control.includes(this.parentControlName)) {
            const clearValue = control.value;
            const clearControl = control.control.split('.');
            remove(clearControl, val => val === this.parentControlName);
            if (!isNil(this.projectInfoFormGroup.get(clearControl))) {
              const currentValue = this.projectInfoFormGroup.get(clearControl).value;
              if (isArray(currentValue)) {
                remove(currentValue, val => val === clearValue);
                this.projectInfoFormGroup.get(clearControl).setValue(currentValue);
              } else {
                this.projectInfoFormGroup.get(clearControl).reset();
              }
            }
          }
        }
      }
    });

    // issue date
    this.endDateControl.disable();
    this.startDateContronSubscription = this.startDateControl.valueChanges.subscribe((newval: string) => {
      if (!newval) {
        this.endDateControl.disable();
        this.endDateControl.setValue('');
      } else {
        this.endDateControl.enable();
        // set start date as min date to issue max date
        const minDate = moment(newval, environment.apiDateFormat);
        // empty the field if date is already there and its invalid
        if (this.endDateControl.value) {
          const endDate = moment(this.endDateControl.value, environment.apiDateFormat);
          if (minDate.isAfter(endDate)) {
            this.endDateControl.setValue('');
          }
        }
        this.maxBidDateStart = { year: minDate.get('year'), month: minDate.get('month') + 1, day: minDate.get('date') };
      }
    });
  }

  ngOnDestroy() {
    /**
     * Unscribe to Obserables
     */
    if (this.mainFormReadySubscrition) {
      this.mainFormReadySubscrition.unsubscribe();
    }
    if (this.clearFormSubscription) {
      this.clearFormSubscription.unsubscribe();
    }
    if (this.startDateContronSubscription) {
      this.startDateContronSubscription.unsubscribe();
    }
    this.addRemoveControls(false);
  }

  /**
   * onCheckChange event from biddate type check
   * @params event: event from checkbox click
   */
  onCheckChange(event) {
    const formArray: FormArray = this.projectBidDateFormGroup.get('dateCodes') as FormArray;

    // if item is selected
    if (event.target.checked) {
      // Add a new control in the arrayForm
      formArray.push(new FormControl(event.target.value));
    } else {
      // if item is unselected
      // find the unselected element
      let i = 0;
      formArray.controls.forEach((ctrl: FormControl) => {
        if (ctrl.value === event.target.value) {
          // Remove the unselected element from the arrayForm
          formArray.removeAt(i);
          return;
        }
        i++;
      });
    }
  }

  /**
   * Change event handler for exactMacth checkbox
   * @param event the event object
   */
  exactMarchCheckHandler(event: MouseEvent) {
    const element = <HTMLInputElement>event.target;
    const controlPath = (element.name === 'titleAnyAll') ? 'title.exactMatch' : 'keyword.exactMatch';
    this.projectInfoFormGroup.get(controlPath).setValue(element.checked);
  }

  /** Reset dateCodes field */
  resetDateCodeControl() {
    const formArray: FormArray = this.projectBidDateFormGroup.get('dateCodes') as FormArray;
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
    const bidDateChoices = cloneDeep(this.bidDateChoices);
    bidDateChoices.forEach((choice) => { choice.checked = false; });
    this.bidDateChoices = [...bidDateChoices];
  }

  /** Add / Remove Controls */
  addRemoveControls(addControls: boolean) {
    if (addControls) {
      if (!this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentGroupControlName = this.parentControlName + 'FormGroup';
        const parentGroupControl = new BaseFormGroup(parentGroupControlName, {});
        this.leftSidebarService.getMainForm.addControl(this.parentControlName, parentGroupControl);
      }
      const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
      parentFormGroup.addControl('title', this.projectTitleFormGroup);
      parentFormGroup.addControl('contractNumber', this.projectContractNumber);
      parentFormGroup.addControl('keyword', this.projectKeywordFormGroup);
      parentFormGroup.addControl('bid', this.projectBidDateFormGroup);
    } else {
      if (this.leftSidebarService.getMainForm.get(this.parentControlName)) {
        const parentFormGroup = this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup;
        parentFormGroup.removeControl('title');
        parentFormGroup.removeControl('contractNumber');
        parentFormGroup.removeControl('keyword');
        parentFormGroup.removeControl('bid');
        if (Object.keys((this.leftSidebarService.getMainForm.get(this.parentControlName) as BaseFormGroup).controls).length === 0) {
          this.leftSidebarService.getMainForm.removeControl(this.parentControlName);
        }
      }
    }
  }
}
