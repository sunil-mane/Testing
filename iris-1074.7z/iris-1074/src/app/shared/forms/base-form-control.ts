import { FormControl } from '@angular/forms';
import { Injector } from '@angular/core';
import { MessageService } from './../../shared/services/message.service';

/**
 * A common user form control class will extend reactive form control class.
 * This will return a reactive form control with additional properties to add labels and type of control.
 */
export class BaseFormControl extends FormControl {
  // form control label
  label: string;
  // model property which will be binded to respective form control
  modelProperty: string;
  // type of form control
  type: string;
  // initial values if any to pass to initialize dropdown.
  data: any;
  // create injector for messageservice which will inject message service when required.
  injector: Injector = Injector.create([{ provide: MessageService, deps: [] }]);
  /**
   * Constructor
   * @param label: Label text to associate with form control
   * @param property: Property from model where we will bind data
   * @param type: Type of input form
   * @param value: Default value of control if any
   * @param data: Default data for dropdown if any
   * @param validator: List of validators including custom validator.
   * @returns reactive form control.
   */
  constructor(label: string, property: string, type: string, value: any, validator: any, data?: any[]) {
    super(value, { validators: validator, updateOn: 'blur' });
    this.label = label;
    this.type = type;
    this.data = data;
    this.modelProperty = property;
  }
  /**
   * Get all validation messages for perticular form control
   * @returns array of form control error messages.
   */
  public getValidationMessages(): string[] {
    // initialize messages array
    const messages: string[] = [];
    // get message service object from injector
    const messageService = this.injector.get(MessageService);
    // iterate through all errors and get message for same.
    if (this.errors) {
      for (const errorName in this.errors) {
        if (errorName) {
          messages.push(messageService.getValidationMessage(this.label, this.type, errorName, this.errors[errorName]));
        }
      }
    }
    return messages;
  }
}
