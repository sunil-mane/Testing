import { Component, Input, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { GridColumn } from '../../models/GridColumn';
import { BaseFormGroup } from '../base-form-group';
import { SumoLoggerService } from '../../services/sumo-logger.service';
import { AlertService } from '../../services/alert.service';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { BaseFormControl } from '../base-form-control';
import { isNil, isString, isEmpty, findIndex } from 'lodash';
import { FormGroup, FormControl } from '@angular/forms';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Country, CountryLookup } from '../../models/CountryLookup';
import { State } from '../../models/StatesLookup';
import { County } from '../../models/CountyLookup';
import { environment } from '../../../../environments/environment';
import { DropdownGridComponent } from './../../components/dropdown-grid/dropdown-grid.component';
import * as moment from 'moment';
import { Feed } from '../../models/Feed';

@Component({
  selector: 'app-efeed-search-form',
  templateUrl: './efeed-search-form.component.html',
  styleUrls: ['./efeed-search-form.component.scss']
})
export class EfeedSearchFormComponent implements OnInit, OnDestroy {

  // Form group title
  @Input() parentDisplayName: string;

  @ViewChild('regiondropdown') regionDropdown: DropdownGridComponent;
  @ViewChild('reporterdropdown') reporterDropdown: DropdownGridComponent;
  // Company Type columns
  companyTypeColumns: GridColumn[];
  // address
  countryColumns: GridColumn[];
  regionColumns: GridColumn[];
  feedNameColumns: GridColumn[];
  stateColumns: GridColumn[];
  reporterColumns: GridColumn[];
  countyColumns: GridColumn[];
  countries: Country[];
  states: State[];
  counties: County[];
  dropdownCounty = [];
  feeds: Feed[] = [];
  regions = [];
  reporters = [];
  selectedCountry: Array<any>;
  defaultCountry: string;
  regionsDefaultValue: number;
  // date controls
  // minDateValidation
  minValidationDate: NgbDateStruct = { year: 1998, month: 1, day: 1 };
  maxValidationDate: NgbDateStruct = { year: new Date().getFullYear() + 5, month: 1, day: 1 };
  // date controls
  maxFeedDateStart: NgbDateStruct;
  startDateDefault: string = moment().startOf('month').subtract(1, 'months').format(environment.apiDateFormat);
  endDateDefault: string = moment().format(environment.apiDateFormat);
  startDateControl: BaseFormControl = new BaseFormControl('Start', 'start', 'start', this.startDateDefault, [], []);
  endDateControl: BaseFormControl = new BaseFormControl('End', 'end', 'end', this.endDateDefault, [], []);

  // Company/Contact Info Form
  eFeedContentForm: BaseFormGroup;

  // Efeed location group
  eFeedLocationGroup: BaseFormGroup;

  // Company keyword
  eFeedDateRangeFormGroup: BaseFormGroup;

  hideGeography: boolean;
  hideRerouted: boolean;

  mainFormReadySubscription: Subscription;
  clearFormSubscription: Subscription;
  companyContactInfoFormSubscription: Subscription;
  countryControlSubscription: Subscription;
  stateControlSubscription: Subscription;
  startDateControlSubcription: Subscription;
  sourceTypeControlSubscription: Subscription;
  formControlActiveStatusSubscription: Subscription;

  constructor(private logger: SumoLoggerService, private alertService: AlertService, public leftSidebarService: LeftSidebarService,
    private lookupApiService: LookupApiService) {
    this.hideGeography = false;
    this.hideRerouted = false;
    this.defaultCountry = 'USA';
    // Country dropdown config
    this.countryColumns = [
      { name: 'Country Name', prop: 'name' }
    ];
    // Region dropdown config
    this.regionColumns = [
      { name: 'Region Name', prop: 'name' }
    ];
    // Feed name dropdown config
    this.feedNameColumns = [
      { name: 'Feed Name', prop: 'name' }
    ];
    // reporter dropdown config
    this.reporterColumns = [
      { name: 'Reporter Id', prop: 'id' },
      { name: 'User', prop: 'user' }
    ];
    // State dropdown config
    this.stateColumns = [
      { name: 'STATE NAME', prop: 'name' }
    ];
    // County dropdown config
    this.countyColumns = [
      { name: 'COUNTY NAME', prop: 'name' }
    ];
    // efeed date form
    this.eFeedDateRangeFormGroup = new BaseFormGroup('projectBidDate', {
      dateRange: new FormGroup({
        start: this.startDateControl,
        end: this.endDateControl
      })
    });

    // efeed location
    this.eFeedLocationGroup = new BaseFormGroup('locationGroup', {
      countries: new BaseFormGroup('locationCountry', {
        codes: new BaseFormControl('Country', 'country', 'text', '', [], [])
      }),
      states: new BaseFormGroup('locationState', {
        codes: new BaseFormControl('State', 'state', 'text', '', [], [])
      }),
      counties: new BaseFormGroup('locationCounty', {
        codes: new BaseFormControl('County', 'county', 'select', '', [], [])
      }),
    });

    // efeed form
    this.eFeedContentForm = new BaseFormGroup('eFeedContentForm', {
      source: new BaseFormControl('Source', 'source', 'radio', '', [], []),
      sourceType: new FormControl('REGION', [], []),
      feedId: new BaseFormControl('Feed ID', 'feedId', 'text', '0', [], []),
      location: this.eFeedLocationGroup,
      feed: this.eFeedDateRangeFormGroup,
      recordId: new BaseFormControl('Record Id', 'recordId', 'text', '', [], [])
    });
  }

  ngOnInit() {
    // Get all lookup list
    this.getCountries();
    this.getFeeds();
    this.getRegions();
    this.getReporters();
    // enable/disable dropdowns
    this.reporterDropdown.setDisabledState(true);
    // this.reporterDropdown.disabled = true;
    // Push form on ready
    this.mainFormReadySubscription = this.leftSidebarService.mainFormReady$.subscribe((status) => {
      if (status) {
        this.addRemoveControls(true);
      }
    });
    // Reset field
    this.clearFormSubscription = this.leftSidebarService.clearForm$.subscribe((control) => {
      if (!isNil(control)) {
        if (isString(control)) {
          if (control === 'all') {
            this.eFeedContentForm.reset({
              sourceType: 'REGION',
              source: this.regionsDefaultValue,
              location: {
                country: ['USA']
              },
              feed: {
                dateRange: {
                  start: this.startDateDefault,
                  end: this.endDateDefault
                }
              },
            });
            this.regionDropdown.writeValue(this.regionsDefaultValue);
          } else {
            this.eFeedContentForm.get(control).reset();
          }
        }
      }
    });

    this.formControlActiveStatusSubscription = this.leftSidebarService.formControlActiveStatus$.subscribe((status) => {
      if (status) {
        const parentIndex = findIndex(status, item => item.displayName === this.parentDisplayName);
        const geographyIndex = findIndex(status[parentIndex].children, item => item.displayName === 'Geography');
        const reroutedIndex = findIndex(status[parentIndex].children, item => item.displayName === 'Rerouted');
        const geography = status[parentIndex].children[geographyIndex];
        const rerouted = status[parentIndex].children[reroutedIndex];

        this.hideGeography = !geography.active;
        this.hideRerouted = !rerouted.active;

        if (geography.active && !rerouted.active) {
          this.eFeedContentForm.get('sourceType').setValue('REGION');
          this.regionDropdown.setDisabledState(false);
          this.reporterDropdown.setDisabledState(true);
        } else if (!geography.active && rerouted.active) {
          this.eFeedContentForm.get('sourceType').setValue('REPORTER');
          this.regionDropdown.setDisabledState(true);
          this.reporterDropdown.setDisabledState(false);
        }
      }
    });

    this.countryControlSubscription = this.eFeedContentForm.get('location.countries.codes').valueChanges.subscribe((newval) => {
      this.states = [];
      this.counties = [];
      this.dropdownCounty = [];
      if (!isEmpty(newval)) {
        this.getStates(newval);
      }
    });
    this.stateControlSubscription = this.eFeedContentForm.get('location.states.codes').valueChanges.subscribe((newval) => {
      this.counties = [];
      if (!isEmpty(newval)) {
        this.getCounties(newval);
      }
    });
    this.startDateControlSubcription = this.startDateControl.valueChanges.subscribe((newval: string) => {
      if (!newval) {
        this.endDateControl.disable();
        this.endDateControl.setValue('');
      } else {
        this.endDateControl.enable();
        // set start date as min date to issue max date
        const minDate = moment(newval, environment.apiDateFormat);
        // empty the field if date is already there and its invalid
        if (this.endDateControl.value) {
          const endDate = moment(this.endDateControl.value, environment.apiDateFormat);
          if (minDate.isAfter(endDate)) {
            this.endDateControl.setValue('');
          }
        }
        this.maxFeedDateStart = { year: minDate.get('year'), month: minDate.get('month') + 1, day: minDate.get('date') };
      }
    });
    // subscriber for source type
    this.sourceTypeControlSubscription = this.eFeedContentForm.get('sourceType').valueChanges.subscribe((newval) => {
      if (newval === 'REPORTER') {
        this.regionDropdown.setDisabledState(true);
        this.reporterDropdown.setDisabledState(false);
      } else {
        this.regionDropdown.setDisabledState(false);
        this.reporterDropdown.setDisabledState(true);
      }
      this.eFeedContentForm.get('source').reset();
    });
  }

  ngOnDestroy() {
    if (this.mainFormReadySubscription) {
      this.mainFormReadySubscription.unsubscribe();
    }
    if (this.clearFormSubscription) {
      this.clearFormSubscription.unsubscribe();
    }
    if (this.companyContactInfoFormSubscription) {
      this.companyContactInfoFormSubscription.unsubscribe();
    }
    if (this.countryControlSubscription) {
      this.countryControlSubscription.unsubscribe();
    }
    if (this.stateControlSubscription) {
      this.stateControlSubscription.unsubscribe();
    }
    if (this.startDateControlSubcription) {
      this.startDateControlSubcription.unsubscribe();
    }
    if (this.sourceTypeControlSubscription) {
      this.sourceTypeControlSubscription.unsubscribe();
    }
    if (this.formControlActiveStatusSubscription) {
      this.formControlActiveStatusSubscription.unsubscribe();
    }
    this.addRemoveControls(false);
  }

  /**
   * Country lookup api call
   */
  getCountries() {
    this.lookupApiService.getCountries().subscribe(
      (res) => {
        this.countries = this.arrangeCountries(res).data.countries;
        if (this.defaultCountry) {
          this.eFeedContentForm.get('location.countries.codes').setValue(this.defaultCountry);
        }
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * States lookup api call
   * @param country Country selected by user
   */
  getStates(country) {
    this.lookupApiService.getStates(country).subscribe(
      (res) => {
        this.states = res.data.states;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * County lookup api call
   * @param state States selected by user
   */
  getCounties(state) {
    this.lookupApiService.getCounties(state).subscribe(
      (res) => {
        this.counties = res.data.states[0].counties;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * Regions lookup api call
   */
  getRegions() {
    this.lookupApiService.getRegions().subscribe(
      (res) => {
        this.regions = res.data.regions;
        this.regionsDefaultValue = this.regions[0].id;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * Reporters lookup api call
   */
  getReporters() {
    this.lookupApiService.getReporters().subscribe(
      (res) => {
        this.reporters = res.data.reporters;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * Feed lookup api call
   */
  getFeeds() {
    this.lookupApiService.getFeeds().subscribe(
      (res) => {
        this.feeds = res.data.feeds;
      },
      (err) => {
        this.logger.error(err);
      }
    );
  }
  /**
   * Arrange countries data for dropdown
   * @param lookupData country lookup data
   */
  private arrangeCountries(lookupData: CountryLookup): CountryLookup {
    const priorityCountryIds: Array<string> = ['USA', 'CAN', 'MEX', 'PRI', 'VIR', 'GUM'];
    const countriesWithPriority: Array<Country> = [];
    const countriesWithoutPriority: Array<Country> = lookupData.data.countries.reduce((countries, currentCountry) => {
      if (!priorityCountryIds.includes(currentCountry.id)) {
        countries.push(currentCountry);
      }
      return countries;
    }, []);

    priorityCountryIds.forEach((val) => {
      countriesWithPriority.push(lookupData.data.countries.filter(country => country.id === val)[0]);
    });

    lookupData.data.countries = [...countriesWithPriority, ...countriesWithoutPriority];

    return lookupData;
  }

  /** Add / Remove Controls */
  addRemoveControls(addControls: boolean) {
    if (addControls) {
      this.leftSidebarService.getMainForm.addControl('source', this.eFeedContentForm.controls['source']);
      this.leftSidebarService.getMainForm.addControl('sourceType', this.eFeedContentForm.controls['sourceType']);
      this.leftSidebarService.getMainForm.addControl('feedId', this.eFeedContentForm.controls['feedId']);
      this.leftSidebarService.getMainForm.addControl('location', this.eFeedContentForm.controls['location']);
      this.leftSidebarService.getMainForm.addControl('feed', this.eFeedContentForm.controls['feed']);
      this.leftSidebarService.getMainForm.addControl('recordId', this.eFeedContentForm.controls['recordId']);
    } else {
      this.leftSidebarService.getMainForm.removeControl('source');
      this.leftSidebarService.getMainForm.removeControl('sourceType');
      this.leftSidebarService.getMainForm.removeControl('feedId');
      this.leftSidebarService.getMainForm.removeControl('location');
      this.leftSidebarService.getMainForm.removeControl('feed');
      this.leftSidebarService.getMainForm.removeControl('recordId');
    }
  }
}
