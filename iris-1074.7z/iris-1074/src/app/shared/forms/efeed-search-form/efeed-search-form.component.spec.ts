import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { SharedModule } from '../../shared.module';
import { TreeviewModule } from 'ngx-treeview';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { ApiService } from '../../services/api.service';
import { AlertService } from '../../services/alert.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LookupApiService } from '../../services/lookup-api.service';
import { EfeedSearchFormComponent } from './efeed-search-form.component';

describe('EfeedSearchFormComponent', () => {
  let component: EfeedSearchFormComponent;
  let fixture: ComponentFixture<EfeedSearchFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, HttpClientTestingModule, RouterTestingModule,
        SharedModule.forRoot(), TreeviewModule.forRoot()],
      providers: [LocationStrategy, PathLocationStrategy, LeftSidebarService, ApiService, AlertService, LookupApiService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EfeedSearchFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
