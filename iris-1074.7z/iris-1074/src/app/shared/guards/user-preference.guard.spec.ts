import { TestBed, async, inject } from '@angular/core/testing';

import { UserPreferenceGuard } from './user-preference.guard';

describe('UserPreferenceGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserPreferenceGuard]
    });
  });

  // it('should ...', inject([UserPreferenceGuard], (guard: UserPreferenceGuard) => {
  //   expect(guard).toBeTruthy();
  // }));
});
