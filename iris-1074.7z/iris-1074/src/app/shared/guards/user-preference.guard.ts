import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivateChild } from '@angular/router';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { AppState } from '../store/app-state';
import { Store, select } from '@ngrx/store';
import * as UserPreferenceActions from '../store/user-preference/user-preference.actions';
import * as fromuserPreference from '../store/user-preference/user-preference.reducer';
import { take, map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class UserPreferenceGuard implements CanActivate, CanActivateChild {

  isLoaded$ = new BehaviorSubject(<boolean>null);

  constructor(private store: Store<AppState>) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.loadFromServer();
  }

  canActivateChild(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.loadFromServer();
  }

  loadFromServer(): Observable<boolean> {
    this.store.pipe(
      select(fromuserPreference.selectUserPreference),
      map((userPreference) => this.store.dispatch(new UserPreferenceActions.LoadAll(userPreference))),
      take(1)
    ).subscribe(
      (data) => { this.isLoaded$.next(true); },
      (error) => { console.log(error); this.isLoaded$.next(true); }
    );
    return this.isLoaded$.asObservable();
  }
}
