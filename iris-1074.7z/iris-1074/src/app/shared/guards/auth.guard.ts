import { Inject, Injectable, NgZone } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivateChild } from '@angular/router';
import { of as observableOf, Observable, Subscription, combineLatest, BehaviorSubject } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { environment } from '../../../environments/environment';
import * as fromAuth from '../store/auth/auth.reducer';
import { isTokenValid } from '@dodge/js-auth-client';
import { Store, select } from '@ngrx/store';
import { AppState } from '../store/app-state';
import { map, take } from 'rxjs/operators';
import { selectInvalidated } from '../store/auth/auth.reducer';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild {

  isLoggedIn$ = new BehaviorSubject(<boolean>false);

  constructor(private authService: AuthService,
              private store: Store<AppState>) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.handleAuthFlow();
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    console.log('calling authGuard');
    return this.handleAuthFlow();
  }

  private handleAuthFlow(): Observable<boolean> {
    this.store.pipe(
      select(fromAuth.selectAccessToken),
      take(1)
    ).subscribe((token) => {
      if (token && isTokenValid(token)) {
        this.isLoggedIn$.next(true);
      } else {
        this.isLoggedIn$.next(false);
        return this.authService.redirectToLogin();
      }
    });
    return this.isLoggedIn$.asObservable();
  }
}
