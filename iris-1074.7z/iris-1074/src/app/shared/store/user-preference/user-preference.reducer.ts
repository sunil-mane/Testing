import { UserPreferenceActions, UserPreferenceActionTypes } from './user-preference.actions';
import { UserPreferenceState } from './user-preference-state';
import { AppState } from '../app-state';
import { merge } from 'lodash';

export const initialState: UserPreferenceState = {
  failure: false,
  loading: false,
  userPreference: {}
};

export function reducer(state = initialState, action: UserPreferenceActions): UserPreferenceState {
  switch (action.type) {

    case UserPreferenceActionTypes.LoadAll:
      return {
        ...state,
        failure: false,
        loading: true,
        userPreference: {...state.userPreference}
      };

    case UserPreferenceActionTypes.LoadAllSuccess:
      return {
        ...state,
        failure: false,
        loading: false,
        userPreference: {...action.payload}
      };

    case UserPreferenceActionTypes.LoadAllFailure:
      return {
        ...state,
        failure: true,
        loading: false,
        userPreference: {...state.userPreference}
      };

    case UserPreferenceActionTypes.ResetToDefault:
      return {
        ...state,
        ...initialState
      };

    case UserPreferenceActionTypes.SaveAll:
      return {
        ...state,
        ...action.payload
      };

    case UserPreferenceActionTypes.SaveAllSuccess:
      return {
        ...state,
        failure: false,
        loading: false,
        userPreference: {...state.userPreference}
      };

    case UserPreferenceActionTypes.SaveAllFailure:
      return {
        ...state,
        failure: true,
        loading: false,
        userPreference: {...state.userPreference}
      };

    default:
      return state;
  }
}

export const selectUserPreference = (state: AppState) => state.userPreference;
