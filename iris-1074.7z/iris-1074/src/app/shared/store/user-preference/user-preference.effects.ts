import { Inject, Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { UserPreferenceActionTypes, LoadAllFailure, LoadAllSuccess, SaveAllSuccess, SaveAllFailure } from './user-preference.actions';
import { select, Store } from '@ngrx/store';
import { UserPreferenceService } from '../../services/user-preference.service';
import { catchError, mergeMap, map, switchMap, debounceTime, tap, withLatestFrom } from 'rxjs/operators';
import { of } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import { environment } from '../../../../environments/environment';
import { AppState } from '../app-state';
import { selectInvalidated } from '../auth/auth.reducer';

const UI_DEBOUNCE_TIME = 800;

@Injectable()
export class UserPreferenceEffects {

  @Effect()
  loadUserPreference$ = this.actions$.pipe(
    ofType(UserPreferenceActionTypes.LoadAll),
    debounceTime(UI_DEBOUNCE_TIME),
    map(userpreference => userpreference),
    mergeMap((userpreference: any) => {
        return this.userPreferenceService.loadAll().pipe(
          map((userPreferences) => {
            return new LoadAllSuccess(userPreferences['data']);
          }),
          catchError(error => {
            console.log(error);
            return of(new LoadAllFailure());
          })
        );
      }
    )
  );

  @Effect()
  saveUserPreference$ = this.actions$.pipe(
    ofType(UserPreferenceActionTypes.SaveAll),
    map(userpreference => userpreference),
    debounceTime(UI_DEBOUNCE_TIME),
    switchMap((action: any) => {
      return this.userPreferenceService.saveAll(action.payload['userPreference']).pipe(
        map(() => {
          return new SaveAllSuccess();
        }),
        catchError(error => {
          console.log(error);
          return of(new SaveAllFailure());
        })
      );
    })
  );

  @Effect()
  saveUserPreferenceSuccess$ = this.actions$.pipe(
    ofType(UserPreferenceActionTypes.SaveAllSuccess),
    withLatestFrom(
      this.store$.pipe(select(selectInvalidated))
    ),
    tap((invalidated) => {
      if (invalidated[1]) {
        this.document.location.href = `${environment.ssoUrl}/login?returnUrl=${environment.siteUrl}/login`;
      }
    })
  );

  constructor(private actions$: Actions,
              private userPreferenceService: UserPreferenceService,
              private store$: Store<AppState>, @Inject(DOCUMENT) private document: Document) {}
}
