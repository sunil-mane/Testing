export interface UserPreferenceState {
  failure: boolean;
  loading: boolean;
  userPreference: any;
}
