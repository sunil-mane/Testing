import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { UserPreferenceEffects } from './user-preference.effects';

describe('UserPreferencesEffects', () => {
  let actions$: Observable<any>;
  let effects: UserPreferenceEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        UserPreferenceEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(UserPreferenceEffects);
  });

  // it('should be created', () => {
  //   expect(effects).toBeTruthy();
  // });
});
