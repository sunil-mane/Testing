import { Action } from '@ngrx/store';
import { UserPreferenceState } from './user-preference-state';

export enum UserPreferenceActionTypes {
  LoadAll = '[UserPreferences] Load All',
  LoadAllSuccess = '[UserPreferences] Load All Success',
  LoadAllFailure = '[UserPreferences] Load All Failure',
  ResetToDefault = '[UserPreferences] Reset To Default',
  SaveAll = '[UserPreferences] Save All',
  SaveAllSuccess = '[UserPreferences] Save All Success',
  SaveAllFailure = '[UserPreferences] Save All Failure'
}

export class LoadAll implements Action {
  readonly type = UserPreferenceActionTypes.LoadAll;

  constructor(public payload?: UserPreferenceState) {}
}

export class LoadAllSuccess implements Action {
  readonly type = UserPreferenceActionTypes.LoadAllSuccess;

  constructor(public payload?: UserPreferenceState) {}
}

export class LoadAllFailure implements Action {
  readonly type = UserPreferenceActionTypes.LoadAllFailure;

  constructor(public payload?: UserPreferenceState) {}
}

export class ResetToDefault implements Action {
  readonly type = UserPreferenceActionTypes.ResetToDefault;

  constructor(public payload?: UserPreferenceState) {}
}

export class SaveAll implements Action {
  readonly type = UserPreferenceActionTypes.SaveAll;

  constructor(public payload?: UserPreferenceState) {}
}

export class SaveAllSuccess implements Action {
  readonly type = UserPreferenceActionTypes.SaveAllSuccess;

  constructor(public payload?: UserPreferenceState) {}
}

export class SaveAllFailure implements Action {
  readonly type = UserPreferenceActionTypes.SaveAllFailure;

  constructor(public payload?: UserPreferenceState) {}
}

export type UserPreferenceActions = LoadAll | LoadAllSuccess | LoadAllFailure | ResetToDefault | SaveAll | SaveAllSuccess | SaveAllFailure;
