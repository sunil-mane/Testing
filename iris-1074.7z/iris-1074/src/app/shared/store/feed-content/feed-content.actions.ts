import { Action } from '@ngrx/store';
import { FeedContentState } from './feed-content-state';

export enum FeedContentActionTypes {
  SAVE_FEED_CONTENT = '[Feed Content] Feed Content Save'
}

export class SaveFeedContentAction implements Action {
  readonly type = FeedContentActionTypes.SAVE_FEED_CONTENT;

  constructor(public payload?: FeedContentState) { }
}

export type FeedContentActionsUnion = SaveFeedContentAction;
