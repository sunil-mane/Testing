export interface FeedContentState {
  name: string;
  value: any;
}
