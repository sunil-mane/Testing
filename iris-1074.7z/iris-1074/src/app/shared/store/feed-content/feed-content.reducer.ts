import { AppState } from '../app-state';
import { FeedContentState } from './feed-content-state';
import { FeedContentActionsUnion, FeedContentActionTypes } from './feed-content.actions';

export const initialState: FeedContentState = {
  name: '',
  value: {}
};

export function reducer(state: FeedContentState = initialState, action: FeedContentActionsUnion): FeedContentState {
  switch (action.type) {
    case FeedContentActionTypes.SAVE_FEED_CONTENT: {
      return { ...state, ...action.payload };
    }
    default:
      return state;
  }
}

export const selectFeedContent = (state: AppState) => state.feedContent;
