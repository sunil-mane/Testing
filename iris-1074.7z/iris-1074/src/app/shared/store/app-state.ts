import { AuthState } from './auth/auth-state';
import * as fromRouter from '@ngrx/router-store';
import { UserPreferenceState } from './user-preference/user-preference-state';
import { FeedContentState } from './feed-content/feed-content-state';

export interface AppState {
  auth: AuthState;
  userPreference: UserPreferenceState;
  router: fromRouter.RouterReducerState;
  feedContent: FeedContentState;
}
