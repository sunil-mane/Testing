export interface AuthState {
  invalidated: boolean;
  accessToken: string;
  refreshToken: string;
  userId: string;
}
