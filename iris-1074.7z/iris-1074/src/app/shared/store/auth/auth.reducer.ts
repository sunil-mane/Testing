import { AuthActionsUnion, AuthActionTypes } from './auth.actions';
import { AuthState } from './auth-state';
import { AppState } from '../app-state';
import { createSelector } from '@ngrx/store';
import { merge } from 'lodash';

export const initialState: AuthState = {
  invalidated: false,
  accessToken: null,
  refreshToken: null,
  userId: null
};

export function reducer(state: AuthState = initialState, action: AuthActionsUnion): AuthState {
  switch (action.type) {
    case AuthActionTypes.SAVE_AUTH: {
      return {...state, ...action.payload};
    }

    case AuthActionTypes.INVALIDATE_AUTH: {
      const newState = merge(initialState, {invalidated: true});
      return newState;
    }

    default:
      return state;
  }
}

export const selectAuth = (state: AppState) => state.auth;

export const selectAccessToken = createSelector(
  selectAuth,
  (auth: AuthState) => auth.accessToken
);

export const selectInvalidated = createSelector(
  selectAuth,
  (auth: AuthState) => auth.invalidated
);
