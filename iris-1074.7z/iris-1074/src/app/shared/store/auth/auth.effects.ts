import { Inject, Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { AuthActionTypes, InvalidateAuthSuccessAction } from './auth.actions';
import { concatMapTo, mapTo, switchMap, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { AppState } from '../app-state';
import { SaveAll } from '../user-preference/user-preference.actions';
import { DOCUMENT } from '@angular/common';
import { environment } from '../../../../environments/environment';


@Injectable()
export class AuthEffects {

  constructor(private actions$: Actions, private store: Store<AppState>, @Inject(DOCUMENT) private document: Document) {}

  @Effect()
  invalidateAuth$ = this.actions$.pipe(
    ofType(AuthActionTypes.INVALIDATE_AUTH),
    mapTo(new SaveAll(JSON.parse(localStorage.getItem('userPreference'))))
  );
}
