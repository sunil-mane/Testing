import { Action } from '@ngrx/store';
import { AuthState } from './auth-state';

export enum AuthActionTypes {
  SAVE_AUTH = '[Auth] Save Auth',
  INVALIDATE_AUTH = '[Auth] Invalidate Auth',
  INVALIDATE_AUTH_SUCCESS = '[Auth] Invalidate Auth Success'
}

export class SaveAuthAction implements Action {
  readonly type = AuthActionTypes.SAVE_AUTH;

  constructor(public payload?: AuthState) {}
}

export class InvalidateAuthAction implements Action {
  readonly type = AuthActionTypes.INVALIDATE_AUTH;

  constructor(public payload?: AuthState) {}
}

export class InvalidateAuthSuccessAction implements Action {
  readonly type = AuthActionTypes.INVALIDATE_AUTH_SUCCESS;

  constructor(public payload?: AuthState) {}
}

export type AuthActionsUnion = SaveAuthAction | InvalidateAuthAction | InvalidateAuthSuccessAction;
