import * as moment from 'moment';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';

/**
 * Simple logger Service to send warn/errors/info to sumoLogic.
 */

@Injectable()
export class SumoLoggerService {
  isLoggerInitialized = false;

  /**
   * Initialize sumoLogic Logger
   */
  constructor(private location: LocationStrategy) {

  }

  /**
   * Method to log informational messages
   * @param message: message to be logged.
   */
  log(...message) {
    if (environment.isDebugMode) {
      if (environment.logToConsole) {
        console.log(...message);
      } else {
        if (!this.isLoggerInitialized) {
          this.initializeLogger();
          this.isLoggerInitialized = true;
        }
        SLLogger.log('INFO: ' + message);
      }
    }
  }

  /**
   * Method to log errors
   * @param error: error message to be logged
   */
  error(error) {
    if (!this.isLoggerInitialized) {
      this.initializeLogger();
      this.isLoggerInitialized = true;
    }
    const timestamp = moment.utc();
    let str = timestamp.format('YYYY-MM-DD HH:mm:ss') + ' [' + (error.name || null) + ']';
    str += ' ERROR LG:' + ((this.location instanceof PathLocationStrategy) ? this.location.path() : '');
    str += ' User: SSO User';
    str += ' MSG:[' + (error.message || error.toString()) + ']';
    str += ' STACK:[' + error.stack + ']';
    console.error(str);
    if (environment.production) {
      SLLogger.log(str);
    }
  }
  /**
   * Initialize Logger
   */
  initializeLogger() {
    // Configure the logger
    SLLogger.config({
      endpoint: `${environment.sumoLogicUrl}${environment.sumoLogicCC}`,
      interval: 10000
    });
  }

  /**
   * TO DO: Flush any logs, the following will be in the shutdown code
   * window.addEventListener('beforeunload', function() {
   *    SLLogger.flushLogs();
   * });
   */


}
