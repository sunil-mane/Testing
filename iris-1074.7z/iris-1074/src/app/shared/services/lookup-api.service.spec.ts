import { TestBed, inject } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LookupApiService } from './lookup-api.service';
import { ApiService } from './api.service';

describe('LookupApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [LookupApiService, ApiService]
    });
  });

  it('should be created', inject([LookupApiService], (service: LookupApiService) => {
    expect(service).toBeTruthy();
  }));
});
