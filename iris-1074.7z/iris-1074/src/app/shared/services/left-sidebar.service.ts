import { Injectable } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { BehaviorSubject, Subject, Observable, Observer } from 'rxjs';
import { isEmpty, isNil, findIndex, cloneDeep, get, set, has } from 'lodash';
import { BaseFormGroup } from '../forms/base-form-group';
import { BaseFormControl } from '../forms/base-form-control';
import { ApiService } from './api.service';
import { UtilService } from './util.service';
import { AlertService } from './alert.service';
import { LookupApiService } from './lookup-api.service';
import { FilterDropdown, ClearFormPayload, SearchPageConfig, ErrorResponse, ErrorResponseObject } from '../models/LeftSidebar';
import { isString, isArray } from 'lodash';
import * as searchPageConfigurations from '../config/searchpage.json';

/**
 * This service is bridge between Left sidebar forms and other components
 */

@Injectable()
export class LeftSidebarService {
  // This Observable provides all the form control active status
  formControlActiveStatus$: Observable<Array<FilterDropdown>>;

  // This Observable provides main form ready status
  mainFormReady$: Observable<boolean>;

  // This Observable emits main form clear event
  clearForm$: Observable<string | ClearFormPayload>;

  // This Observable emits left sidebar hide or show event
  visibleChange$: Observable<boolean>;

  // current grid sort
  currentGridSorts: Array<any>;

  // Master form group identifier
  pageIdentifier: string;

  // API Loading Status
  loadingStatus: boolean;

  // Grid messages
  searchStatus: string;

  // This provides search result data
  searchResults: any[] = [];

  // Total count of search results
  searchResultsTotal: number;

  // Pagination Limit
  paginationLimit: number;

  // Search Config
  searchPageConfig: SearchPageConfig;

  // This BehaviorSubject is to provide form control active status to it's subscibers
  private formControlActiveSubject: BehaviorSubject<Array<FilterDropdown>>;

  // On Form Init event
  private mainFormReadyStatus: BehaviorSubject<boolean>;

  // Subject to emit Clear event of Forms
  private clearFormSubject: Subject<string | ClearFormPayload>;

  // Subject to emit Clear event of Forms
  private visibleChangeSubject: Subject<boolean>;

  // This property holds all the form control details and there active status
  private formControlActiveStatus: Array<FilterDropdown>;

  // Master form group
  private mainForm: BaseFormGroup;

  // Pagination Form Control Group
  private paginationFormGroup: BaseFormGroup;

  // Sort From Control Group
  private sortFormGroup: BaseFormGroup;

  // Current Search criteria
  private currentSearchCriteria: any;

  /** Constructor */
  constructor(private utilService: UtilService, private apiService: ApiService, private alertService: AlertService,
    private lookupApiService: LookupApiService) {
    // Initialize Main Form ready event
    this.mainFormReadyStatus = new BehaviorSubject<boolean>(false);

    // Assign Observable of this.mainFormReadyStatus which is a BehaviorSubject
    this.mainFormReady$ = this.mainFormReadyStatus.asObservable();

    // Initialize clear all
    this.clearFormSubject = new Subject<string>();

    // Assign Observable of this.clearFormSubject which is a Subject
    this.clearForm$ = this.clearFormSubject.asObservable();

    // Initialize visibleChange all
    this.visibleChangeSubject = new Subject<boolean>();

    // Assign Observable of this.visibleChangeSubject which is a Subject
    this.visibleChange$ = this.visibleChangeSubject.asObservable();

    // Initialize with empty array, so that subscribe of Subject doesn't get undefined error
    this.formControlActiveStatus = [];

    // Instantiate Subject with this.formControlActiveStatus as initial value
    this.formControlActiveSubject = new BehaviorSubject<Array<FilterDropdown>>(this.formControlActiveStatus);

    // Assign Observable of this.formControlActiveSubject which is a BehaviorSubject
    this.formControlActiveStatus$ = this.formControlActiveSubject.asObservable();

    // Create Pagination Form Controls
    this.paginationFormGroup = new BaseFormGroup('paginationFormGroup', {
      limit: new BaseFormControl('Limit', 'limit', 'text', 100, []),
      offset: new BaseFormControl('Offset', 'offset', 'text', 0, [])
    });

    // Create Sort form controls
    this.sortFormGroup = new BaseFormGroup('sortFormGroup', {
      order: new BaseFormControl('Order', 'order', 'text', 'asc', []),
      by: new BaseFormControl('By', 'by', 'text', '', [])
    });

    // Initial main form group
    this.mainForm = new BaseFormGroup('mainForm', {});

    // set default limit
    this.paginationLimit = 100;
  }

  /**
   * Get active status of particular form control
   * @param {string} parentDisplayName control group display property as in this.formControlActiveStatus
   * @param {string} childDisplayName control group child display property as in this.formControlActiveStatus
   * @returns {Observable<boolean>} returns true if form control is active and false if form control is in active
   */
  isFormControlActive(parentDisplayName: string, childDisplayName?: string): Observable<boolean> {
    return Observable.create((observer: Observer<boolean>) => {
      this.formControlActiveStatus$.subscribe((status) => {
        if (!isEmpty(status)) {
          let payload;
          if (isNil(childDisplayName)) {
            const parentIndex = findIndex(status, item => item.displayName === parentDisplayName);
            payload = (parentIndex >= 0) ? status[parentIndex].active : null;
          } else {
            const parentIndex = findIndex(status, item => item.displayName === parentDisplayName);
            const childIndex = (parentIndex >= 0) ?
              findIndex(status[parentIndex].children, item => item.displayName === childDisplayName) : -1;
            payload = (childIndex >= 0) ? status[parentIndex].children[childIndex].active : null;
          }
          if (!isNil(payload)) {
            observer.next(payload);
          }
        }
      });
    });
  }

  /**
   * Change status of control. This being used for left sidebar filter (gear) dropdown item's onClick event
   * @param {number} parentControlIndex parent control index as in this.formControlActiveStatus
   * @param {number} childControlIndex child control index as in this.formControlActiveStatus
   */
  changeFormControlActiveStatus(parentControlIndex: number, childControlIndex?: number): void {
    if (!isEmpty(this.formControlActiveStatus)) {
      if (isNil(childControlIndex)) {
        if (this.formControlActiveStatus[parentControlIndex].children) {
          this.formControlActiveStatus[parentControlIndex].children.forEach((val) => {
            val.active = !this.formControlActiveStatus[parentControlIndex].active;
            if (!val.active) {
              const parentControlName = isEmpty(this.formControlActiveStatus[parentControlIndex].controlName) ? '' :
                this.formControlActiveStatus[parentControlIndex].controlName + '.';
              this.triggerClearForm(parentControlName + val.controlName);
            }
          });
        }
        this.formControlActiveStatus[parentControlIndex].active = !this.formControlActiveStatus[parentControlIndex].active;
      } else {
        this.formControlActiveStatus[parentControlIndex].children[childControlIndex].active =
          !this.formControlActiveStatus[parentControlIndex].children[childControlIndex].active;

        if (this.formControlActiveStatus[parentControlIndex].children[childControlIndex].active) {
          this.formControlActiveStatus[parentControlIndex].active = true;
        }

        if (this.formControlActiveStatus[parentControlIndex].children.filter(item => item.active).length === 0) {
          this.formControlActiveStatus[parentControlIndex].active = false;
        }

        if (!this.formControlActiveStatus[parentControlIndex].children[childControlIndex].active) {
          const parentControlName = isEmpty(this.formControlActiveStatus[parentControlIndex].controlName) ? '' :
            this.formControlActiveStatus[parentControlIndex].controlName + '.';
          this.triggerClearForm(parentControlName +
            this.formControlActiveStatus[parentControlIndex].children[childControlIndex].controlName);
        }
      }
      this.formControlActiveSubject.next(this.formControlActiveStatus);
    }
  }

  /**
   * This method being used by left sidebar component to push the for control status template
   * @param {Array<FilterDropdown>} currentFormControl current form controls
   */
  pushFormControlStatusList(currentFormControl: Array<FilterDropdown>): void {
    // Assign the template to class property
    this.formControlActiveStatus = currentFormControl;

    // Emit the initial values so that left sidebar filter gear dropdown can be created
    this.formControlActiveSubject.next(this.formControlActiveStatus);
  }

  /**
   * Initialize mainForm
   * @param {string} indentifier BaseFormGroup indentifier
   */
  initMainForm(indentifier: string): void {
    // Save indentifier
    this.pageIdentifier = indentifier;

    // Set config
    this.searchPageConfig = searchPageConfigurations[this.pageIdentifier];

    // Add pagination control
    if (this.searchPageConfig.hasPagination) {
      this.getMainForm.addControl('pagination', this.paginationFormGroup);
    } else {
      if (this.mainForm.contains('pagination')) {
        this.getMainForm.removeControl('pagination');
      }
    }

    // Add sort control
    if (this.searchPageConfig.hasSort) {
      this.getMainForm.addControl('sort', this.sortFormGroup);
    } else {
      if (this.mainForm.contains('sort')) {
        this.getMainForm.removeControl('sort');
      }
    }

    // Emit main form ready stutus
    this.mainFormReadyStatus.next(true);
  }

  /**
   * Clear default value
   */
  onDestroy() {
    this.searchStatus = this.searchPageConfig && this.searchPageConfig.searchStatus.noData;
    this.pageIdentifier = null;
    this.loadingStatus = null;
    this.searchResults = [];
    this.searchResultsTotal = null;
    this.currentSearchCriteria = null;
    this.currentGridSorts = null;
    this.formControlActiveSubject.next([]);
    this.mainFormReadyStatus.next(false);
  }

  /**
   * Get mainForm instance
   * @returns {BaseFormGroup} reference of mainForm
   */
  get getMainForm(): BaseFormGroup {
    return this.mainForm;
  }

  /**
   * Set pagination form values
   * @param {number} limit max limit of rows to be returned by api
   * @param {number} offset offset/page number
   * @param {boolean} triggerSearch if true search will be trigged after setting pagination for values
   */
  setPagination(event: any): void {
    if (this.searchPageConfig.hasPagination) {
      const offset = (event - 1) * this.paginationLimit;
      this.mainForm.get('pagination.limit').setValue(this.paginationLimit);
      this.mainForm.get('pagination.offset').setValue(offset);
      this.searchTriggered(false, false, true);
    }
  }

  /**
   * Set sorting form values
   * @param {string} order order 'asc' or 'desc'
   * @param {string} by field name
   * @param {boolean} triggerSearch if true search will be trigged after setting pagination for values
   */
  setSort(event: any): void {
    if (this.searchPageConfig.hasSort) {
      const order = event.newValue;
      const by = event.sorts[0].prop;
      this.mainForm.get('sort.order').setValue(order);
      this.mainForm.get('sort.by').setValue(by);
      this.searchTriggered(true, false, true);
    }
  }

  /**
   * Trigger clear form event
   * @param control control  ClearFormPayload or string
   */
  triggerClearForm(control: string | ClearFormPayload) {
    this.clearFormSubject.next(control);
  }

  /**
   * Bind to "Clear All" link on left sidebar
   */
  clearAllTriggered() {
    if (this.searchPageConfig.hasSort) {
      this.mainForm.get('sort.order').setValue('asc');
      this.mainForm.get('sort.by').reset();
      this.currentGridSorts = [];
    }
    if (this.searchPageConfig.hasPagination) {
      this.mainForm.get('pagination.offset').setValue(0);
    }
    this.searchResults = [];
    this.searchResultsTotal = 0;
    this.searchStatus = this.searchPageConfig.searchStatus.noData;
    this.loadingStatus = false;
    this.triggerClearForm('all');
  }

  /**
   * Bind to click event of search button of left sidebar, search of header, pagination, sorting and TriggerSearch Directive
   * This search result gets into the searchResultsSubject which the grid subscribes
   * @param {booleon} ressetOffset if set to true offset will be set to zero
   */
  searchTriggered(resetOffset?: boolean, resetSorting?: boolean, useExistingCreiteria?: boolean): void {

    this.alertService.clear();
    this.searchResults = [];

    let formValues;
    if (resetOffset && this.searchPageConfig.hasPagination) {
      this.mainForm.get('pagination.offset').setValue(0);
    }

    if (resetSorting && this.searchPageConfig.hasSort) {
      this.mainForm.get('sort.order').setValue('asc');
      this.mainForm.get('sort.by').reset();
      this.currentGridSorts = [];
    }

    if (useExistingCreiteria) {
      formValues = this.getSavedSearchCriteria();
    } else {
      formValues = this.validateFromData(this.getMainForm.value);
      this.currentSearchCriteria = cloneDeep(formValues);
      this.searchResultsTotal = 0;
    }

    if (this.onlyPaginationAndSort(formValues)) {
      this.searchStatus = this.searchPageConfig.searchStatus.emptyCriteria;
      this.loadingStatus = false;
    } else if (this.pageIdentifier === 'projectSearch' && isEmpty(get(formValues, 'project.issue.dateRange.start'))) {
      // Set error message
      this.searchStatus = this.searchPageConfig.searchStatus.noIssueDate;
      this.loadingStatus = false;
    } else {
      this.searchStatus = this.searchPageConfig.searchStatus.noData;
      this.loadingStatus = true;

      this.apiService.post<any>(this.searchPageConfig.apiPath, formValues).subscribe(
        (res) => {
          this.searchResultsTotal = get(res, this.searchPageConfig.totalPath, 0);
          this.searchResults = this.utilService.getRowsWithId(get(res, this.searchPageConfig.dataPath, []));
          if (this.pageIdentifier === 'companySearch') {
            this.searchResults = this.utilService.formatDataForContactName(this.searchResults);
          } else if (this.pageIdentifier === 'feedContent') {
            this.searchResults.forEach((record) => {
              if (formValues.sourceType === 'REGION') {
                record['assignedTo'] = this.lookupApiService.getRegionNameById(formValues.source);
              } else {
                record['assignedTo'] = formValues.source;
              }
            });
          }
          this.searchStatus = (this.searchResultsTotal === 0) ? this.searchPageConfig.searchStatus.zeroResults :
            this.searchPageConfig.searchStatus.noData;
          this.loadingStatus = false;
        },
        (err) => {
          this.searchStatus = this.searchPageConfig.searchStatus.zeroResults;
          const errors: ErrorResponseObject[] = get(err, 'error.data.errors');
          if (isArray(errors)) {
            errors.forEach(error => this.alertService.error(error.message));
          } else if (isString(get(err, 'error.message'))) {
            this.searchStatus = err.error.message;
          } else {
            this.alertService.error(err.message);
          }
          this.loadingStatus = false;
        }
      );
    }
  }

  /**
  * Export to csv  file API call
  */
  export(offset, limit): Observable<any> {
    const formValues = this.getSavedSearchCriteria();
    set(formValues, 'pagination.limit', limit);
    set(formValues, 'pagination.offset', offset);
    return this.apiService.post(this.searchPageConfig.apiPath, formValues);
  }

  /** Emit event on visibility change of sidebar */
  changeVisibility(hideOrShow: boolean) {
    this.visibleChangeSubject.next(hideOrShow);
  }

  /**
   * Validate values of present associate filter
   * @param mainFormValues form value
   */
  private validateFromData(mainFormValues: any): any {
    const clonedFormValues = cloneDeep(mainFormValues);
    // Remove values when header search present
    if (this.searchPageConfig.showHeaderSearch) {
      if (isEmpty(get(clonedFormValues, 'term'))) {
        if (has(clonedFormValues, 'term')) {
          delete clonedFormValues.term;
        }
        if (has(clonedFormValues, 'exactMatch')) {
          delete clonedFormValues.exactMatch;
        }
        if (has(clonedFormValues, 'searchType')) {
          delete clonedFormValues.searchType;
        }
      }
    }

    if (this.pageIdentifier === 'projectSearch' || this.pageIdentifier === 'companySearch') {
      if (isEmpty(get(clonedFormValues, 'company.keyword.term')) && has(clonedFormValues, 'company.keyword')) {
        delete clonedFormValues.company.keyword;
      }
    }

    if (this.pageIdentifier === 'projectSearch') {
      if (isEmpty(get(clonedFormValues, 'project.title.term')) && has(clonedFormValues, 'project.title')) {
        delete clonedFormValues.project.title;
      }
      if (isEmpty(get(clonedFormValues, 'project.keyword.term')) && has(clonedFormValues, 'project.keyword')) {
        delete clonedFormValues.project.keyword;
      }
    }

    // Remove values for feed content page
    if (this.pageIdentifier === 'feedContent') {
      if (has(clonedFormValues, 'location.countries.codes')) {
        delete clonedFormValues.location.countries;
      }
    }

    return clonedFormValues;
  }

  /**
   * Check whether mainform object only contains pagination and sort
   * @param formValues cleaned form value
   */
  private onlyPaginationAndSort(formValues: any): boolean {
    const clonedFormValues = this.utilService.deepCleanObject(cloneDeep(formValues));

    if (this.pageIdentifier === 'feedContent') {
      if (get(clonedFormValues, 'feedId') === '0') {
        delete clonedFormValues.feedId;
      }
    }

    if (isNil(clonedFormValues) || isEmpty(clonedFormValues)) {
      return true;
    } else {
      if (this.searchPageConfig.hasPagination && has(clonedFormValues, 'pagination')) {
        delete clonedFormValues.pagination;
      }
      if (this.searchPageConfig.hasSort && has(clonedFormValues, 'sort')) {
        delete clonedFormValues.sort;
      }
      return isEmpty(clonedFormValues);
    }
  }

  /**
   * Get current search criteria
   */
  private getSavedSearchCriteria(): any {
    const clonedFormValues = cloneDeep(this.currentSearchCriteria);
    set(clonedFormValues, 'pagination.limit', this.getMainForm.get('pagination.limit').value);
    set(clonedFormValues, 'pagination.offset', this.getMainForm.get('pagination.offset').value);
    set(clonedFormValues, 'sort.order', this.getMainForm.get('sort.order').value);
    set(clonedFormValues, 'sort.by', this.getMainForm.get('sort.by').value);
    return clonedFormValues;
  }
}
