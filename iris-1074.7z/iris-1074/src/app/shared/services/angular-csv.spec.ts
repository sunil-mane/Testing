import { AngularCsv, CsvConfigConsts } from './angular-csv';

describe('Component: Angular2Csv', () => {


  it('should create an file with name My_Report.csv', () => {
    const component = new AngularCsv([{ name: 'test', age: 20 }], 'My Report');
    expect(component).toBeTruthy();
  });

  it('should return correct order', () => {
    const component = new AngularCsv([{ name: 'test', age: 20 }], 'My Report', { useBom: false });
    const csv = component['csv'];
    const csv_rows = csv.split(CsvConfigConsts.EOL);
    const first_row = csv_rows[0].replace(/"/g, '').split(',');
    expect(first_row[0]).toEqual('test');
    expect(first_row[1]).toBe('' + 20);
  });

  it('should return csv with title', () => {
    const component = new AngularCsv([{ name: 'test', age: 20 }], 'My Report', { showTitle: true, useBom: false });
    const csv = component['csv'];
    const title = csv.split(CsvConfigConsts.EOL)[0];
    expect(title).toEqual('My Report');
  });

  it('should return csv file with custom field separator', () => {
    const component = new AngularCsv([{ name: 'test', age: 20 }], 'My Report', { useBom: false, fieldSeparator: ';' });
    const csv = component['csv'];
    const first_row = csv.split(CsvConfigConsts.EOL)[0];
    expect(first_row.split(';').length).toBe(2);
  });

  it('should return csv file with custom field separator', () => {
    const component = new AngularCsv([{ name: 'test', age: 20 }], 'My Report', { useBom: false, quoteStrings: '|' });
    const csv = component['csv'];
    const first_row = csv.split(CsvConfigConsts.EOL)[0].split(',');
    expect(first_row[0]).toMatch('\\|.*\\|');
  });

  it('should return csv file with correct header labels', () => {
    const component = new AngularCsv([{ name: 'test', age: 20 }], 'My Report', {
      useBom: false,
      showLabels: true,
      headers: ['name', 'age']
    });
    const csv = component['csv'];
    const labels = csv.split(CsvConfigConsts.EOL)[0].split(',');
    expect(labels[0]).toEqual('name');
    expect(labels[1]).toEqual('age');
  });
});
