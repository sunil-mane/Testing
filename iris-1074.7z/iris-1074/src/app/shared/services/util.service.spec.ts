import { TestBed, inject } from '@angular/core/testing';
import { UtilService } from './util.service';
import * as data from '../../../mocks/exportToExcelData.json';

describe('UtilService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UtilService]
    });
  });

  it('should be created', inject([UtilService], (service: UtilService) => {
    expect(service).toBeTruthy();
  }));
  it('should generate excel', inject([UtilService], (service: UtilService) => {
    const dummyData: any[] = (<any>data).list;
    const fileName = 'Project Name' + service.getCSVFileName();
    const options = { noDownload: true };
    const p = service.exportToExcel(dummyData, fileName, options);
    expect(p).toBeTruthy();
  }));
});
