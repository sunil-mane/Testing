import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  AuthClient,
  AngularHttpAuthTransportAdapter,
  LocalAuthStorageAdapter,
  AuthToken,
  isTokenValid,
  getTokenContent
} from '@dodge/js-auth-client';
import { Store } from '@ngrx/store';
import { environment } from '../../../environments/environment';
import { Observable, of as observableOf } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import { AppState } from '../store/app-state';
import * as AuthActions from '../store/auth/auth.actions';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  client: AuthClient;

  constructor(@Inject(DOCUMENT) private document: Document, private http: HttpClient, private store: Store<AppState>) {
    this.client = new AuthClient(
      new AngularHttpAuthTransportAdapter(http),
      new LocalAuthStorageAdapter()
    );

    this.client.setEndpoint(`${environment.ssoHost}/cc/api/sso`);
  }

  setStorage(token: AuthToken) {
    this.client.getStorage().store(token);
  }

  getToken(): string {
    return JSON.parse(localStorage.getItem('auth')).accessToken;
  }

  /**
   * Redirects the browser to the SSO login URL.
   */
  redirectToLogin(): Observable<boolean> {
    this.document.location.href = this.createLoginUrl();
    return observableOf(false);
  }

  /**
   * Create a SSO login URL
   */
  createLoginUrl(): string {
    return `${environment.ssoUrl}/login?returnUrl=${environment.siteUrl}/login`;
  }

  invalidate() {
    this.store.dispatch(new AuthActions.InvalidateAuthAction());
  }

  getEmail() {
    const decodedToken = getTokenContent(this.getToken());
    return decodedToken.email;
  }
}
