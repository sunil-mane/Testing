import { Injectable } from '@angular/core';
import { AngularCsv } from './angular-csv';
import printjs from 'print-js';
import { isEmpty, isPlainObject, transform, cloneDeep, get, isNull, isNumber, set } from 'lodash';
import { FormatDateStringPipe } from '../pipe/format-date-string.pipe';

/**
 * Utility Service
 */
@Injectable()
export class UtilService {
  /**
   * Export to Excel functionality
   * @param data Data to be exported into excel
   * @param fileName File name of the excel file
   * @param options Options e.g. headers etc.
   */
  exportToExcel(data, fileName, options) {
    const p = new AngularCsv(data, fileName + this.getCSVFileName(), options);
    return p;
  }
  /**
   * Print JSON
   * @param data Data to be print
   * @param props Properties
   * @param header Heading
   */
  printJSON(data, props, header) {
    printjs({
      printable: data,
      properties: props,
      documentTitle: '',
      header: header,
      headerStyle: 'text-align: center',
      type: 'json',
      gridHeaderStyle: 'color: black;  border: 2px solid black; padding-top: 6px',
      gridStyle: 'border: 1px solid black; padding-left: 5px;'
    });
  }
  /**
   * Get csv file name
   */
  getCSVFileName(): string {
    if (!String.prototype.padStart) {
      String.prototype.padStart = function padStart(targetLength, padString) {
        padString = String((typeof padString !== 'undefined' ? padString : ' '));
        if (this.length > targetLength) {
          return String(this);
        } else {
          targetLength = targetLength - this.length;
          if (targetLength > padString.length) {
            padString += padString.repeat(targetLength / padString.length); // append to original to ensure we are longer than needed
          }
          return padString.slice(0, targetLength) + String(this);
        }
      };
    }
    const d = new Date();
    const name = [(d.getMonth() + 1).toString().padStart(2, '0'),
    d.getDate().toString().padStart(2, '0'),
    d.getFullYear()].join('') + ' ' + [d.getHours().toString().padStart(2, '0'),
    d.getMinutes().toString().padStart(2, '0'),
    d.getSeconds().toString().padStart(2, '0')].join('');
    return name;
  }

  /**
   * Removes empty objects, arrays, empty strings, null and undefined values from objects. Does not alter the original object.
   * @param objectToClean the object to clean
   */
  deepCleanObject(objectToClean: any): any {
    const cleanDeep = (object, {
      emptyArrays = true,
      emptyObjects = true,
      emptyStrings = true,
      nullValues = true,
      undefinedValues = true
    } = {}) => {
      return transform(object, (result, value, key) => {
        // Recurse into arrays and objects.
        if (Array.isArray(value) || isPlainObject(value)) {
          value = cleanDeep(value, { emptyArrays, emptyObjects, emptyStrings, nullValues, undefinedValues });
        }

        // Exclude empty objects.
        if (emptyObjects && isPlainObject(value) && isEmpty(value)) {
          return;
        }

        // Exclude empty arrays.
        if (emptyArrays && Array.isArray(value) && !value.length) {
          return;
        }

        // Exclude empty strings.
        if (emptyStrings && value === '') {
          return;
        }

        // Exclude null values.
        if (nullValues && value === null) {
          return;
        }

        // Exclude undefined values.
        if (undefinedValues && value === undefined) {
          return;
        }

        // Append when recursing arrays.
        if (Array.isArray(result)) {
          return result.push(value);
        }

        result[key] = value;
      });
    };

    return cleanDeep(objectToClean);
  }

  /**
   * Format data for Print or Export
   * @param rows Data to be formatted
   * @param columns Column headers
   */
  formatDataForPrint(rows, columns, type) {
    const data = [];
    rows.forEach(row => {
      const obj = {};
      columns.forEach(col => {
        if (col.type === 'companies' || col.type === 'projects' || col.type === 'source') {
          // Ignore
        } else if (col.type === 'date') {
          obj[col.name] = row[col.prop] ? this.formatDate(row[col.prop]) : '';
        } else if (col.type === 'phone' && type === 'print') {
          const phoneAreaCode = row.phoneAreaCode ? '(' + row.phoneAreaCode + ')' : '';
          const phone = row.phone ? row.phone : '';
          const phoneExt = row.phoneExt ? '*' + row.phoneExt : '';
          obj[col.name] = phoneAreaCode + phone + phoneExt;
        } else if (col.type === 'NumberOfContacts') {
          obj[col.name] = row.companies.length;
        } else {
          if (col.prop.indexOf('.') === -1) {
            obj[col.name] = row[col.prop] ? row[col.prop] : '';
          } else {
            const prop = col.prop.split('.');
            obj[col.name] = row[prop[0]][prop[1]] ? row[prop[0]][prop[1]] : '';
          }
        }
      });
      data.push(obj);
    });
    return data;
  }

  /**
   * Show information on mouse over
   * @param row Row where user currently done mouse over
   * @param columns Columns to be shown on mouse over popover
   */
  formatDataForMouseOver(row, columns) {
    const rowInformation = [];
    columns.forEach(
      col => {
        if (col.prop === 'valuation') {
          const low = row[col.prop]['low'] ? row[col.prop]['low'] : 'NA';
          const high = row[col.prop]['high'] ? row[col.prop]['high'] : 'NA';
          rowInformation.push({
            key: 'Valuation',
            value: low + ' - ' + high
          });
        } else if (col.type === 'date') {
          rowInformation.push({
            key: col.name,
            value: row[col.prop] ? this.formatDate(row[col.prop]) : 'NA'
          });
        } else {
          rowInformation.push({
            key: col.name,
            value: row[col.prop] ? row[col.prop] : 'NA'
          });
        }
      }
    );
    return rowInformation;
  }
  /**
   * Date formatting
   * @param date Date to format
   */
  formatDate(date: string): string {
    return new FormatDateStringPipe().transform(date, 'MM/DD/YYYY');
  }

  /**
   * When the name is blank for a contact, use the parent name
   * @param companies List of companies response
   */
  formatDataForContactName(companies) {
    companies.forEach(company => {
      company.companies.forEach(contact => {
        contact.name = contact.name ? contact.name : company.name;
      });
    });
    return companies;
  }
  /**
   * Uses canvas.measureText to compute and return the width of the given text of given font in pixels
   * @param {String} text  text The text to be rendered
   * @param {String} cssClass The css class that text is to be rendered with
   */
  getTextWidth(text: string, cssClass: string): number {
    const canvas = document.createElement('canvas');
    canvas.classList.add(cssClass);
    const context = canvas.getContext('2d');
    const metrics = context.measureText(text);
    return metrics.width;
  }

  /**
   * Remove duplicate object from array by property
   * @param {any[]} data Array of objects
   * @param {string} prop property name by which duplicates need to removed.
   */
  removeDuplicateObjectByProperty(data: any[], prop: string) {
    return data.filter((item, pos, originalData) => {
      return originalData.map(dataObj => dataObj[prop]).indexOf(item[prop]) === pos;
    });
  }

  /**
 * Get unique random number
 * @param min minimum number range
 * @param max maximum number range
 */
  uniqueRandomNumber(min: number, max: number): FunctionConstructor {
    let prev;
    const rand = () => {
      const num = Math.floor((Math.random() * (max - min + 1)) + min);
      prev = (num === prev && min !== max) ? rand() : num;
      return prev;
    };
    return rand();
  }

  /**
   * Return a new object containing property "id" if it is not present
   * @param data array of objects
   */
  getRowsWithId(data: any[]): any[] {
    const rows = cloneDeep(data);

    rows.forEach(row => {
      const rowId = get(row, 'id');
      if ((isEmpty(rowId) || isNull(rowId)) || !isNumber(rowId)) {
        const keyId = Object.keys(row).find(key => key.toLowerCase().includes('id'));
        const keyIdValue = (isEmpty(keyId) || isNull(keyId)) ? null : get(row, keyId);
        if ((!isEmpty(keyIdValue) && !isNull(keyIdValue)) || isNumber(keyIdValue)) {
          set(row, 'id', keyIdValue);
        } else {
          set(row, 'id', new Date().getTime().toString());
        }
      }
    });

    return rows;
  }
}
