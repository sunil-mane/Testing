import { TestBed, inject } from '@angular/core/testing';
import { MessageService } from './message.service';

/**
  * Message service suite
*/
describe('MessageService', () => {
  // global constants which will be used in specs
  // field name to test
  const fieldName = 'First Name';
  // type of field
  const textType = 'text';
  const selectType = 'select';
  // validation type
  const requiredValidationType = 'required';
  const patternValidationType = 'pattern';
  const minLengthValidationType = 'minlength';
  const maxLengthValidationType = 'maxlength';
  // validation objects returned by angular form validator
  const requiredValidationObject = {
    required: true
  };
  const patternValidationObject = {
    actualValue: '1',
    requiredPattern: '^[A-Za-z ]+$'
  };
  const minLengthValidationObject = {
    actualLength: 1,
    requiredLength: 3
  };
  const maxLengthValidationObject = {
    actualLength: 1,
    requiredLength: 3
  };
  // api error message
  const apiErrorCode = 401;
  // provide service before each spec
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MessageService]
    });
  });
  // should create object when spec starts
  it('should be created', inject([MessageService], (service: MessageService) => {
    expect(service).toBeTruthy();
  }));
  // check if valid message is retured when required validation is there.
  it('should return required text field message', inject([MessageService], (service: MessageService) => {
    const errorMessage = service.getValidationMessage(fieldName, textType, requiredValidationType, requiredValidationObject);
    expect(errorMessage).not.toBeNull();
    expect(errorMessage.length).toBeGreaterThan(0);
    expect(errorMessage).toEqual(`You must enter ${fieldName}.`);
  }));
  // check if valid message is retured when required validation is there for dropdown.
  it('should return required dropdown field message', inject([MessageService], (service: MessageService) => {
    const errorMessage = service.getValidationMessage(fieldName, selectType, requiredValidationType, requiredValidationObject);
    expect(errorMessage).not.toBeNull();
    expect(errorMessage.length).toBeGreaterThan(0);
    expect(errorMessage).toEqual(`You must select ${fieldName}.`);
  }));
  // check if valid message is retured when pattern validation is there.
  it('should return valid pattern field message', inject([MessageService], (service: MessageService) => {
    const errorMessage = service.getValidationMessage(fieldName, textType, patternValidationType, patternValidationObject);
    expect(errorMessage).not.toBeNull();
    expect(errorMessage.length).toBeGreaterThan(0);
    expect(errorMessage).toEqual(`The ${fieldName} contains illegal characters.`);
  }));
  // check if valid message is retured when min length validation is there.
  it('should return valid min length field message', inject([MessageService], (service: MessageService) => {
    const errorMessage = service.getValidationMessage(fieldName, textType, minLengthValidationType, minLengthValidationObject);
    expect(errorMessage).not.toBeNull();
    expect(errorMessage.length).toBeGreaterThan(0);
    expect(errorMessage).toEqual(`${fieldName} must be at least ${minLengthValidationObject.requiredLength} characters.`);
  }));
  // check if valid message is retured when max length validation is there.
  it('should return valid max length field message', inject([MessageService], (service: MessageService) => {
    const errorMessage = service.getValidationMessage(fieldName, textType, maxLengthValidationType, maxLengthValidationObject);
    expect(errorMessage).not.toBeNull();
    expect(errorMessage.length).toBeGreaterThan(0);
    expect(errorMessage).toEqual(`${fieldName} must be no more than ${minLengthValidationObject.requiredLength} characters.`);
  }));
  // check if default validation message is retrurned when no mapping found in config
  it('should return default field message', inject([MessageService], (service: MessageService) => {
    const errorMessage = service.getValidationMessage(fieldName, textType, 'invalid', maxLengthValidationObject);
    expect(errorMessage).not.toBeNull();
    expect(errorMessage.length).toBeGreaterThan(0);
    expect(errorMessage).toEqual(`${fieldName} is not valid.`);
  }));
  // check if valid message is retured when api error message is there.
  it('should return api validation message', inject([MessageService], (service: MessageService) => {
    const errorMessage = service.getAPIErrorMessage(apiErrorCode);
    expect(errorMessage).not.toBeNull();
    expect(errorMessage.length).toBeGreaterThan(0);
    expect(errorMessage).toEqual(`Unauthorized`);
  }));
});
