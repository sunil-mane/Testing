import { TestBed, inject } from '@angular/core/testing';

import { LeftSidebarService } from './left-sidebar.service';
import { ApiService } from './api.service';
import { AlertService } from './alert.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LookupApiService } from './lookup-api.service';
import { RightSlidepanelService } from './right-slidepanel.service';
import { UtilService } from './util.service';

describe('LeftSidebarService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [LeftSidebarService, ApiService, AlertService, LookupApiService, RightSlidepanelService, UtilService]
    });
  });

  it('should be created', inject([LeftSidebarService], (service: LeftSidebarService) => {
    expect(service).toBeTruthy();
  }));
});
