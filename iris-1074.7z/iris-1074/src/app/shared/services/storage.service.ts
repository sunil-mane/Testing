import { Injectable } from '@angular/core';
import { isNil } from 'lodash';

/**
 * Interface for Storage method
 */
export interface Storage {
  get(key: string): any;
  set(key: string, data: any): void;
  remove(key: string): void;
  clear(): void;
}

/**
 * Storage service is a Angular wrapper class to access browsers localStorage and sessionStorage.
 * If localStorage and/or sessionStorage is not available is not available in the browsers then
 * this service keep data in memory.
 * To-Do: Model of saving data.
 * To-Do: Implement Obserable if required
 * To-Do: Implement Generics
 */

@Injectable()
export class StorageService {
  /**
   * Class property to store data in-memory when localStorage and/or sessionStorage is not available in browser
   */
  private interStorage: {
    local: object;
    session: object;
  };

  /**
   * Constuctor
   */
  constructor() {
    // Initialize in-memory property with empty object
    this.interStorage = {
      local: {},
      session: {}
    };
  }

  /**
   * Getter method to access session storage methods
   */
  get session(): Storage {
    return this.storage('session');
  }

  /**
   * Getter method to access local storage methods
   */
  get local(): Storage {
    return this.storage('local');
  }

  /**
   * Method return object containing all common methods.
   * @param {string} type specify the storage name 'session' or 'local' whose methods to be returned
   */
  private storage(type: string): Storage {
    return {
      get: (key: string): any => this.getItem(type, key),
      set: (key: string, data: any): void => { this.setItem(type, key, data); },
      remove: (key: string): void => { this.removeItem(type, key); },
      clear: (): void => { this.clear(type); }
    };
  }

  /**
   * Set data to Storage
   * @param {string} type 'session' or 'local'
   * @param {string} key in session or local storage
   * @param {any} data data to save
   * @returns {void}
   */
  private setItem(type: string, key: string, data: any): void {
    const storageType = type.toLowerCase();
    const stringifyData = JSON.stringify(data);

    if (storageType === 'local' && this.isLocalStorage()) {
      localStorage.setItem(key, stringifyData);
    } else if (storageType === 'session' && this.isSessionStorage()) {
      sessionStorage.setItem(key, stringifyData);
    } else {
      this.interStorage[storageType][key] = stringifyData;
    }
  }

  /**
   * Get data from Storage
   * @param {string} type 'session' or 'local'
   * @param {string} key in session or local storage
   * @returns {any} returns the data if exists or null
   */
  private getItem(type: string, key: string): any {
    let stringifyData;
    const storageType = type.toLowerCase();

    if (storageType === 'local' && this.isLocalStorage()) {
      stringifyData = localStorage.getItem(key);
    } else if (type.toLowerCase() === 'session' && this.isSessionStorage()) {
      stringifyData = sessionStorage.getItem(key);
    } else {
      stringifyData = this.interStorage[storageType][key];
    }

    const parsedData = (isNil(stringifyData)) ? null : JSON.parse(stringifyData);
    return parsedData;
  }

  /**
   * Remove particlar key from Storage
   * @param {string} type 'session' or 'local'
   * @param {string} key in session or local storage
   * @returns {void}
   */
  private removeItem(type: string, key: string): void {
    const storageType = type.toLowerCase();

    if (storageType === 'local' && this.isLocalStorage()) {
      localStorage.removeItem(key);
    } else if (type.toLowerCase() === 'session' && this.isSessionStorage()) {
      sessionStorage.removeItem(key);
    } else {
      delete this.interStorage[storageType][key];
    }
  }

  /**
   * Clear all data from Storage
    * @param {string} type 'session' or 'local'
    * @returns {void}
   */
  private clear(type: string): void {
    const storageType = type.toLowerCase();

    if (storageType !== 'local' && storageType !== 'session') {
      return void 0;
    }

    if (storageType === 'local' && this.isLocalStorage()) {
      localStorage.clear();
    } else if (storageType === 'session' && this.isSessionStorage()) {
      sessionStorage.clear();
    } else {
      this.interStorage[storageType] = {};
    }
  }

  /**
   * Check whether localStorage class exist in browser
   * @returns {boolean}
   */
  private isLocalStorage(): boolean {
    const iris = 'irisapp';
    try {
      localStorage.setItem(iris, iris);
      localStorage.removeItem(iris);
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * Check whether sessionStorage class exist in browser
   * @returns {boolean}
   */
  private isSessionStorage(): boolean {
    const iris = 'irisapp';
    try {
      sessionStorage.setItem(iris, iris);
      sessionStorage.removeItem(iris);
      return true;
    } catch (e) {
      return false;
    }
  }
}
