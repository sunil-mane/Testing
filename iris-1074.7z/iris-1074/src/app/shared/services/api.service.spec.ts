import { TestBed, getTestBed, inject } from '@angular/core/testing';
import { ApiService } from './api.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

const activatedRouteSnapshotStub: any = {
  snapshot: {
    queryParamMap: {
      get: function (name) {
        return 'true';
      }
    }
  }
};

describe('ApiService', () => {
  let injector;
  let service: ApiService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        ApiService,
        { provide: ActivatedRoute, useValue: activatedRouteSnapshotStub }
      ]
    });

    injector = getTestBed();
    service = injector.get(ApiService);
    httpMock = injector.get(HttpTestingController);
  });

  it('should be created', inject([ApiService], (api: ApiService) => {
    expect(api).toBeTruthy();
  }));

  it('should return an Observable<any> if GET request succeed', () => {
    const dummyUsers: any[] = [
      {
        id: 8000,
        userName: 'Hayes.Jasen',
        firstName: 'Marcella',
        lastName: 'Renner',
        middleName: 'E',
        groupCode: 'REPORTER',
        siteCode: 'North Odamouth',
        officeNumber: '993-070-6473',
        email: 'Augustine.Collins@yahoo.com',
        status: ''
      },
      {
        id: 8861,
        userName: 'Hammes.Romaine',
        firstName: 'Cydney',
        lastName: 'Hegmann',
        middleName: 'J',
        groupCode: 'REPORTER',
        siteCode: 'South Bryonshire',
        officeNumber: '254-563-4318',
        email: 'Chadd_Rowe@Kassulke.biz',
        status: 'Active'
      }
    ];

    service.get('users').subscribe((res: any[]) => {
      expect(res.length).toBe(2);
      expect(res).toEqual(dummyUsers);
    });

    const request = httpMock.expectOne(`${service.apiPath}users`);
    expect(request.request.method).toBe('GET');
    request.flush(dummyUsers);
  });

  it('should return error if GET request failed', () => {
    service.get('users', { params: { _page: '2', _limit: '10' } }).subscribe((res: any) => { }, (err) => {
      expect(err instanceof HttpErrorResponse).toBeTruthy();
    });

    const request = httpMock.expectOne(`${service.apiPath}users?_page=2&_limit=10`);
    request.error(new ErrorEvent('ERROR_LOADING_COUNTRIES'));

    httpMock.verify();
  });

  it('should return an Observable<any> if POST request succeed', () => {
    const payload = {
      id: 8861,
      userName: 'Hammes.Romaine',
      firstName: 'Cydney',
      lastName: 'Hegmann',
      middleName: 'J',
      groupCode: 'REPORTER',
      siteCode: 'South Bryonshire',
      officeNumber: '254-563-4318',
      email: 'Chadd_Rowe@Kassulke.biz',
      status: 'Active'
    };

    service.post('users', payload).subscribe((res: any) => {
      expect(res).toEqual(payload);
    });

    const request = httpMock.expectOne(`${service.apiPath}users`);
    expect(request.request.method).toBe('POST');
  });

  it('should return error if POST request failed', () => {
    service.post('users', {}).subscribe((res: any) => { }, (err) => {
      expect(err instanceof HttpErrorResponse).toBeTruthy();
    });

    const request = httpMock.expectOne(`${service.apiPath}users`);
    request.error(new ErrorEvent('ERROR_LOADING_COUNTRIES'));

    httpMock.verify();
  });

  it('should return an Observable<any> if PUT request succeed', () => {
    const payload = {
      id: 8861,
      userName: 'Hammes.Romaine',
      firstName: 'Cydney',
      lastName: 'Hegmann',
      middleName: 'J',
      groupCode: 'REPORTER',
      siteCode: 'South Bryonshire',
      officeNumber: '254-563-4318',
      email: 'Chadd_Rowe@Kassulke.biz',
      status: 'Active'
    };

    service.put('users', payload).subscribe((res: any) => {
      expect(res).toEqual(payload);
    });

    const request = httpMock.expectOne(`${service.apiPath}users`);
    expect(request.request.method).toBe('PUT');
  });

  it('should return error if PUT request failed', () => {
    service.put('users', {}).subscribe((res: any) => { }, (err) => {
      expect(err instanceof HttpErrorResponse).toBeTruthy();
    });

    const request = httpMock.expectOne(`${service.apiPath}users`);
    request.error(new ErrorEvent('ERROR_LOADING_COUNTRIES'));

    httpMock.verify();
  });

  it('should return an Observable<any> if DELETE request succeed', () => {
    service.delete('users/8000').subscribe((res: any) => {
      expect(res).toBeNull();
    });

    const request = httpMock.expectOne(`${service.apiPath}users/8000`);
    expect(request.request.method).toBe('DELETE');
  });

  it('should return error if DELETE request failed', () => {
    service.delete('users/8000').subscribe((res: any) => { }, (err) => {
      expect(err instanceof HttpErrorResponse).toBeTruthy();
    });

    const request = httpMock.expectOne(`${service.apiPath}users/8000`);
    request.error(new ErrorEvent('ERROR_LOADING_COUNTRIES'));

    httpMock.verify();
  });
});
