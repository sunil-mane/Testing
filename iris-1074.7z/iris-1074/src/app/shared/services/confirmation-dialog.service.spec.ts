import { TestBed, inject, getTestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationDialogService } from './confirmation-dialog.service';
import { ConfirmationDialogComponent } from './../components/confirmation-dialog/confirmation-dialog.component';
import { SharedModule } from './../shared.module';
describe('AlertService', () => {
  let confirmDialogService;
  let routerMock;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NgbModule.forRoot(),
        RouterTestingModule.withRoutes([]),
        SharedModule.forRoot()
      ],
      providers: [ConfirmationDialogService],
    });

    confirmDialogService = TestBed.get(ConfirmationDialogService);
    routerMock = TestBed.get(RouterTestingModule);
  });

  it('should be created', inject([ConfirmationDialogService], (service: ConfirmationDialogService) => {
    expect(service).toBeTruthy();
  }));
  it('should return promise when confirm is called', inject([ConfirmationDialogService], (service: ConfirmationDialogService) => {
    const dialog = service.confirm('test', 'Are you sure?');
    expect(dialog).toBeTruthy();
  }));
});
