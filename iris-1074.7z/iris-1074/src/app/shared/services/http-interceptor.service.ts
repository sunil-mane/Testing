import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SumoLoggerService } from './sumo-logger.service';
import { environment } from '../../../environments/environment';

/**
 * Http interceptor to handle http exception and globally handle all request headers
 */

@Injectable()
export class HttpInterceptorService implements HttpInterceptor {
  // Http status on which modal should be displayed and user should be redirected to home page.
  private statusCodeForLogout: number[];

  /** Constructor */
  constructor(
    private logger: SumoLoggerService
  ) {
    // Http status defined.
    this.statusCodeForLogout = [401, 403, 404, 504];
  }

  /**
   * Intercetor method that HttpClientModule to call for every Http request and response
   * @param req this is request object
   * @param next The next object represents the next interceptor in the chain of interceptors
   */
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // To set a header first request object need to cloned as it is immutable
    // Then set the headers property. Header property is not assignable as it return a new object every is also immutable
    let customRequest = req.clone({
      headers: req.headers
        .set('Content-Type', 'application/json; charset=UTF-8')
    });
    // add authorization header
    customRequest = customRequest.clone({
      headers: customRequest.headers
        .set('Authorization', environment.apiAuthorizationHeader)
    });

    // Handle response
    return next.handle(customRequest)
      .pipe(
        catchError((error, caught) => {
          if (error instanceof HttpErrorResponse) {
            if (this.statusCodeForLogout.includes(error.status)) {
              this.logger.error(error);
            }
            return throwError(error);
          }
          return caught;
        })
      );
  }
}
