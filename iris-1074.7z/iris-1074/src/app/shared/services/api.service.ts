import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ApiHttpOptions } from '../models/ApiParams';
import { ActivatedRoute } from '@angular/router';

/**
 * ApiService is a single service to handle application-wide HTTP requests and exceptions.
 */
@Injectable()
export class ApiService {

  apiPath = `${environment.apiSvcUrl}${environment.apiPath}`;

  public constructor(public http: HttpClient, private route: ActivatedRoute) {
    // In order to run mock, set the api path based on query param.
    const mock = this.getParam('mock'); // this.route.snapshot.queryParamMap.get('mock') || 'false';
    if (mock === 'true' && ! environment.production) {
      this.apiPath = '/api/';
    }
  }

  /**
   * GET request
   * @param {string} endPoint it doesn't need / in front of the end point
   * @param {ApiHttpOptions} options http request header, query params as object.
   * @returns {Observable<T>}
   */
  public get<T>(endPoint: string, options?: ApiHttpOptions): Observable<T> {
    return this.http.get<T>(`${this.apiPath}${endPoint}`, options);
  }

  /**
   * POST request
   * @param {string} endPoint end point of the api
   * @param {object} body body of the request.
   * @param {ApiHttpOptions} options http request header, query params as object.
   * @returns {Observable<T>}
   */
  public post<T>(endPoint: string, body: object, options?: ApiHttpOptions): Observable<T> {
    return this.http.post<T>(`${this.apiPath}${endPoint}`, body, options);
  }

  /**
   * PUT request
   * @param {string} endPoint end point of the api
   * @param {object} body body of the request.
   * @param {ApiHttpOptions} options http request header, query params as object.
   * @returns {Observable<T>}
   */
  public put<T>(endPoint: string, body: object, options?: ApiHttpOptions): Observable<T> {
    return this.http.put<T>(`${this.apiPath}${endPoint}`, body, options);
  }

  /**
   * DELETE request
   * @param {string} endPoint end point of the api
   * @param {ApiHttpOptions} options http request header, query params as object.
   * @returns {Observable<T>}
   */
  public delete<T>(endPoint: string, options?: ApiHttpOptions): Observable<T> {
    return this.http.delete<T>(`${this.apiPath}${endPoint}`, options);
  }

  private getParam(name) {
    const results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (! results) {
      return 0;
    }
    return results[1] || 0;
  }
}
