import { of as observableOf, Observable } from 'rxjs';

import { delay } from 'rxjs/operators';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Lookups } from '../../../mocks/lookups';
import { environment } from '../../../environments/environment';

import { ProjectSearch } from '../../../mocks/projectSearch';
import { CompanyProjects } from '../../../mocks/companyProjects';
import { CompanySearch } from '../../../mocks/companySearch';
import { FeedContent } from '../../../mocks/FeedContent';
import { Disposition } from '../../../mocks/disposition';

@Injectable()
export class FakeBackendProdInterceptorService implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // pass through any requests not handled above
    return next.handle(req);
  }
}

@Injectable()
export class FakeBackendInterceptorService implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (!environment.production && req.url.indexOf('/api/') > -1) {
      let body = null;
      if (req.url.endsWith('/valuation')) {
        body = Lookups.getValuation(14);
      } else if (req.url.endsWith('/country')) {
        body = Lookups.getCountry();
      } else if (req.url.endsWith('/state')) {
        body = Lookups.getStates('USA');
      } else if (req.url.endsWith('/city')) {
        body = Lookups.getCities('USAAL');
      } else if (req.url.endsWith('/county')) {
        body = Lookups.getCounties('USAAL');
      } else if (req.url.endsWith('/companyType')) {
        body = Lookups.getCompanyType(51);
      } else if (req.url.endsWith('/projectStage')) {
        body = Lookups.getProjectStage(6);
      } else if (req.url.endsWith('/project/search')) {
        body = ProjectSearch.getProjects(req, 444);
      } else if (req.url.endsWith('/projects')) {
        body = CompanyProjects.getProjects(5);
      } else if (req.url.endsWith('/company/search')) {
        body = CompanySearch.getCompanies(req, 444);
      } else if (req.url.endsWith('/feed/content')) {
        body = FeedContent.getFeedContent(req, 100);
      } else if (req.url.endsWith('/feed/dispose')) {
        body = Disposition.getProjects(req, 444);
      } else if (req.url.endsWith('/feed')) {
        body = Lookups.getFeeds();
      } else if (req.url.endsWith('/region')) {
        body = Lookups.getRegions();
      } else if (req.url.endsWith('/reporter')) {
        body = Lookups.getReporters();
      } else if (req.url.endsWith('/disposition')) {
        body = Lookups.getDispositionReasons();
      } else if (req.url.endsWith('/feed/drnumber')) {
        body = FeedContent.getDRNumber();
      } else if (req.url.indexOf('/feed/') > 0 && !req.url.endsWith('/feed')) {
        body = FeedContent.getFeedDetails();
      } else {
        console.error('Missing mock for ' + req.method + ' ' + req.url);
        return next.handle(req);
      }
      this.logMockedData(req, body);
      return observableOf(new HttpResponse({ status: 200, body: body })).pipe(delay(1000));
    }
    // pass through any requests not handled above
    return next.handle(req);
  }

  private logMockedData(req, mockedData) {
    console.groupCollapsed('Mocked ' + req.method + ' ' + req.url + ' ' + mockedData.status);

    console.group('JSON');
    console.dir(mockedData);
    console.groupEnd();

    console.groupEnd();
  }

}
