import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiService } from './api.service';
import { Company, CompanyPopupLookup } from '../models/CompanyPopupLookup';
import { Project, ProjectPopupLookup } from '../models/ProjectPopupLookup';
import { AlertService } from './alert.service';

/**
 * Common service to send message to right panel
 */
@Injectable()
export class RightSlidepanelService {
  // private variable as behaviour subject
  private ProjectNumberObservable = new BehaviorSubject<number>(0);
  // project number variable as subscriber
  ProjectNumber = this.ProjectNumberObservable.asObservable();
  // private variable as behaviour subject
  private CompanyObservable = new BehaviorSubject<Object>(null);
  // Company Id variable as subscriber
  Company$ = this.CompanyObservable.asObservable();
  // Show right panel flag
  showRightPanel: boolean;

  /**
   * Constructor
   */
  constructor(private apiService: ApiService, private alertService: AlertService) {
    this.showRightPanel = false;
  }
  /**
  * Update project number to send from grid to right panel
  * @param {number} projectNumber Project number from grid
  */
  setProjectNumber(projectNumber: number) {
    // update observable
    this.ProjectNumberObservable.next(projectNumber);
  }

  /**
  * Update company id to send from grid to right panel
  * @param {string} companyId Company id from grid
  */
  setCompany(company: string) {
    // update observable
    this.CompanyObservable.next(company);
  }

  /**
   * get companies for project method
   * @param {number} projectNumber project id
   * @returns {Promise} promise object with list of companies
   */
  getCompaniesForProject(projectNumber: number): Promise<Company[]> {
    // get data from api
    return this.apiService.get<CompanyPopupLookup>(`project/${projectNumber}/companies`)
      .pipe(
        map(response => response.data.companies)
      ).toPromise();
  }

  /**
 * get projects for company method
 * @param {string} companyId company id
 * @returns {Promise} promise object with list of projects
 */
  getProjectsForCompany(companyId: string): Promise<Project[]> {
    // get data from api
    return this.apiService.get<ProjectPopupLookup>(`company/${companyId}/projects`)
      .pipe(
        map(response => response.data.projects)
      ).toPromise();
  }
}
