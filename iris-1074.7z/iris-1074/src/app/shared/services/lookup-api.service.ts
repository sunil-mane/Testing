import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { ApiService } from './api.service';
import { ProjectStageLookup, Stages } from '../models/ProjectStageLookup';
import { ProjectTypes, ProjectTypeLookup } from '../models/ProjectTypeLookup';
import { ValuationLookup, Valuation } from '../models/ValuationLookup';
import { CompanyTypeLookup, Company } from '../models/CompanyTypeLookup';
import { Country, CountryLookup } from '../models/CountryLookup';
import { State, StatesLookup } from '../models/StatesLookup';
import { CountyState, CountyLookup } from '../models/CountyLookup';
import { CityLookup } from '../models/CityLookup';
import { isArray, isNil, isEmpty, isNumber } from 'lodash';
import { Feed, FeedLookup } from '../models/Feed';
import { RegionLookup, Region } from '../models/Region';
import { Reporter, ReporterLookup } from '../models/Reporter';
import { DispositionReasonLookup, DispositionReason } from '../models/DispositionReasonLookup';
@Injectable()
export class LookupApiService {
  // Project Stages
  private projectStages: Array<Stages>;
  // Project Types
  private projectTypes: Array<ProjectTypes>;
  // Valuations
  private valuations: Array<Valuation>;
  // Company Types
  private companyTypes: Array<Company>;
  // Locations
  private countries: Array<Country>;
  private states: Array<State>;
  private counties: Array<CountyState>;
  private feeds: Array<Feed>;
  private regions: Array<Region>;
  private reporters: Array<Reporter>;
  private dispostionReasons: Array<DispositionReason>;
  constructor(private apiService: ApiService) {
    this.projectStages = [];
    this.projectTypes = [];
    this.valuations = [];
    this.companyTypes = [];
    this.counties = [];
    this.states = [];
    this.counties = [];
    this.feeds = [];
    this.regions = [];
    this.reporters = [];
    this.dispostionReasons = [];
  }

  /**
   * Get Project Stages API response
   * @return {Observable<ProjectStageLookup>} HttpResponse or HttpErrorResponse
   */
  getProjectStages(): Observable<ProjectStageLookup> {
    return this.apiService.get<ProjectStageLookup>('lookup/projectStage').pipe(tap(res => this.projectStages = res.data.stages));
  }

  /**
   * Get Project Stage Name By Id
   * @param {string} id Id of the Stage object
   * @returns {string} Name of the Stage object
   */
  getProjectStageNameById(id: string): string {
    let stageName = null;
    const findStage = (stages) => {
      stages.some(stage => {
        if (stage.id === id) {
          stageName = stage.name;
          return true;
        }
        if (isArray(stage.stage)) {
          findStage(stage.stage);
        }
      });
    };
    if (!isEmpty(this.projectStages)) {
      findStage(this.projectStages);
    }
    return stageName;
  }

  /**
   * Get Project Stage Id By Name
   * @param {string} name Name of the Stage object
   * @returns {string} Id of the Stage object
   */
  getProjectStageIdByName(name: string): string {
    let stageId = null;
    const findStage = (stages) => {
      stages.some(stage => {
        if (isArray(stage.stage)) {
          findStage(stage.stage);
        } else {
          if (stage.name === name) {
            stageId = stage.id;
            return true;
          }
        }
      });
    };
    if (!isEmpty(this.projectStages)) {
      findStage(this.projectStages);
    }
    return stageId;
  }

  /**
   * Get Project Type API response
   * @return {Observable<ProjectStageLookup>} HttpResponse or HttpErrorResponse
   */
  getProjectTypes(): Observable<ProjectTypeLookup> {
    return this.apiService.get<ProjectTypeLookup>('lookup/projectTypeWithParent').pipe(tap(res => this.projectTypes = res.data.types));
  }

  /**
   * Get Project Type Name By code
   * @param {string} code Code of the Type object
   * @returns {string} Name of the Type object
   */
  getProjectTypeNameByCode(code: string): string {
    let typesName = null;
    const findTypes = (types) => {
      types.some(type => {
        if (type.code === code) {
          typesName = type.name;
          return true;
        }
        if (isArray(type.subtypes)) {
          findTypes(type.subtypes);
        }
      });
    };
    if (!isEmpty(this.projectTypes)) {
      findTypes(this.projectTypes);
    }
    return typesName;
  }

  /**
   * Get Project Type Name By code
   * @param {string} name Nme of the Type object
   * @returns {string} Code of the Type object
   */
  getProjectTypeCodeByName(name: string): string {
    let typesCode = null;
    const findTypes = (types) => {
      types.some(type => {
        if (isArray(type.subtypes)) {
          findTypes(type.subtypes);
        } else {
          if (type.name === name) {
            typesCode = type.code;
            return true;
          }
        }
      });
    };
    if (!isEmpty(this.projectTypes)) {
      findTypes(this.projectTypes);
    }
    return typesCode;
  }

  /**
   * Get Valuations API response
   * @return {Observable<ProjectStageLookup>} HttpResponse or HttpErrorResponse
   */
  getValuations(): Observable<ValuationLookup> {
    return this.apiService.get<ValuationLookup>('lookup/valuation').pipe(tap(res => this.valuations = res.data.valuations));
  }

  /**
   * Get Valuation Low/High By Id
   * @param {string} id Id of the Valuation object
   * @param type
   * @returns {number} low or high value
   */
  getValuationLowHighById(id: string, type: 'low' | 'high'): number {
    const valuation = (isEmpty(this.valuations)) ? null : this.valuations.find(value => value.id === id);
    return (isNil(valuation)) ? valuation : valuation[type];
  }

  /**
   * Get Valuation Id By Low/High
   * @returns {string} id of valuation
   * @param lowHighValue
   * @param type
   */
  getValuationIdByLowHigh(lowHighValue: number, type: 'low' | 'high'): string {
    const valuation = (isEmpty(this.valuations)) ? null : this.valuations.find(value => value[type] === lowHighValue);
    return (isNil(valuation)) ? valuation : valuation.id;
  }

  /**
   * Get Company Types API response
   * @return {Observable<CompanyTypeLookup>} HttpResponse or HttpErrorResponse
   */
  getCompanyTypes(): Observable<CompanyTypeLookup> {
    return this.apiService.get<CompanyTypeLookup>('lookup/companyType').pipe(tap(res => this.companyTypes = res.data.companyTypes));
  }

  /**
   * Get Company Type Name By Id
   * @param {string} id Id of the Company Type object
   * @returns {string} Company Type
   */
  getCompanyTypeNameById(id: string): string {
    const type = (isEmpty(this.companyTypes)) ? null : this.companyTypes.find(value => value.id === id);
    return (isNil(type)) ? type : type.type;
  }

  /**
   * Get Company Type By Name
   * @param {string} type Name of the Company type object
   * @returns {string} Compnay Type ID
   */
  getCompanyTypeIdByName(name: string): string {
    const type = (isEmpty(this.companyTypes)) ? null : this.companyTypes.find(value => value.type === name);
    return (isNil(type)) ? type : type.id;
  }

  /**
   * Get Country API response
   * @return {Observable<CountryLookup>} HttpResponse or HttpErrorResponse
   */
  getCountries(): Observable<CountryLookup> {
    return this.apiService.get<CountryLookup>('lookup/country').pipe(tap(res => this.countries = res.data.countries));
  }

  /**
   * Get Country Name By Id
   * @param {string} id Id of the Country object
   * @returns {string} Country Name
   */
  getCountryNameById(id: string): string {
    const country = (isEmpty(this.countries)) ? null : this.countries.find(value => value.id === id);
    return (isNil(country)) ? country : country.name;
  }

  /**
   * Get Country By Name
   * @param {string} name Name of the Country object
   * @returns {string} Country ID
   */
  getCountryIdByName(name: string): string {
    const country = (isEmpty(this.countries)) ? null : this.countries.find(value => value.name === name);
    return (isNil(country)) ? country : country.id;
  }

  /**
   * Get States API response
   * @return {Observable<StatesLookup>} HttpResponse or HttpErrorResponse
   */
  getStates(country): Observable<StatesLookup> {
    return this.apiService.get<StatesLookup>('lookup/state', { params: { country } }).pipe(tap(res => this.states = res.data.states));
  }

  /**
   * Get States Name By Id
   * @param {string} id Id of the States object
   * @returns {string} States Name
   */
  getStatesNameById(id: string): string {
    const state = (isEmpty(this.states)) ? null : this.states.find(value => value.id === id);
    return (isNil(state)) ? state : state.name;
  }

  /**
   * Get States By Name
   * @param {string} name Name of the States object
   * @returns {string} States ID
   */
  getStatesIdByName(name: string): string {
    const state = (isEmpty(this.states)) ? null : this.states.find(value => value.name === name);
    return (isNil(state)) ? state : state.id;
  }

  /**
   * Get County API response
   * @return {Observable<CountyLookup>} HttpResponse or HttpErrorResponse
   */
  getCounties(state): Observable<CountyLookup> {
    return this.apiService.get<CountyLookup>('lookup/county', { params: { state } }).pipe(tap(res => this.counties = res.data.states));
  }

  /**
   * Get County Name By Id
   * @param {string} id Id of the County object
   * @returns {string} Name of the County object
   */
  getCountyNameById(id: string): string {
    let countyName = null;
    const isCountyName = isEmpty(this.counties) ? false : this.counties.some((state) => {
      const countyObj = state.counties.find(county => county.id === id);
      if (!isNil(countyObj)) {
        countyName = countyObj.name;
        return true;
      }
    });
    return (isCountyName) ? countyName : null;
  }

  /**
   * Get County Id By Name
   * @param {string} name Name of the County object
   * @returns {string} Id of the County object
   */
  getCountyIdByName(name: string): string {
    let countyId = null;
    const isCountyId = isEmpty(this.counties) ? false : this.counties.some((state) => {
      const countyObj = state.counties.find(county => county.name === name);
      if (!isNil(countyObj)) {
        countyId = countyObj.id;
        return true;
      }
    });
    return (isCountyId) ? countyId : null;
  }

  /**
   * Get City API response
   * @return {Observable<CityLookup>} HttpResponse or HttpErrorResponse
   */
  getCities(state): Observable<CityLookup> {
    return this.apiService.get<CityLookup>('lookup/city', { params: { state } });
  }
  /**
   * Get Feed API response
   * @return {Observable<FeedLookup>} HttpResponse or HttpErrorResponse
   */
  getFeeds(): Observable<FeedLookup> {
    return this.apiService.get<FeedLookup>('lookup/feed').pipe(tap(res => this.feeds = res.data.feeds));
  }

  /**
   * Get feed name by id
   * @param {string} feedId feed id
   * @returns {string} feed name
   */
  getFeedNameById(feedId: string): string {
    if (!isNil(feedId) && !isEmpty(feedId)) {
      const feed = this.feeds.find(val => val.id === feedId);
      return (feed) ? feed.name : null;
    }
    return null;
  }

  /**
   * Get Region API response
   * @return {Observable<RegionLookup>} HttpResponse or HttpErrorResponse
   */
  getRegions(): Observable<RegionLookup> {
    return this.apiService.get<RegionLookup>('lookup/region').pipe(tap(res => this.regions = res.data.regions));
  }

  /**
   * Get region name by id
   * @param {string} regionId region id
   * @returns {string} region name
   */
  getRegionNameById(regionId: string): string {
    if (isNumber(regionId) || !isEmpty(regionId)) {
      const region = this.regions.find(val => val.id === regionId);
      return (region) ? region.name : null;
    }
    return null;
  }

  /**
   * Get Reporter API response
   * @return {Observable<ReporterLookup>} HttpResponse or HttpErrorResponse
   */
  getReporters(): Observable<ReporterLookup> {
    return this.apiService.get<ReporterLookup>('lookup/reporter');
  }
  /**
   * Get Dispostion Reason API response
   * @return {Observable<DispositionReasonLookup>} HttpResponse or HttpErrorResponse
   */
  getDispostionReasons(): Observable<DispositionReasonLookup> {
    return this.apiService.get<DispositionReasonLookup>('lookup/disposition')
      .pipe(tap(res => this.dispostionReasons = res.data.dispositions));
  }

  /**
   * Get Dispostion description by id
   * @param {string} dispostionId region id
   * @returns {string} Dispostion description
   */
  getDispostionReasonDescriptioneById(dispostionId: string): string {
    if (isNumber(dispostionId) || !isEmpty(dispostionId)) {
      const dispostion = this.dispostionReasons.find(val => val.id === dispostionId);
      return (dispostion) ? dispostion.description : null;
    }
    return null;
  }
}
