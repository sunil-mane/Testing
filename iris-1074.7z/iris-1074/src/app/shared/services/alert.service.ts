import { Injectable } from '@angular/core';
import { Alert, AlertType } from '../models/Alert';
import { Observable, Subject } from 'rxjs';
import { NavigationStart, Router } from '@angular/router';

/**
 * The alert service acts as a bridge between angular components. It's responsible for sending and clearing page level
 * alert messages. it uses the Observable and Subject classes to enable communication with other components.
 */

@Injectable()
export class AlertService {

  private subject = new Subject<Alert>();
  private keepAfterRouteChange = false;

  /**
   * The constructor subscribes to the router 'NavigationStart' event to automatically clear alert messages on route change,
   * unless the keepAfterRouteChange flag is set to true, in which case the alert messages survive a single route change
   * and are cleared on the next route change.
   * @param {Router} router
   */
  constructor(private router: Router) {
    // clear alert messages on route change unless 'keepAfterRouteChange' flag is true
    router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        if (this.keepAfterRouteChange) {
          // only keep for a single route change
          this.keepAfterRouteChange = false;
        } else {
          // clear alert messages
          this.clear();
        }
      }
    });
  }

  /**
   * return the alert as an observable
   * @returns {Observable<any>}
   */
  getAlert(): Observable<any> {
    return this.subject.asObservable();
  }

  success(message: string, keepAfterRouteChange = false) {
    this.alert(AlertType.Success, message, keepAfterRouteChange);
  }

  error(message: string, keepAfterRouteChange = false) {
    this.alert(AlertType.Error, message, keepAfterRouteChange);
  }

  info(message: string, keepAfterRouteChange = false) {
    this.alert(AlertType.Info, message, keepAfterRouteChange);
  }

  warn(message: string, keepAfterRouteChange = false) {
    this.alert(AlertType.Warning, message, keepAfterRouteChange);
  }

  alert(type: AlertType, message: string, keepAfterRouteChange = false) {
    this.keepAfterRouteChange = keepAfterRouteChange;
    this.subject.next(<Alert>{type: type, message: message });
  }

  clear() {
    // clear alerts
    this.subject.next();
  }
}
