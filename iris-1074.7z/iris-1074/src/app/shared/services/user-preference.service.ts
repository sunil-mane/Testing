import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient} from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserPreferenceService {

  httpOptions;

  constructor(private http: HttpClient, private authService: AuthService) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'USERNAME': 'sonal.gandhi@construction.com', // this.authService.getEmail(),
        'AppId': environment.appId
      })
    };
  }

  loadAll() {
    return this.http.post(environment.JAPIHost, null, this.httpOptions);
  }

  saveAll(userPreferences) {
    return this.http.post(environment.JAPIHost + '/save', userPreferences, this.httpOptions);
  }
}
