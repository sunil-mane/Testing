import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RightSlidepanelService } from './right-slidepanel.service';
import { ApiService } from './api.service';
import { AlertService } from './alert.service';

describe('RightSlidepanelService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [RightSlidepanelService, ApiService, AlertService]
    });
  });

  it('should be created', inject([RightSlidepanelService], (service: RightSlidepanelService) => {
    expect(service).toBeTruthy();
  }));
});
