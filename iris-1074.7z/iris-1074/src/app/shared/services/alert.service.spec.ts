import { TestBed, inject, getTestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AlertService } from './alert.service';
import { Observable } from 'rxjs/Observable';
import { Alert, AlertType } from '../models/Alert';

describe('AlertService', () => {
  let alertService;
  let routerMock;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([])
      ],
      providers: [AlertService],
    });

    alertService = TestBed.get(AlertService);
    routerMock = TestBed.get(RouterTestingModule);
  });

  it('should be created', inject([AlertService], (service: AlertService) => {
    expect(service).toBeTruthy();
  }));

  it('getAlert should return an Observable', inject([AlertService], (service: AlertService) => {
    const alert = alertService.getAlert();
    expect(alert).toBeTruthy();
  }));

  it('should return sucess message', inject([AlertService], (service: AlertService) => {
    alertService.getAlert().subscribe((alert: Alert) => {
      expect(alert.type).toBe(AlertType.Success);
      expect(alert.message).toBe('Test Success');
    });
    alertService.success('Test Success');
  }));

  it('should return warning message', inject([AlertService], (service: AlertService) => {
    alertService.getAlert().subscribe((alert: Alert) => {
      expect(alert.type).toBe(AlertType.Warning);
      expect(alert.message).toBe('Test Warning');
    });
    alertService.warn('Test Warning');
  }));

  it('should return error message', inject([AlertService], (service: AlertService) => {
    alertService.getAlert().subscribe((alert: Alert) => {
      expect(alert.type).toBe(AlertType.Error);
      expect(alert.message).toBe('Test Error');
    });
    alertService.error('Test Error');
  }));

  it('should return informational message', inject([AlertService], (service: AlertService) => {
    alertService.getAlert().subscribe((alert: Alert) => {
      expect(alert.type).toBe(AlertType.Info);
      expect(alert.message).toBe('Test Info');
    });
    alertService.info('Test Info');
  }));

  it('should clear the alert', inject([AlertService], (service: AlertService) => {
    const alert = alertService.clear();
    expect(alert).toBe(undefined);
  }));
});
