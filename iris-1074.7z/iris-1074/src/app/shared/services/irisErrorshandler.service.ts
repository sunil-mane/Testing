
import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { SumoLoggerService } from './sumo-logger.service';

/**
 * This service catch all runtime errors. If http interceptor being defined then this service will not catch Http errors
 * This service implements Angular Angular ErrorHandler and provide it to ErrorHandler service in ShareModule
 */

@Injectable()
export class IrisErrorsHandler implements ErrorHandler {

  /**
   * Construction
   * @param injector Angular DI
   */
  constructor(private injector: Injector) { }

  /**
   * Error handler method. It takes in error and pass it to sumo logger service.
   * @param {Error | HttpErrorResponse} error Error object
   */
  handleError(error: Error | HttpErrorResponse) {
    // instance of SumoLoggerService
    const logger = this.injector.get(SumoLoggerService);

    // Calling error method of SumoLoggerService and passing error as parameter
    logger.error(error);
  }
}

