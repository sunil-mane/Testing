import { Injectable } from '@angular/core';
import { ValidationErrors } from '@angular/forms';
import * as messages from './../config/messages.json';

/**
 * Common component to gerenate messages
 */

@Injectable()
export class MessageService {
  NAME_LITERAL = /{name}/gi;
  TYPE_LITERAL = /{type}/gi;
  MINLENGTH_LITERAL = /{minlength}/gi;
  MAXLENGTH_LITERAL = /{maxlength}/gi;
  /**
    * Constructor
  */
  constructor() { }
  /**
    * Get Validation Message for form control
    * @param property: Property name from model
    * @param type: Type of input
    * @param validationType: validation type which will be mapped with validation message from json
    * @param validationObject: Validation object returned from angular forms validator
    * @returns string message of validation
  */
  getValidationMessage(property: string, type: string, validationType: string,
                       validationObject: ValidationErrors): string {
    // An empty string variable
    let message = '';
    // validator messages from json
    const validators = (<any>messages).validation;
    // get each message object.
    message = validators[validationType];
    // add prefix based on input type
    if (validators[validationType]) {
      let text = 'enter';
      // check if its input or select
      if (type === 'select') {
        text = 'select';
      }
      message = message.replace(this.TYPE_LITERAL, text);
      message = message.replace(this.NAME_LITERAL, property);

      // check for min length
      if (validationType === 'minlength') {
        message = message.replace(this.MINLENGTH_LITERAL, validationObject.requiredLength);
      }
      // check for max length
      if (validationType === 'maxlength') {
        message = message.replace(this.MAXLENGTH_LITERAL, validationObject.requiredLength);
      }
    } else {
      message = `${property} is not valid.`;
    }
    return message;
  }
  /**
    * Get Validation Message for api exception
    * @param code: code of exception from api or angular code
    * @returns message string.
  */
  getAPIErrorMessage(code: number): string {
    let message = '';
    message = (<any>messages).apiMessages[code.toString()];
    return message;
  }
}
