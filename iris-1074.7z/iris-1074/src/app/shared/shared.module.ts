/** Import: Angular Framework Modules */
import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, ErrorHandler } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';

/** Import: Angular Third Party Modules */
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { TreeviewModule } from 'ngx-treeview';
import { TextMaskModule } from 'angular2-text-mask';
import { NgxPageScrollModule } from 'ngx-page-scroll';

/** Import: Shared Compponent  */
import { HeaderComponent } from './components/header/header.component';
import { LeftNavigationComponent } from './components/leftnav/leftnav.component';
import { FooterComponent } from './components/footer/footer.component';
import { GridComponent } from './components/grid/grid.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { PaginationLimitComponent } from './components/pagination-limit/pagination-limit.component';
import { LoadOverlayComponent } from './components/load-overlay/load-overlay.component';
import { DropdownGridComponent } from './components/dropdown-grid/dropdown-grid.component';
import { MultiCheckboxTreeDropdownComponent } from './components/multi-checkbox-tree-dropdown/multi-checkbox-tree-dropdown.component';
import { DatePickerComponent } from './components/date-picker/date-picker.component';
import { AlertComponent } from './components/alert/alert.component';
import { DrSearchComponent } from './components/dr-search/dr-search.component';
import { LeftSidebarComponent } from './components/left-sidebar/left-sidebar.component';
import { AppliedFiltersComponent } from './components/applied-filters/applied-filters.component';
import { ProjectSearchFormComponent } from './forms/project-search-form/project-search-form.component';
import { AddressFormComponent } from './forms/address-form/address-form.component';
import { OtherProjectInfoComponent } from './forms/other-project-info/other-project-info.component';
import { CompanyInfoFormComponent } from './forms/company-info-form/company-info-form.component';
import { CompanyPopupComponent } from './../projects/company-popup/company-popup.component';
import { CompanyContactInfoFormComponent } from './forms/company-contact-info-form/company-contact-info-form.component';
import { GridActionButtonsComponent } from './components/grid-action-buttons/grid-action-buttons.component';
import { PhoneMaskComponent } from './components/phone-mask/phone-mask.component';
import { EfeedSearchFormComponent } from './forms/efeed-search-form/efeed-search-form.component';
import { FeedDispositionSearchFormComponent } from './forms/feed-disposition-search-form/feed-disposition-search-form.component';
import { PageTabNavigationComponent } from './components/page-tab-navigation/page-tab-navigation.component';
import { ConfirmationDialogComponent } from './components/confirmation-dialog/confirmation-dialog.component';
import { ContentTabNavigationComponent } from './components/content-tab-navigation/content-tab-navigation.component';
import { ContentAccordionComponent } from './components/content-accordion/content-accordion.component';
import { LeftSidebarLinksComponent } from './components/left-sidebar-links/left-sidebar-links.component';
import { ContentCardsComponent } from './components/content-cards/content-cards.component';

/** Import: Shared Directives */
import { RemoveMultipleSpacesDirective } from './directives/remove-multiple-spaces.directive';
import { InputRestrictionDirective, ToUpperCaseDirective } from './directives/input-restriction.directive';
import { TriggerSearchDirective } from './directives/trigger-search.directive';
import { NoDblClickDirective } from './directives/no-dbl-click.directive';
import { IrisAccordionDirective } from './directives/iris-accordion.directive';
import { AutofocusDirective } from './directives/autofocus.directive';
import { CustomSwitchKeypressDirective } from './directives/custom-switch-keypress.directive';
import { IrisCardsDirective } from './directives/iris-cards.directive';

/** Import: Shared Pipes */
import { FormatNumberPipe } from './pipe/format-number.pipe';
import { FilterPipe } from './pipe/filter.pipe';
import { FormatDateStringPipe } from './pipe/format-date-string.pipe';
import { OrderPipe } from './pipe/order.pipe';

/** Import: Services */
import { SumoLoggerService } from './services/sumo-logger.service';
import { MessageService } from './services/message.service';
import { ApiService } from './services/api.service';
import { IrisErrorsHandler } from './services/irisErrorshandler.service';
import { AlertService } from './services/alert.service';
import { UtilService } from './services/util.service';
import { StorageService } from './services/storage.service';
import { LeftSidebarService } from './services/left-sidebar.service';
import { LookupApiService } from './services/lookup-api.service';
import { RightSlidepanelService } from './services/right-slidepanel.service';
import { FakeBackendInterceptorService, FakeBackendProdInterceptorService } from './services/fake-backend-interceptor-service';
import { HttpInterceptorService } from './services/http-interceptor.service';
import { AuthService } from './services/auth.service';
import { AuthGuard } from './guards/auth.guard';
import { ConfirmationDialogService } from './services/confirmation-dialog.service';
import { UserPreferenceGuard } from './guards/user-preference.guard';
import { UserPreferenceService } from './services/user-preference.service';
import { environment } from '../../environments/environment';

/*** Shared Services */
const SERVICES = [
  SumoLoggerService,
  MessageService,
  AlertService,
  ApiService,
  {
    provide: ErrorHandler,
    useClass: IrisErrorsHandler
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: (environment.enableMocks) ? FakeBackendInterceptorService : FakeBackendProdInterceptorService,
    multi: true
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: HttpInterceptorService,
    multi: true
  },
  UtilService,
  StorageService,
  LeftSidebarService,
  LookupApiService,
  RightSlidepanelService,
  ConfirmationDialogService,
  AuthService,
  AuthGuard,
  UserPreferenceService,
  UserPreferenceGuard
];

/***Shared Directives */
const DIRECTIVES = [
  RemoveMultipleSpacesDirective,
  IrisAccordionDirective,
  InputRestrictionDirective,
  TriggerSearchDirective,
  ToUpperCaseDirective,
  NoDblClickDirective,
  AutofocusDirective,
  CustomSwitchKeypressDirective,
  IrisCardsDirective
];

/*** Shared components */
const COMPONENTS = [
  HeaderComponent,
  LeftNavigationComponent,
  FooterComponent,
  GridComponent,
  PaginationComponent,
  PaginationLimitComponent,
  LoadOverlayComponent,
  DropdownGridComponent,
  AlertComponent,
  MultiCheckboxTreeDropdownComponent,
  DatePickerComponent,
  DrSearchComponent,
  LeftSidebarComponent,
  AppliedFiltersComponent,
  ProjectSearchFormComponent,
  CompanyInfoFormComponent,
  AddressFormComponent,
  OtherProjectInfoComponent,
  CompanyPopupComponent,
  CompanyContactInfoFormComponent,
  GridActionButtonsComponent,
  PhoneMaskComponent,
  EfeedSearchFormComponent,
  FeedDispositionSearchFormComponent,
  PageTabNavigationComponent,
  ConfirmationDialogComponent,
  ContentTabNavigationComponent,
  ContentAccordionComponent,
  LeftSidebarLinksComponent,
  ContentCardsComponent
];

/** Shared Pipes */
const PIPES = [
  FormatNumberPipe,
  FilterPipe,
  FormatDateStringPipe,
  OrderPipe
];

/** Modules which need to be imported always as exported from this module */
const MODULES = [
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  RouterModule,
  HttpClientModule,
  NgbModule,
  NgxDatatableModule,
  TreeviewModule,
  TextMaskModule,
  NgxPageScrollModule
];

@NgModule({
  imports: [
    ...MODULES
  ],
  declarations: [
    ...COMPONENTS,
    ...DIRECTIVES,
    ...PIPES
  ],
  exports: [
    ...MODULES,
    ...COMPONENTS,
    ...DIRECTIVES,
    ...PIPES
  ],
  entryComponents: [ConfirmationDialogComponent]
})
export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: SERVICES
    };
  }
}
