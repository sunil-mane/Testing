import { MetaData } from './MetaData';

export interface StatesLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    states: Array<State>;
  };
}
export interface State {
  id: string;
  code: string;
  name: string;
}
