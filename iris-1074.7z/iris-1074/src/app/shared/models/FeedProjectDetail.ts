import { MetaData } from './MetaData';

export interface FeedProjectDetailsResponse {
  status: string;
  code: number;
  data: FeedProjectData;
}
export interface FeedProjectData {
  metaData: MetaData;
  project: FeedProjectDetails;
  biddingInformation: BiddingInformation;
  additionalInformation: AdditionalInformation;
  details: FeedProjectOtherDetails;
  contactdetails: ContactDetails;
  lastUpdatedOn: String;
}
export interface FeedProjectDetails {
  description: string;
  title: string;
  number: string;
  type: string;
  recordId: string;
  reportNumber: string;
  reportType: string;
  originalRegion: string;
  currentRegion: number;
  routedBy: string;
  valuation: string;
  contractNumber: string;
  deliverySystem: string;
  ownerType: string;
  stage: string;
  status: string;
  remarks: string;
  exception: string;
  contractAwardees: string;
  location: Location;
  date: Date;
}

export interface Location {
  address1: string;
  address2: string;
  address3: string;
  city: string;
  county: string;
  state: string;
  country: string;
  zip: string;
}
export interface Date {
  awardDate: string;
  advertise: string;
  submission: string;
  submissionTime: string;

}
export interface BiddingInformation {
  bid: Bid;
  preBid: PreBid;
  target: Target;
}

export class Bid {
  bidDate: string;
  bidTime: string;
  submitBidTo: string;
}

export interface PreBid {
  preBidMeeting: string;
  date: string;
  time: string;
}

export class Target {
  bidDate: string;
  startDate: string;
  completionDate: string;
}

export class AdditionalInformation {
  typeOfWork: string;
  additionalInfo1: string;
  additionalInfo2: string;
  additionalInfo3: string;
  additionalInfo4: string;
  bond: Bond;
}

export interface Bond {
  bid: string;
  performance: string;
  payment: number;
  remark: string;
}

export interface FeedProjectOtherDetails {
  noOfBuilding: string;
  noOfStoriesAboveGrade: string;
  noOfStoriesBelowGrade: string;
  totalSquareFeet: string;
  buildingFrame: string;
  storeNumber: string;
  url: Url;
  plan: Plan;
  category1: string;
  category2: string;
  category3: string;
}

export interface Url {
  pageUrl: string;
  otherUrl2: string;
  otherUrl3: string;
  otherUrl4: string;
}

export interface Plan {
  addenda: string;
  deposit: string;
  planReleaseDate: string;
  planAvailableFrom: string;
  planRemark: string;
}

export interface ContactDetails {
  name: string;
  address1: string;
  address2: string;
  address3: string;
  city: string;
  state: string;
  contact: string;
  phone: string;
  fax: string;
}

