import { MetaData } from './MetaData';

export interface ReporterLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    reporters: Array<Reporter>;
  };
}
export interface Reporter {
  id: string;
  description: string;
  managerId: string;
  user: string;
  type: string;
  region: number;
  isManager: string;
}

