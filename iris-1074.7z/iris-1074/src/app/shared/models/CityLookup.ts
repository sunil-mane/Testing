import { MetaData } from './MetaData';

export interface CityLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    states: Array<CityState>;
  };
}
export interface CityState {
  id: string;
  name: string;
  cities: Array<string>;
}
