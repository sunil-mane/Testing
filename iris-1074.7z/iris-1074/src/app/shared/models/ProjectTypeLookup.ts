import { MetaData } from './MetaData';

export interface ProjectTypeLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    types: Array<ProjectTypes>;
  };
}
export interface ProjectType {
  code: string;
  name: string;
}
export interface ProjectTypes {
  code: string;
  name: string;
  subtypes: Array<ProjectTypes>;
}
// export interface ProjectTypes {
//   code: string;
//   name: string;
//   subtypes: Array<ProjectType>;
// }
