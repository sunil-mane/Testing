export interface SelectedRows {
  selected: Array<any>;
}
