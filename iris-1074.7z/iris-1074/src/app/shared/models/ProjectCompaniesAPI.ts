import { MetaData } from './MetaData';

export interface ProjectCompaniesOutput {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    companies: Array<ProjectCompany>;
  };
}

export interface ProjectCompany {
  projectNumber?: number;
  version?: number;
  title?: string;
  titleCode?: string;
  contractRole?: string;
  bidderType?: string;
  bidderCode?: number;
  name?: string;
  contactName?: string;
  addressLine1?: string;
  addressLine2?: string;
  state?: string;
  city?: string;
  county?: string;
  phone?: string;
  fax?: string;
  email?: string;
  sortOrder?: number;
}
