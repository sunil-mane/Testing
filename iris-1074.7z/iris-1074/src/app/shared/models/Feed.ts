import { MetaData } from './MetaData';

export interface FeedLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    feeds: Array<Feed>;
  };
}
export interface Feed {
  id: string;
  name: string;
}

