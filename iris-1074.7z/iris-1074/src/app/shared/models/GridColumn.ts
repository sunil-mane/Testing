import { TemplateRef } from '@angular/core';

export interface GridColumn {
  name?: string;
  name2?: string;
  prop?: string;
  minWidth?: number;
  width?: number;
  cellClass?: string;
  draggable?: boolean;
  frozenLeft?: boolean;
  sortable?: boolean;
  levels?: number;
  levelHasUrl?: boolean;
  cellTemplate?: TemplateRef<any>;
  childTemplate?: TemplateRef<any>;
  type?: string;
  isVisible?: boolean;
  order?: number;
}
