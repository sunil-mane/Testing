export interface LeftNavLinks {
  label: string;
  url: any[] | string;
  icon: string[];
}
