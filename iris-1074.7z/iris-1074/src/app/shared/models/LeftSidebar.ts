export interface FilterDropdown {
  displayName: string;
  controlName: string;
  order?: number;
  active: boolean;
  children?: Array<FilterDropdownItems>;
}
export interface FilterDropdownItems {
  displayName: string;
  controlName: string;
  order?: number;
  active: boolean;
}

export interface ClearFormPayload {
  control: string;
  value: any;
}

export interface SearchPageConfig {
  apiPath: string;
  dataPath: string;
  totalPath: string;
  showHeaderSearch: boolean;
  showHeaderSearchDropdown: boolean;
  termPlaceholder?: string;
  searchStatus: SearchStatusConfig;
  hasPagination: boolean;
  hasSort: boolean;
}

export interface SearchStatusConfig {
  noData?: string;
  emptyCriteria?: string;
  zeroResults?: string;
  noIssueDate?: string;
}

export interface ErrorResponse {
  code: number;
  data: {
    errors: Array<ErrorResponseObject>;
  };
}

export interface ErrorResponseObject {
  code: string;
  message: string;
}

export interface LeftSidebarLinks {
  label: string;
  panelId: string;
}
