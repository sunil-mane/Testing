import { MetaData } from './MetaData';
import { ProjectSearchOutput, ProjectOutput } from './ProjectSearchAPI';
/**
 * Reroute Action Output
 */
export interface MarkFeedActionResponse {
  status: string;
  code: number;
  data: any;
}

export interface MarkFeedRequest {
  dispositionId: string;
  projects: number[];
  comment: string;
}
