export interface MetaData {
  count: number;
  start: number;
  total: number;
}
