export interface PageTabNavigation {
  label: string;
  route: any[];
}
