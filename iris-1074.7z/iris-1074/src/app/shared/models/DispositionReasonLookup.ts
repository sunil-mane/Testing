import { MetaData } from './MetaData';

export interface DispositionReasonLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    dispositions: Array<DispositionReason>;
  };
}
export interface DispositionReason {
  id: string;
  description: string;
}
