/**
 * Model for header find in dropdown
 */
export interface FindInDropdowns {
  label: string;
  value: string;
  active: boolean;
}
/**
 * Model for Payload of search and save search button events
 */
export interface SearchPayload {
  term: string;
  searchType: string;
  exactMatch: boolean;
}
