import { MetaData } from './MetaData';
import { ProjectSearchOutput, ProjectOutput } from './ProjectSearchAPI';
/**
 * Reroute Action Output
 */
export interface RerouteActionResponse {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    projects: Array<ProjectOutput>;
  };
}

export interface RerouteActionRequest {
  id: string;
  type: string;
  projects?: number[];
}
