import { MetaData } from './MetaData';

export interface CountyLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    states: Array<CountyState>;
  };
}
export interface County {
  id: string;
  name: string;
}
export interface CountyState {
  id: string;
  name: string;
  counties: Array<County>;
}
