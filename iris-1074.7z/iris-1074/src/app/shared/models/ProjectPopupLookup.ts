import { MetaData } from './MetaData';

export interface ProjectPopupLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    projects: Array<Project>;
  };
}
export interface Project {
  title: string;
  stage: string;
  projectNumber: string;
  valuation: number;
  bidDate: string;
  role: string;
  addressLine1: string;
  addressLine12: string;
  city: string;
  county: string;
  state: string;
  zipCode: string;
  lastIssueDate: string;
}
