export interface QueryTreeData {
  text: string;
  children?: QueryTreeData[];
}
