import { MetaData } from './MetaData';

export interface CompanyPopupLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    companies: Array<Company>;
  };
}
export interface Company {
  id: string;
  projectNumber: string;
  version: string;
  title: string;
  titleCode: string;
  contractRole: string;
  bidderType: string;
  bidderCode: string;
  name: string;
  contactName: string;
  addressLine1: string;
  addressLine2: string;
  state: string;
  city: string;
  county: string;
  phone: string;
  fax: string;
  email: string;
  sortOrder: string;
  website: string;
}
