export interface ApiParams {
  [param: string]: string | string[];
}

export interface ApiHttpOptions {
  headers?: ApiParams;
  params?: ApiParams;
  observe?: any; // 'body' | 'response' | 'events';
  reportProgress?: boolean;
  responseType?: any; // 'arraybuffer' | 'blob' | 'json' | 'text';
  withCredentials?: boolean;
}
