export interface CustomerCare {
  text: string;
  url: string;
  tel: string;
}

export interface FooterLinks {
  label: string;
  url: string;
  target: string;
}
