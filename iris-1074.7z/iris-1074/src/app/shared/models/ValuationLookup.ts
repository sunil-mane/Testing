import { MetaData } from './MetaData';

export interface ValuationLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    valuations: Array<Valuation>;
  };
}
export interface Valuation {
  id: string;
  low: number;
  high: number;
}
