import { MetaData } from './MetaData';

export interface RegionLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    regions: Array<Region>;
  };
}
export interface Region {
  id: string;
  name: string;
}

