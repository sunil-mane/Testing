import { MetaData } from './MetaData';

/**
 * project/search Input
 */
export interface ProjectSearchInput {
  term?: string;
  exactMatch?: boolean;
  searchType?: string;
  project?: {
    title?: ProjectInputTermExactMatch;
    contractNumber?: string;
    keyword?: ProjectInputTermExactMatch;
    bid?: {
      dateRange?: ProjectInputDateRange;
      dateCodes?: Array<string>;
    };
    valuation?: {
      range?: {
        min?: number;
        max?: number;
      };
    };
    issue?: {
      dateRange?: ProjectInputDateRange;
    };
    location?: ProjectInputLocation;
    stages?: Array<string>;
    types?: Array<string>;
  };
  company?: {
    name?: string;
    code?: string;
    keyword?: ProjectInputTermExactMatch;
    phone?: string;
    type?: string;
    contact?: ProjectInputNameCode;
    email?: string;
    location?: ProjectInputLocation;
  };
  pagination?: ProjectInputPagination;
  sort?: ProjectInputSort;
}

/**
 * Project Search Output
 */
export interface ProjectSearchOutput {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    projects: Array<ProjectOutput>;
  };
}

/**
 * Interface Partials
 */
export interface ProjectInputLocation {
  address?: string;
  zip?: string;
  countries?: ProjectInputLocationCode;
  states?: ProjectInputLocationCode;
  counties?: ProjectInputLocationCode;
  cities?: ProjectInputLocationCode;
}

export interface ProjectInputLocationCode {
  codes?: Array<string>;
}

export interface ProjectInputSort {
  order?: string;
  by?: string;
}

export interface ProjectInputPagination {
  limit?: number;
  offset?: number;
}

export interface ProjectInputTermExactMatch {
  term?: string;
  exactMatch?: boolean;
}

export interface ProjectInputNameCode {
  name?: string;
  code?: string;
}

export interface ProjectInputDateRange {
  start?: string;
  end?: string;
}

export interface ProjectOutput {
  bidDate?: string;
  city?: string;
  id?: number;
  name?: string;
  issuedDate?: string;
  stage?: string;
  state?: string;
  street?: string;
  type?: string;
  valuation?: ProjectOutputValuation;
  ownerName?: string;
  architectName?: string;
  gcName?: string;
  version?: number;
}

export interface ProjectOutputValuation {
  high?: number;
  low?: number;
}
