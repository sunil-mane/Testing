import { MetaData } from './MetaData';

export interface CompanyTypeLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    companyTypes: Array<Company>;
  };
}
export interface Company {
  id: string;
  type: string;
  code: string;
}
