import { MetaData } from './MetaData';

export interface CountryLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    countries: Array<Country>;
  };
}
export interface Country {
  id: string;
  name: string;
}
