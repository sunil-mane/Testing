import { MetaData } from './MetaData';

export interface ProjectStageLookup {
  status: string;
  code: number;
  data: {
    metaData: MetaData;
    stages: Array<Stages>;
  };
}
export interface Stage {
  id: string;
  name: string;
}
export interface Stages {
  id: string;
  name: string;
  stage: Array<Stage>;
}
