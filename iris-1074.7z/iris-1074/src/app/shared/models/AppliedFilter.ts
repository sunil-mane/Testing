export interface AppliedFilter {
  name?: string;
  value?: string | number;
  control?: string;
  showRemoveFilter?: boolean;
  order?: number;
}
export interface AppliedFilterHelper {
  getFilters(data: any): Array<AppliedFilter>;
  removeFilter(control: string, value: string): void;
  getValue(data: any, template: AppliedFilter): any;
  getFilterObject(controlValue: any, template: AppliedFilter): any;
}
