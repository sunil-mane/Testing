import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

/**
 * Pagination Limit Component
 *
 * Allows selection of the amount of results to show per page.
 *
 */

@Component({
  selector: 'app-pagination-limit',
  templateUrl: './pagination-limit.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaginationLimitComponent {


  /**
   * Total number of paginated records.
   */
  @Input() total: number;

  /**
   * Current beginning number for paginated records.
   */
  @Input() offset: number;

  /**
   * Number of records to show per page.
   */
  @Input() limit: number;

  /**
   * Limit change event emitter.
   */
  @Output() limitChange = new EventEmitter<number>();

  /**
   * Get last item of current page
   */
  get last(): number {
    const last = this.offset + this.limit;

    return last > this.total ? this.total : last;
  }

  getCurrentLimit() {
    return this.limit;
  }

  /**
   * Change limit
   */
  changeLimit() {
    this.limitChange.emit(this.getCurrentLimit());
  }
}
