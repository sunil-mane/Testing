import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core/src/debug/debug_node';
import { PaginationLimitComponent } from './pagination-limit.component';
import { SharedModule } from '../../shared.module';

describe('PaginationLimitComponent', () => {
  let component: PaginationLimitComponent;
  let fixture: ComponentFixture<PaginationLimitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SharedModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginationLimitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /**
   * Pagination limiter on first page
   */
  describe('On indicator', () => {

    beforeEach(setup(1000, 100, 0));

    it('should display total number of records', () => {
      expect(fixture.debugElement.nativeElement.textContent).toContain('1,000');
    });

    it('should display current pagination range', () => {
      expect(fixture.debugElement.nativeElement.textContent).toContain('1 – 100');
    });
  });

  /**
   * Pagination limiter on page after first
   */
  describe('On subsequent pages', () => {

    beforeEach(setup(1000, 100, 100));

    it('should display correct pagination range', () => {
      expect(fixture.debugElement.nativeElement.textContent).toContain('101 – 200');
    });
  });

  /**
   * Pagination limiter on last page
   */
  describe('On last page', () => {

    beforeEach(setup(1050, 100, 1000));

    it('should show total instead of calculation on partial last set', () => {
      expect(fixture.debugElement.nativeElement.textContent).toContain('1,001 – 1,050');
    });
  });


  // Private functions

  /**
   * Setup component with set properties
   *
   * @param total Total number of records
   * @param limit Page size
   * @param offset Record offset
   */
  function setup(total: number, limit: number, offset: number) {
    return () => {
      fixture = TestBed.createComponent(PaginationLimitComponent);
      component = fixture.componentInstance;

      // Manual input binding
      component.total = total;
      component.limit = limit;
      component.offset = offset;

      fixture.detectChanges();
    };
  }
});
