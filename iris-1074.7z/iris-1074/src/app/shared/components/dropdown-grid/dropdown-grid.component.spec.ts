import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, ViewChild } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DropdownGridComponent } from './dropdown-grid.component';
import { SharedModule } from '../../shared.module';
import { BaseFormGroup } from '../../forms/base-form-group';
import { BaseFormControl } from '../../forms/base-form-control';
import { GridColumn } from '../../models/GridColumn';
import { Country } from '../../models/CountryLookup';
import { State } from '../../models/StatesLookup';
import { Lookups } from '../../../../mocks/lookups';

@Component({
  template: `<form id="test-form" novalidate [formGroup]="locationFormGroup">
    <app-dropdown-grid formControlName="countries" [placeholder]="placeholderText" [gridColumns]="countryColumns"
    [gridData]="countries" [isMultiSelect]="isMultiSelectEnabled" [showCheckbox]="false" [labelProperty]="'name'"
    [valueProperty]="valueProperty" [signleSelectValueAsArray]="signleSelectValueAsArray"></app-dropdown-grid>
  </form>`
})
class TestComponent {
  /** Countries Form Group */
  locationFormGroup: BaseFormGroup;

  /** Countries Grid column configuration */
  countryColumns: GridColumn[];

  /** Countries Data */
  countries: Country[];

  /** Placeholder Text */
  placeholderText: string;

  /** Value Property Name */
  valueProperty: string;

  /** Multiselect Flag */
  isMultiSelectEnabled: boolean;

  /** signleSelectValueAsArray flag */
  signleSelectValueAsArray: boolean;

  @ViewChild(DropdownGridComponent) dropdown: DropdownGridComponent;

  constructor() {
    // Country dropdown config
    this.countryColumns = [
      { name: 'Country Name', prop: 'name' }
    ];

    // Location Form
    this.locationFormGroup = new BaseFormGroup('locationForm', {
      countries: new BaseFormControl('Countries', 'countries', 'select', '', null, []),
      states: new BaseFormControl('States', 'states', 'select', '', null, [])
    });

    // Countries data
    this.countries = Lookups.getCountry().data.countries;

    // Set value property
    this.valueProperty = 'id';
  }
}

describe('DropdownGridComponent', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let dropdown: DropdownGridComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule],
      declarations: [TestComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    dropdown = component.dropdown;
  });

  it('should create', async(() => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  }));

  it('should call "setDisabledState" when control disabled', async(() => {
    fixture.detectChanges();
    spyOn(dropdown, 'setDisabledState').and.callThrough();
    component.locationFormGroup.get('countries').disable();
    component.locationFormGroup.get('countries').enable();
    expect(dropdown.setDisabledState).toHaveBeenCalledTimes(2);
  }));

  it('should enable multi select', async(() => {
    component.isMultiSelectEnabled = true;
    fixture.detectChanges();
    expect(dropdown.selectionType).toBe('multiClick');
  }));

  it('should disabled multi select', async(() => {
    component.isMultiSelectEnabled = false;
    fixture.detectChanges();
    expect(dropdown.selectionType).toBe('single');
  }));

  it('should have initial label equal to placeholder', async(() => {
    component.placeholderText = 'Country';
    fixture.detectChanges();
    expect(dropdown.label).toBe('Country');
  }));

  it('should have zero selected rows when value is empty', async(() => {
    component.locationFormGroup.get('countries').setValue([]);
    component.countries = [];
    fixture.detectChanges();
    expect(dropdown.selectedRows.length).toBe(0);
  }));

  it('should have zero selected rows when valueProperty is empty', async(() => {
    component.valueProperty = null;
    fixture.detectChanges();
    expect(dropdown.selectedRows.length).toBe(0);
  }));

  it('should have value is selected row when control value as array matches grid data', async(() => {
    component.signleSelectValueAsArray = true;
    component.locationFormGroup.get('countries').setValue(['USA']);
    fixture.detectChanges();
    expect(dropdown.selectedRows.length).toBe(1);
  }));

  it('should have value is selected row when control value as string matches grid data', async(() => {
    component.signleSelectValueAsArray = false;
    component.locationFormGroup.get('countries').setValue('USA');
    fixture.detectChanges();
    expect(dropdown.selectedRows.length).toBe(1);
  }));

  it('should have count in label', async(() => {
    component.isMultiSelectEnabled = true;
    component.signleSelectValueAsArray = true;
    component.placeholderText = 'Country';
    component.locationFormGroup.get('countries').setValue(['USA', 'CAN']);
    fixture.detectChanges();
    expect(dropdown.label).toBe('Country (2)');
  }));

  it('should not return value if valueProperty is not property of row', async(() => {
    component.valueProperty = null;
    component.signleSelectValueAsArray = true;
    component.locationFormGroup.get('countries').setValue(['USA']);
    fixture.detectChanges();
    expect(dropdown.getValues(dropdown.selectedRows).length).toBe(0);
  }));
});
