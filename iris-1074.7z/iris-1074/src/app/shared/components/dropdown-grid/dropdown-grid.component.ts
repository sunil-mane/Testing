import { Component, OnChanges, Input, SimpleChanges, forwardRef, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { Renderer2, ViewEncapsulation, ChangeDetectionStrategy } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { TableColumn, } from '@swimlane/ngx-datatable';
import { NgbDropdownConfig, NgbDropdown } from '@ng-bootstrap/ng-bootstrap';
import { PlacementArray } from '@ng-bootstrap/ng-bootstrap/util/positioning';
import { isEmpty, findIndex, cloneDeep, isNil, isNumber, get } from 'lodash';
import { SelectedRows } from '../../models/DropdownGrid';

/**
 * This component shows data grid in dropdown. It uses ngx-datatable as grid component
 */
@Component({
  selector: 'app-dropdown-grid',
  templateUrl: './dropdown-grid.component.html',
  styleUrls: ['./dropdown-grid.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.Default,
  providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => DropdownGridComponent), multi: true }, NgbDropdownConfig]
})
export class DropdownGridComponent implements ControlValueAccessor, OnChanges, AfterViewInit {
  /** Columns for ngx-datatable. Column array being build from @Input gridColumns */
  columns: Array<TableColumn>;

  /** selected rows of ngx-datatable are store in this property */
  selectedRows: Array<object>;

  /** Selected item display property */
  label: string;

  /** Disables the dropdown */
  disabled: boolean;

  /** Bind selection type of ngx-datatable */
  selectionType: string;

  /** Flag for dropdown open state */
  isOpen: boolean;

  /** Grid rows */
  gridRows: Array<object>;

  /** Filter properties */
  filterProperties: string[];

  /** Placeholder text */
  @Input() placeholder: string;

  /** Grid columns */
  @Input() gridColumns: Array<TableColumn>;

  /** Data for the grid */
  @Input() gridData: Array<object>;

  /** Booleon property to enable/disable multiple rows selectinility */
  @Input() isMultiSelect: boolean;

  /** If Single select then whether to wrap value in array */
  @Input() signleSelectValueAsArray: boolean;

  /** Boolean property to show/hide checkboxes on first column of data grid */
  @Input() showCheckbox: boolean;

  /** Proerty name of gridData object whose value will be used as label */
  @Input() labelProperty: string;

  /** Placement of the dropdown */
  @Input() placement: PlacementArray;

  /** Dropdown width */
  @Input() dropDownWidth: number;

  /** Property name of gridData object whose value will be passed as array of form value */
  @Input() valueProperty: string;

  /** Property name of gridData object which will be used for filtering */
  @Input() enableFilter: boolean;

  /** Set default value */
  @Input() defaultValue: any;

  /** Get current instance of NgbDropdown */
  @ViewChild(NgbDropdown) private dropdown: NgbDropdown;

  /** Current Value */
  private values: any;

  /**
   * Constructor propery
   * @param {ElementRef} elementRef Element reference of component
   * @param {Renderer2} renderer Renderer2 class
   * @param {NgbDropdownConfig} dropdownConfig NgbDropdownConfig service
   */
  constructor(private elementRef: ElementRef, private renderer: Renderer2, private dropdownConfig: NgbDropdownConfig) {
    // Enable dropdown by default
    this.disabled = false;

    // Initialiaze selectedRows with empty array
    this.selectedRows = [];

    // Set autoClose to 'outside' so that dropdown doesn't close on selecting any item
    this.dropdownConfig.autoClose = 'outside';

    // Set to false
    this.isOpen = false;

    // Set Value as Array to tru
    this.signleSelectValueAsArray = true;

    // Deafult dropdown placemnt
    this.placement = 'bottom-left';

    // Initiatize with empty array
    this.gridRows = [];

    // Set default value to true
    this.enableFilter = true;
  }

  /**
   * onChange method for ControlValueAccessor
   */
  onChange = (rows: any) => { };

  /**
   * onTouched method for ControlValueAccessor
   */
  onTouched = () => { };

  /**
   * WriteValue method for ControlValueAccessor
   * @param {any} rows selected rows
   */
  writeValue(rows: any): void {
    if (!isEmpty(rows)) {
      this.values = rows;
    }
    if (!isEmpty(this.gridData)) {
      if (this.valueProperty) {
        if (isNumber(rows) || !isEmpty(rows)) {
          this.selectedRows = this.gridData.filter(data => (this.isMultiSelect || this.signleSelectValueAsArray) ?
            rows.includes(data[this.valueProperty]) : rows === data[this.valueProperty]);
        } else {
          this.selectedRows = [];
        }
      }
    } else {
      this.selectedRows = [];
    }
    const value = this.getValues(this.selectedRows);
    this.onChange(value);
    this.onTouched();
    this.displayLabel(this.selectedRows);
  }

  /**
   * registerOnChange method for  ControlValueAccessor
   */
  registerOnChange(fn: (rows: Array<object>) => void): void {
    this.onChange = fn;
  }

  /**
   * registerOnTouched method for  ControlValueAccessor
   */
  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  /**
   * setDisabledState method for  ControlValueAccessor
   */
  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  /**
   * Method to handle select event of ngx-datatable.
   * @param selectedItems selected rows
   */
  onSelect(selectedItems: SelectedRows) {
    if (!this.disabled) {
      const value = this.getValues(selectedItems.selected);
      this.onChange(value);
      this.onTouched();
      this.displayLabel(selectedItems.selected);
    }
  }

  /**
   * NgOnChanges hook
   */
  ngOnChanges(changes: SimpleChanges) {
    // Set column configuration on change of 'showCheckbox', 'gridColumns' and 'gridData' @Input values
    if (changes['showCheckbox'] || changes['gridColumns'] || changes['gridData']) {
      this.setColumnConfig();
      if (!isEmpty(this.values) && isNil(changes['gridData'].previousValue)) {
        this.writeValue(this.values);
      }

      if (!isEmpty(changes['gridData'])) {
        if (!isEmpty(changes['gridData'].previousValue) && isEmpty(changes['gridData'].currentValue)) {
          this.selectedRows = [];
          this.writeValue([]);
        }
      }

      this.gridRows = (this.gridData) ? [...this.gridData] : [];
    }

    if (changes['defaultValue']) {
      this.writeValue(this.defaultValue);
    }

    // Enable multiple selectable rows
    if (changes['isMultiSelect']) {
      this.enableMultiSelect();
    }

    // Assign placeholder text
    if (changes['placeholder']) {
      this.label = (isNil(this.placeholder)) ? '' : this.placeholder;
    }
  }

  /**
   * AfterViewInit Event
   */
  ngAfterViewInit() {
    // Bind to click event to close the dropdown when dropdown is Single Select
    this.elementRef.nativeElement.querySelector('.dropdown-grid')
      .addEventListener('click', this.closeOnClickIfSingleSelect.bind(this));
    this.elementRef.nativeElement.querySelector('.dropdown-grid')
      .addEventListener('keydown', this.closeOnTab.bind(this));
  }

  /**
   * Handle click event to close the dropdown when dropdown is Single Select
   */
  closeOnClickIfSingleSelect(event: MouseEvent) {
    const target = <HTMLElement>event.target;
    const parentClassName = target.parentElement.className;
    if (parentClassName.includes('datatable-body-cell-label') || parentClassName.includes('datatable-row-group') ||
      parentClassName.includes('datatable-body-cell')) {
      if (!this.isMultiSelect) {
        this.dropdown.close();
      }
    }
  }

  /**
   * Handles keydown event and closes dropdown on tab
   * @param event event object
   */
  closeOnTab(event: KeyboardEvent) {
    if (event.keyCode === 9) {
      this.dropdown.close();
    }
  }

  /**
   * Bind to dropdown openChange event
   */
  openChange(status) {
    this.isOpen = status;
    if (status) {
      const checkboxEnabledColumns = cloneDeep(this.columns);
      this.columns = this.getColumnsWithWidth(checkboxEnabledColumns);
      this.gridRows = (this.gridData) ? [...this.gridData] : [];
    }
  }

  /** Get width and max-width */
  get dropdownStyle(): any {
    if (this.dropDownWidth) {
      return {
        width: this.dropDownWidth + 'px'
      };
    } else {
      return {
        width: '100%',
        maxWidth: '100%'
      };
    }
  }

  /**
   * Filter values from the grid
   */
  updateFilter(event: KeyboardEvent) {
    const filterInput: HTMLInputElement = <HTMLInputElement>event.target;
    const value = filterInput.value.toLowerCase();

    const filteredData = this.gridData.filter((row) => {
      return this.filterProperties.filter(filterProperty => (isNil(row[filterProperty]) || isEmpty(row[filterProperty])) ? false :
        (row[filterProperty] as string).toLowerCase().startsWith(value)).length > 0;
    });

    this.gridRows = filteredData;
  }

  /**
   * Get values for the ControlValueAccessor
   * @param {any} rows select rows
   */
  getValues(rows: any): any {
    const values = [];
    if (!isEmpty(rows)) {
      rows.forEach((val) => {
        if (val[this.valueProperty]) {
          values.push(val[this.valueProperty]);
        }
      });
    }
    return (this.isMultiSelect || this.signleSelectValueAsArray) ? values : (isEmpty(values)) ? '' : values[0];
  }

  extractFilterProperties(gridColumns: Array<TableColumn>): string[] {
    if (isNil(gridColumns) || isEmpty(gridColumns)) {
      return [];
    } else {
      const filterProperties = [];
      gridColumns.forEach(gridColumn => {
        const prop = get(gridColumn, 'prop');
        if (!isNil(prop)) {
          filterProperties.push(prop);
        }
      });

      return filterProperties;
    }
  }

  /**
   * Based of value of isMultiSelect @Input assign appropriate selectionType to ngx-datatable
   */
  private enableMultiSelect() {
    const selectionType = (this.isMultiSelect) ? 'multiClick' : 'single';
    this.selectionType = selectionType.split('').join('');
  }

  /**
   * Set proper column configations
   */
  private setColumnConfig() {
    this.filterProperties = this.extractFilterProperties(this.gridColumns);
    const gridColumns = cloneDeep(this.gridColumns);
    const checkboxEnabledColumns = this.getCheckboxEnabledColumns(gridColumns);
    this.columns = this.getColumnsWithWidth(checkboxEnabledColumns);
  }

  /**
   * Based on showCheckbox @Input value mododifies the columns to enable/disable checkbox
   */
  private getCheckboxEnabledColumns(columns: Array<TableColumn>): Array<TableColumn> {
    if (!isEmpty(this.gridColumns) && this.showCheckbox !== undefined) {
      const checkboxableObjectIndex = findIndex(columns, (val) => {
        if (val.checkboxable !== undefined) {
          return val.checkboxable;
        }
        return false;
      });
      if (this.showCheckbox && checkboxableObjectIndex < 0) {
        const checkboxableColumn = { name: '', checkboxable: true, width: 25 };
        columns.unshift(checkboxableColumn);
      } else if (!this.showCheckbox && checkboxableObjectIndex > -1) {
        columns.splice(checkboxableObjectIndex, 1);
      }
    }
    return columns;
  }

  /**
   * Determine the maximum width of each column data and assign the calculate width to column config.
   * @param {Array<TableColumn>} columns coumns configuation
   */
  private getColumnsWithWidth(columns: Array<TableColumn>): Array<TableColumn> {
    if (!isEmpty(this.gridData) && !isEmpty(columns)) {
      columns.forEach((val, idx) => {
        const headerText = val.name;
        if (val.prop) {
          const longestTextObj: {} = this.gridData.reduce((a, b) => String(a[val.prop]).length > String(b[val.prop]).length ? a : b);
          if (String(longestTextObj[val.prop]).length > String(headerText).length) {
            columns[idx].width = this.calculcateTextWidth(longestTextObj[val.prop], false);
          } else {
            columns[idx].width = this.calculcateTextWidth(headerText, true);
          }
        }
      });
    }
    return columns;
  }

  /**
   * Calcualte the width by creating a DOM element and removing it after getting width.
   * @param {string} text text whose width to be calculated
   */
  private calculcateTextWidth(text: string, isHeader: boolean): number {
    const testDiv = <HTMLDivElement>this.renderer.createElement('div');
    const body = this.elementRef.nativeElement;
    this.renderer.addClass(testDiv, 'test-width');
    if (isHeader) {
      this.renderer.addClass(testDiv, 'for-col-header');
    } else {
      this.renderer.addClass(testDiv, 'for-col-body');
    }
    testDiv.innerHTML = text;
    this.renderer.appendChild(body, testDiv);
    const textWidth = testDiv.clientWidth;
    this.renderer.removeChild(body, testDiv);
    return textWidth;
  }

  /**
   * Display dropdown selected item
   * @param {Array<object>} rows select rows
   */
  private displayLabel(rows: Array<object>) {
    if (rows.length === 1) {
      this.label = rows[0][this.labelProperty];
    } else if (rows.length > 1) {
      this.label = `${this.placeholder} (${rows.length})`;
    } else {
      this.label = this.placeholder;
    }
  }


}
