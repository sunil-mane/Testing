import { Component, OnInit, OnDestroy, Input, Renderer2 } from '@angular/core';
import { PageTabNavigation } from '../../models/PageTabNavigation';

@Component({
  selector: 'app-page-tab-navigation',
  templateUrl: './page-tab-navigation.component.html',
  styleUrls: ['./page-tab-navigation.component.scss']
})
export class PageTabNavigationComponent implements OnInit, OnDestroy {

  @Input() tabs: PageTabNavigation[];

  private bodyElement: HTMLBodyElement;

  constructor(private renderer: Renderer2) {
    this.bodyElement = document.getElementsByTagName('body')[0];
  }

  ngOnInit() {
    if (!this.bodyElement.classList.contains('page-tab-navigation')) {
      this.renderer.addClass(this.bodyElement, 'page-tab-navigation');
    }
  }

  ngOnDestroy() {
    if (this.bodyElement.classList.contains('page-tab-navigation')) {
      this.renderer.removeClass(this.bodyElement, 'page-tab-navigation');
    }
  }
}
