import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { FooterComponent } from './footer.component';
import { CustomerCare, FooterLinks } from '../../models/Footer';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;
  let element: DebugElement;
  let elements: DebugElement[];
  let customerCare: CustomerCare;
  let footerLinks: Array<FooterLinks>;
  let version: string;
  let dom: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FooterComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;

    customerCare = {
      text: 'Customer Care',
      url: 'https://www.construction.com/help/dodgenetwork/',
      tel: '1.800.393.6343'
    };
    version = '0.1.0.181361829';
    footerLinks = [
      { label: 'Terms of Use', url: 'https://www.construction.com/terms-of-use', target: '_blank' },
      { label: 'Privacy Policy', url: 'https://www.construction.com/privacy-policy', target: '_blank' },
      { label: 'About Us', url: 'https://www.construction.com/company', target: '_blank' }
    ];
  }));

  it('should create', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should have version text', async(() => {
    component.version = version;
    fixture.detectChanges();

    element = fixture.debugElement.query(By.css('span.copyright-text'));
    dom = element.nativeElement;

    expect(component.version).toBe(version);
    expect(dom.textContent.includes(version)).toBeTruthy();
  }));

  it('should not have version text', async(() => {
    component.version = undefined;
    fixture.detectChanges();

    element = fixture.debugElement.query(By.css('span.copyright-text'));
    dom = element.nativeElement;

    expect(component.version).toBeUndefined();
    expect(dom.textContent.includes(version)).toBeFalsy();
  }));

  it('should have customer care text and url', async(() => {
    component.customerCare = customerCare;
    fixture.detectChanges();

    element = fixture.debugElement.query(By.css('span.customer-care-label > a'));
    dom = element.nativeElement;

    expect(component.customerCare).toBe(customerCare);
    expect(dom.textContent.includes(customerCare.text)).toBeTruthy();
    expect(dom.getAttribute('href')).toBe(customerCare.url);
  }));

  it('should have customer care number', async(() => {
    component.customerCare = customerCare;
    fixture.detectChanges();

    element = fixture.debugElement.query(By.css('span.customer-care-number'));
    dom = element.nativeElement;

    expect(component.customerCare).toBe(customerCare);
    expect(dom.textContent).toBe(customerCare.tel);
  }));

  it('should have three footer links', async(() => {
    component.footerLinks = footerLinks;
    fixture.detectChanges();

    elements = fixture.debugElement.queryAll(By.css('div.links > a'));

    expect(component.footerLinks).toBe(footerLinks);
    expect(elements.length).toEqual(3);
  }));

  it('should have text and url for each footer link', async(() => {
    component.footerLinks = footerLinks;
    fixture.detectChanges();

    elements = fixture.debugElement.queryAll(By.css('div.links > a'));

    elements.forEach((val, idx) => {
      dom = val.nativeElement;
      expect(dom.textContent).toBe(footerLinks[idx].label);
      expect(dom.getAttribute('href')).toBe(footerLinks[idx].url);
    });

    expect(component.footerLinks).toBe(footerLinks);
  }));
});
