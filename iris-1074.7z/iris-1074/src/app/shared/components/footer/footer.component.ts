import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { CustomerCare, FooterLinks } from '../../models/Footer';

/**
 * Footer Component
 * This component takes three inputs. If any of input not provided then that portion will not render
 */

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FooterComponent {

  /**
   * Cutomer care object
   */
  @Input() customerCare: CustomerCare;

  /**
   * Footer link array
   */
  @Input() footerLinks: Array<FooterLinks>;

  /**
   * Application version
   */
  @Input() version: string;

  /**
   * Construction
   */
  constructor() {

    // Default customer care value
    this.customerCare = {
      text: 'Customer Care',
      url: 'https://www.construction.com/help/dodgenetwork/',
      tel: '1.800.393.6343'
    };

    // Default version
    this.version = '0.1.0.181361829';

    // Default footer links
    this.footerLinks = [
      { label: 'Terms of Use', url: 'https://www.construction.com/terms-of-use', target: '_blank' },
      { label: 'Privacy Policy', url: 'https://www.construction.com/privacy-policy', target: '_blank' },
      { label: 'About Us', url: 'https://www.construction.com/company', target: '_blank' }
    ];
  }
}
