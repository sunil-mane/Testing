import { LookupApiService } from '../../services/lookup-api.service';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { AppliedFilter, AppliedFilterHelper } from '../../models/AppliedFilter';
import { isEmpty, isNumber, orderBy, get } from 'lodash';
import * as moment from 'moment';
import * as appliedFilter from '../../config/applied-filters-feed-content.json';

export class FeedContentFiltersHelper implements AppliedFilterHelper {
  /** Lookup API Service Instance */
  lookupApiService: LookupApiService;
  /** Left Sidebar Service */
  leftSidebarService: LeftSidebarService;
  /** Date Format */
  dateFormat: string;
  /** Api Date Format */
  apiDateFormat: string;
  /** Applied filter template */
  appliedFilterTemplate: Array<AppliedFilter>;

  constructor(lookupApiService: LookupApiService, leftSidebarService: LeftSidebarService, dateFormat: string, apiDateFormat: string) {
    // Lookup api service intstance
    this.lookupApiService = lookupApiService;
    // Left sidebar service intstance
    this.leftSidebarService = leftSidebarService;
    // Date format
    this.dateFormat = dateFormat;
    // Api Date format
    this.apiDateFormat = apiDateFormat;
    // Applied filter template
    this.appliedFilterTemplate = (<any>appliedFilter).filters;
  }
  /**
   * Project search applied filter array.
   * @returns Array<AppliedFilter> array of AppliedFilter
   */
  getFilters(data: any): Array<AppliedFilter> {
    const appliedFilters: Array<AppliedFilter> = [];
    this.appliedFilterTemplate.forEach((tpl) => {
      const controlValue = this.getValue(data, tpl);
      if (isNumber(controlValue) || !isEmpty(controlValue)) {
        if (tpl.control === 'source') {
          const sourceType = get(data, 'sourceType');
          if (sourceType === 'REGION' || sourceType === 'REPORTER') {
            appliedFilters.push({
              name: (sourceType === 'REGION') ? 'Geography' : 'Rerouted',
              value: controlValue,
              control: 'source',
              showRemoveFilter: true,
              order: 1
            });
          }
        } else {
          appliedFilters.push(this.getFilterObject(controlValue, tpl));
        }
      }
    });
    return orderBy(appliedFilters, ['order'], ['asc']);
  }

  /**
   * Bind to remove filter button of applied filter component
   * @param {string} control Control name from appliedFilterTemplates
   * @param value
   */
  removeFilter(control: string, value?: string) {
    if (control.includes('-')) {
      const controls = control.split('-');
      controls.forEach((val) => {
        this.leftSidebarService.triggerClearForm(val);
      });
    } else {
      this.leftSidebarService.triggerClearForm(control);
    }
  }

  /**
   * Get applied filter value
   * @param data main form value
   * @param template applied filter template
   * @returns {any} string or array
   */
  getValue(data: any, template: AppliedFilter): any {
    if (template.control.includes('-')) {
      const controls = template.control.split('-');
      const values = [];
      controls.forEach((control) => {
        const value = get(data, control);
        if (!isEmpty(value)) {
          if (control.includes('dateRange')) {
            if (moment(value, this.apiDateFormat, true).isValid()) {
              const formatedDate = moment(value).format(this.dateFormat);
              values.push(formatedDate);
            }
          }
        }
      });
      return (values.length === controls.length) ? values.join(' to ') : values[0];
    } else {
      const value = get(data, template.control);
      if (template.control === 'location.countries.codes') {
        if (!isEmpty(value)) {
          const countryName = [];
          value.forEach((val) => { countryName.push(this.lookupApiService.getCountryNameById(val)); });
          return countryName;
        }
      } else if (template.control === 'location.states.codes') {
        if (!isEmpty(value)) {
          const stateName = [];
          value.forEach((val) => { stateName.push(this.lookupApiService.getStatesNameById(val)); });
          return stateName;
        }
      } else if (template.control === 'location.counties.codes') {
        if (!isEmpty(value)) {
          const countyName = [];
          value.forEach((val) => { countyName.push(this.lookupApiService.getCountyNameById(val)); });
          return countyName;
        }
      } else if (template.control === 'feedId' && !isEmpty(value)) {
        return this.lookupApiService.getFeedNameById(value);
      } else if (template.control === 'source' && get(data, 'sourceType') === 'REGION') {
        return this.lookupApiService.getRegionNameById(value);
      } else {
        return (isEmpty(value)) ? null : value;
      }
    }
  }

  /**
   * Get applied filter object
   * @param {any} controlValue the value
   * @param {any} template control template
   * @returns {any} string or array
   */
  getFilterObject(controlValue: any, template: AppliedFilter): any {
    return {
      value: controlValue,
      control: template.control,
      name: template.name,
      showRemoveFilter: template.showRemoveFilter,
      order: template.order
    };
  }
}
