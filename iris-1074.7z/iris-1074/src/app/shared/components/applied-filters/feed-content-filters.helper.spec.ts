import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, Injectable } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FeedContentFiltersHelper } from './feed-content-filters.helper';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { AppliedFilter, AppliedFilterHelper } from '../../models/AppliedFilter';
import { SharedModule } from '../../shared.module';
import { environment } from '../../../../environments/environment';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';
import * as appliedFilter from '../../config/applied-filters-feed-content.json';
import * as feedContentFormData from '../../../../mocks/feedContentFormData.json';


@Injectable()
export class FakeLookupApiService {
  constructor() { }

  getRegionNameById(id: string): string {
    return id;
  }
  getFeedNameById(name: string): string {
    return name;
  }
  getCountryNameById(id: string): string {
    return id;
  }
  getStatesNameById(id: string): string {
    return id;
  }
  getCountyNameById(id: string): string {
    return id;
  }
}


@Component({
  selector: 'app-test',
  template: '<h1>Feed Content Filters Helper</h1>'
})
class TestComponent {
  /** Helper */
  helper: AppliedFilterHelper;

  constructor(public leftSidebarService: LeftSidebarService, private lookupApiService: LookupApiService) {
    this.helper = new FeedContentFiltersHelper(this.lookupApiService, this.leftSidebarService,
      environment.defaultDateFormat, environment.apiDateFormat);
  }
}

describe('FeedContentFiltersHelper', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let leftSidebarService: LeftSidebarService;
  let identifier: string;
  let helper: AppliedFilterHelper;
  let formData: any;
  const appliedFilterTemplate = (<any>appliedFilter).filters;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule],
      declarations: [TestComponent],
      providers: [
        {
          provide: LookupApiService,
          useClass: FakeLookupApiService
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    helper = component.helper;

    leftSidebarService = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'feedContent';
    leftSidebarService.initMainForm(identifier);
    leftSidebarService.pushFormControlStatusList(leftSidebarFilter[identifier]);

    formData = Object.assign({}, (<any>feedContentFormData));
  }));

  it('should create', async(() => {
    expect(component).toBeTruthy();
    expect(helper instanceof FeedContentFiltersHelper).toBe(true);
  }));

  it('should return applied filter object', async(() => {
    const item: AppliedFilter = helper.getFilterObject('term', appliedFilterTemplate);
    expect(item.value).toBe('term');
  }));

  it('should return applied filter from data', async(() => {
    const items: AppliedFilter[] = helper.getFilters(formData);
    expect(items.length).toBeGreaterThan(0);
  }));

  it('should not return applied filter from data', async(() => {
    const items: AppliedFilter[] = helper.getFilters({});
    expect(items.length).toBe(0);
  }));

  it('should call triggerClearForm on removeFilter', async(() => {
    spyOn(leftSidebarService, 'triggerClearForm').and.callThrough();
    helper.removeFilter('feed.dateRange.start-feed.dateRange.end', null);
    helper.removeFilter('source', null);
    helper.removeFilter('feedId', null);
    helper.removeFilter('location.countries.codes', null);
    helper.removeFilter('location.states.codes', null);
    helper.removeFilter('location.counties.codes', null);
    helper.removeFilter('recordId', null);
    expect(leftSidebarService.triggerClearForm).toHaveBeenCalledTimes(8);
  }));

  it('should have Geography applied filter', async(() => {
    formData['sourceType'] = 'REGION';
    formData['source'] = 4735;
    const items: AppliedFilter[] = helper.getFilters(formData);
    const reroutedFilter = items.find(item => item.control === 'source');
    expect(reroutedFilter.name).toBe('Geography');
    expect(reroutedFilter.value).toBe(4735);
  }));

  it('should have Rerouted applied filter', async(() => {
    formData['sourceType'] = 'REPORTER';
    formData['source'] = 'AAMW01';
    const items: AppliedFilter[] = helper.getFilters(formData);
    const reroutedFilter = items.find(item => item.control === 'source');
    expect(reroutedFilter.name).toBe('Rerouted');
    expect(reroutedFilter.value).toBe('AAMW01');
  }));

  it('should not have Geography or Rerouted if sourceType is not REGION or REPORTER', async(() => {
    formData['sourceType'] = 'sample';
    formData['source'] = 'AAMW01';
    const items: AppliedFilter[] = helper.getFilters(formData);
    const reroutedFilter = items.find(item => item.control === 'source');
    expect(reroutedFilter).toBeUndefined();
  }));

  it('should return undefiend if control with - is not daterange', async(() => {
    const value = helper.getValue({
      start: 'some date',
      end: 'some date'
    }, {
        name: 'Sample',
        value: '',
        control: 'start-end',
        order: 1
      });
    expect(value).toBeUndefined();
  }));

  it('should not have a Delivery filter if value is not valid date', async(() => {
    formData['feed']['dateRange']['start'] = null;
    formData['feed']['dateRange']['end'] = null;
    const items: AppliedFilter[] = helper.getFilters(formData);
    const deliveryFilter = items.find(item => item.name === 'Delivery');
    expect(deliveryFilter).toBeUndefined();
  }));

  it('should not have a Delivery filter if value is not valid date format', async(() => {
    formData['feed']['dateRange']['start'] = '09/01/2017';
    formData['feed']['dateRange']['end'] = '09/13/2018';
    const items: AppliedFilter[] = helper.getFilters(formData);
    const deliveryFilter = items.find(item => item.name === 'Delivery');
    expect(deliveryFilter).toBeUndefined();
  }));

  it('should have a Delivery filter if value is valid', async(() => {
    formData['feed']['dateRange']['start'] = '2018-09-12';
    formData['feed']['dateRange']['end'] = '2018-09-14';
    const items: AppliedFilter[] = helper.getFilters(formData);
    const deliveryFilter = items.find(item => item.name === 'Delivery');
    expect(deliveryFilter.value).toBe('09/12/2018 to 09/14/2018');
  }));
});

