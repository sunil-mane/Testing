import { Component, OnInit, OnDestroy, ViewChild, ElementRef, DoCheck } from '@angular/core';
import { AppliedFilter, AppliedFilterHelper } from '../../models/AppliedFilter';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { Subscription } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ProjectSearchFiltersHelper } from './project-search-filters.helper';
import { CompanySearchFiltersHelper } from './company-search-filters.helper';
import { FeedContentFiltersHelper } from './feed-content-filters.helper';
import { DispositionFiltersHelper } from './disposition-filters.helper';
import * as headerdropdown from '../../config/headerdropdown.json';

/**
 * Applied Filter component to keep track of user selected search criteria
 */
@Component({
  selector: 'app-applied-filters',
  templateUrl: './applied-filters.component.html',
  styleUrls: ['./applied-filters.component.scss']
})
export class AppliedFiltersComponent implements OnInit, OnDestroy, DoCheck {
  /** Helper */
  helper: AppliedFilterHelper;

  /** An array of apllied filters selected in the form */
  appliedFilter: AppliedFilter[];

  /** Expand/collapse flag. default is expanded */
  isCollapsed = false;

  /** The start index to begin slicing the appliedFilter array */
  start: number;

  /** Show more / less toggle */
  showMore = false;

  /** Applied filter html element height */
  divHeight = 0;

  @ViewChild('appliedFilterDiv') appliedFilterDivRef: ElementRef;

  /** Subscriptions */
  mainFormValueChangeSubscription: Subscription;

  constructor(public leftSidebarService: LeftSidebarService, private lookupApiService: LookupApiService) {
    this.start = 0;
    this.appliedFilter = [];
  }

  ngOnInit() {
    if (this.leftSidebarService.pageIdentifier === 'projectSearch') {
      this.helper = new ProjectSearchFiltersHelper(this.lookupApiService, this.leftSidebarService,
        (<any>headerdropdown).findInDropDown, environment.defaultDateFormat, environment.apiDateFormat);
    } else if (this.leftSidebarService.pageIdentifier === 'companySearch') {
      this.helper = new CompanySearchFiltersHelper(this.lookupApiService, this.leftSidebarService);
    } else if (this.leftSidebarService.pageIdentifier === 'feedContent') {
      this.helper = new FeedContentFiltersHelper(this.lookupApiService, this.leftSidebarService,
        environment.defaultDateFormat, environment.apiDateFormat);
    } else if (this.leftSidebarService.pageIdentifier === 'disposition') {
      this.helper = new DispositionFiltersHelper(this.lookupApiService, this.leftSidebarService,
        environment.defaultDateFormat, environment.apiDateFormat);
    }
    this.mainFormValueChangeSubscription = this.leftSidebarService.getMainForm.valueChanges.subscribe((res) => {
      this.appliedFilter = (this.helper) ? this.helper.getFilters(res) : [];
    });
  }

  ngDoCheck() {
    this.divHeight = this.appliedFilterDivRef.nativeElement.offsetHeight;
    this.showMore = (this.divHeight > 35) ? this.showMore : false;
  }

  ngOnDestroy() {
    if (this.mainFormValueChangeSubscription) {
      this.mainFormValueChangeSubscription.unsubscribe();
    }
  }
}
