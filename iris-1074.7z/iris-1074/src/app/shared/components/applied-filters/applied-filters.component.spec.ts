import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { AppliedFiltersComponent } from './applied-filters.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { SharedModule } from '../../shared.module';
import { CompanySearchFiltersHelper } from './company-search-filters.helper';
import { ProjectSearchFiltersHelper } from './project-search-filters.helper';
import { BaseFormControl } from '../../forms/base-form-control';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';
import * as appliedFilter from '../../config/applied-filters-project-search.json';

describe('AppliedFiltersComponent', () => {
  let component: AppliedFiltersComponent;
  let fixture: ComponentFixture<AppliedFiltersComponent>;
  let leftSidebarService: LeftSidebarService;
  let identifier: string;
  let elements: Array<DebugElement>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppliedFiltersComponent);
    component = fixture.componentInstance;

    leftSidebarService = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'projectSearch';
    leftSidebarService.initMainForm('projectSearch');
    leftSidebarService.pushFormControlStatusList(leftSidebarFilter[identifier]);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have call "ngOnDestroy"', async(() => {
    spyOn(component, 'ngOnDestroy').and.callThrough();
    component.ngOnInit();
    component.ngOnDestroy();
    fixture.whenStable().then(() => {
      expect(component.ngOnDestroy).toHaveBeenCalled();
      expect(component.mainFormValueChangeSubscription).toBeDefined();
      expect(component.mainFormValueChangeSubscription.closed).toBe(true);
    });
  }));

  it('should have displayed breadcrumb with remove filter button', async(() => {
    component.appliedFilter = (<any>appliedFilter).filters;
    fixture.detectChanges();
    elements = fixture.debugElement.queryAll(By.css('.applied-filter-col-with-remove'));
    fixture.whenStable().then(() => {
      expect(elements.length).toBeGreaterThan(1);
    });
  }));

  it('should not initialize filter helper', async(() => {
    leftSidebarService.pageIdentifier = null;
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.helper).toBeUndefined();
    component.ngOnDestroy();
  }));

  it('should initialize projectSearch filter helper', async(() => {
    leftSidebarService.pageIdentifier = 'projectSearch';
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.helper instanceof ProjectSearchFiltersHelper).toBe(true);
    component.ngOnDestroy();
  }));

  it('should initialize companySearch filter helper', async(() => {
    leftSidebarService.pageIdentifier = 'companySearch';
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.helper instanceof CompanySearchFiltersHelper).toBe(true);
    component.ngOnDestroy();
  }));

  it('should have filter on form value change', async(() => {
    const termFormControl: BaseFormControl = new BaseFormControl('Text Search', 'term', 'text', '', [], []);
    const textSearchFindInControl = new BaseFormControl('FindIn', 'searchType', 'select', 'Entire report', [], []);
    leftSidebarService.getMainForm.addControl('term', termFormControl);
    leftSidebarService.getMainForm.addControl('searchType', textSearchFindInControl);
    component.ngOnInit();
    fixture.detectChanges();
    leftSidebarService.getMainForm.get('term').setValue('test');
    fixture.detectChanges();
    expect(component.appliedFilter.length).toBe(1);
    component.ngOnDestroy();
  }));

  it('should not have filter on form value change', async(() => {
    leftSidebarService.pageIdentifier = null;
    const termFormControl: BaseFormControl = new BaseFormControl('Text Search', 'term', 'text', '', [], []);
    const textSearchFindInControl = new BaseFormControl('FindIn', 'searchType', 'select', 'Entire report', [], []);
    leftSidebarService.getMainForm.addControl('term', termFormControl);
    leftSidebarService.getMainForm.addControl('searchType', textSearchFindInControl);
    component.ngOnInit();
    fixture.detectChanges();
    leftSidebarService.getMainForm.get('term').setValue('test');
    fixture.detectChanges();
    expect(component.appliedFilter.length).toBe(0);
    component.ngOnDestroy();
  }));
});
