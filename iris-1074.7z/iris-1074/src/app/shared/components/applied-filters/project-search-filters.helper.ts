import { LookupApiService } from '../../services/lookup-api.service';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { AppliedFilter, AppliedFilterHelper } from '../../models/AppliedFilter';
import { FindInDropdowns } from '../../models/PageHeader';
import { isEmpty, isNil, isArray, isNumber, orderBy, get } from 'lodash';
import * as moment from 'moment';
import * as appliedFilter from '../../config/applied-filters-project-search.json';

export class ProjectSearchFiltersHelper implements AppliedFilterHelper {
  /** Lookup API Service Instance */
  lookupApiService: LookupApiService;
  /** Left Sidebar Service */
  leftSidebarService: LeftSidebarService;
  /** Find in dropdown */
  findInDropdown: Array<FindInDropdowns>;
  /** Date Format */
  dateFormat: string;
  /** Api Date Format */
  apiDateFormat: string;
  /** Applied filter template */
  appliedFilterTemplate: Array<AppliedFilter>;

  constructor(lookupApiService: LookupApiService, leftSidebarService: LeftSidebarService, findInDropdown: Array<FindInDropdowns>,
    dateFormat: string, apiDateFormat: string) {
    // Lookup api service intstance
    this.lookupApiService = lookupApiService;
    // Left sidebar service intstance
    this.leftSidebarService = leftSidebarService;
    // Set default headers
    this.findInDropdown = findInDropdown;
    // Date format
    this.dateFormat = dateFormat;
    // Api Date format
    this.apiDateFormat = apiDateFormat;
    // Applied filter template
    this.appliedFilterTemplate = (<any>appliedFilter).filters;
  }
  /**
   * Project search applied filter array.
   * @returns Array<AppliedFilter> array of AppliedFilter
   */
  getFilters(data: any): Array<AppliedFilter> {
    const appliedFilters: Array<AppliedFilter> = [];
    this.appliedFilterTemplate.forEach((tpl) => {
      const controlValue = this.getValue(data, tpl);
      if (isNumber(controlValue) || !isEmpty(controlValue)) {
        if (isArray(controlValue)) {
          if (tpl.control === 'project.bid.dateCodes') {
            const dateCodesValue = [];
            controlValue.forEach(datecode => {
              if (datecode === 'asap') {
                dateCodesValue.push('ASAP');
              } else if (datecode === 'no-date-set') {
                dateCodesValue.push('NDS');
              }
            });
            if (dateCodesValue.length > 0) {
              appliedFilters.push(this.getFilterObject(dateCodesValue.join(', '), tpl));
            }
          } else {
            controlValue.forEach((val) => {
              if (!isNil(val) && !isEmpty(val)) {
                appliedFilters.push(this.getFilterObject(val, tpl));
              }
            });
          }
        } else {
          if (tpl.control === 'term') {
            const searchType = this.getValue(data, { control: 'searchType' });
            appliedFilters.push({
              name: 'Text search (' + searchType + ')',
              value: controlValue,
              control: 'term',
              showRemoveFilter: true,
              order: 1
            });
          } else {
            appliedFilters.push(this.getFilterObject(controlValue, tpl));
          }
        }
      }
    });
    return orderBy(appliedFilters, ['order'], ['asc']);
  }

  /**
   * Bind to remove filter button of applied filter component
   * @param {string} control Control name from appliedFilterTemplates
   * @param value
   */
  removeFilter(control: string, value: string) {
    if (control.includes('-')) {
      const controls = control.split('-');
      controls.forEach((val) => {
        this.leftSidebarService.triggerClearForm(val);
      });
    } else if (control === 'project.bid.dateCodes') {
      const controlValue = value.split(', ');
      const dateCodesValue = [];
      controlValue.forEach(code => {
        if (code === 'ASAP') {
          dateCodesValue.push('asap');
        } else if (code === 'NDS') {
          dateCodesValue.push('no-date-set');
        }
      });
      const payload = { control: control, value: dateCodesValue };
      this.leftSidebarService.triggerClearForm(payload);
    } else if (control === 'project.stages') {
      const payload = { control: control, value: this.lookupApiService.getProjectStageIdByName(value) };
      this.leftSidebarService.triggerClearForm(payload);
    } else if (control === 'project.types') {
      const payload = { control: control, value: this.lookupApiService.getProjectTypeCodeByName(value) };
      this.leftSidebarService.triggerClearForm(payload);
    } else if (control === 'company.type') {
      this.leftSidebarService.triggerClearForm(control);
    } else if (control === 'company.location.countries.codes' || control === 'project.location.countries.codes') {
      const payload = { control: control, value: this.lookupApiService.getCountryIdByName(value) };
      this.leftSidebarService.triggerClearForm(payload);
    } else if (control === 'company.location.states.codes' || control === 'project.location.states.codes') {
      const payload = { control: control, value: this.lookupApiService.getStatesIdByName(value) };
      this.leftSidebarService.triggerClearForm(payload);
    } else if (control === 'company.location.counties.codes' || control === 'project.location.counties.codes') {
      const payload = { control: control, value: this.lookupApiService.getCountyIdByName(value) };
      this.leftSidebarService.triggerClearForm(payload);
    } else {
      const payload = (isNil(value)) ? control : { control: control, value: value };
      this.leftSidebarService.triggerClearForm(payload);
    }
  }

  /**
   * Get applied filter value
   * @param data main form value
   * @param template applied filter template
   * @returns {any} string or array
   */
  getValue(data: any, template: AppliedFilter): any {
    if (template.control.includes('-')) {
      const controls = template.control.split('-');
      const values = [];
      controls.forEach((control) => {
        const value = get(data, control);
        if (!isEmpty(value)) {
          if (control === 'project.valuation.range.min') {
            const name = this.lookupApiService.getValuationLowHighById(value, 'low');
            values.push(name);
          } else if (control === 'project.valuation.range.max') {
            const name = this.lookupApiService.getValuationLowHighById(value, 'high');
            values.push(name);
          } else if (control.includes('dateRange')) {
            if (moment(value, this.apiDateFormat, true).isValid()) {
              const formatedDate = moment(value).format(this.dateFormat);
              values.push(formatedDate);
            }
          } else {
            values.push(value);
          }
        }
      });
      return (values.length === controls.length) ? values.join(' to ') : values[0];
    } else {
      const value = get(data, template.control);
      if (template.control === 'project.stages') {
        if (!isEmpty(value)) {
          const stageName = [];
          value.forEach((val) => { stageName.push(this.lookupApiService.getProjectStageNameById(val)); });
          return stageName;
        }
      } else if (template.control === 'project.types') {
        if (!isEmpty(value)) {
          const typeName = [];
          value.forEach((val) => { typeName.push(this.lookupApiService.getProjectTypeNameByCode(val)); });
          return typeName;
        }
      } else if (template.control === 'company.location.countries.codes' || template.control === 'project.location.countries.codes') {
        if (!isEmpty(value)) {
          const countryName = [];
          value.forEach((val) => { countryName.push(this.lookupApiService.getCountryNameById(val)); });
          return countryName;
        }
      } else if (template.control === 'company.location.states.codes' || template.control === 'project.location.states.codes') {
        if (!isEmpty(value)) {
          const stateName = [];
          value.forEach((val) => { stateName.push(this.lookupApiService.getStatesNameById(val)); });
          return stateName;
        }
      } else if (template.control === 'company.location.counties.codes' || template.control === 'project.location.counties.codes') {
        if (!isEmpty(value)) {
          const countyName = [];
          value.forEach((val) => { countyName.push(this.lookupApiService.getCountyNameById(val)); });
          return countyName;
        }
      } else if (template.control === 'company.phone' && template.name.toLowerCase() === 'company area code') {
        if (!isNil(value) && !isEmpty(value)) {
          const newValue = value.replace(/\D+/g, '');
          const valueLength = String(newValue).length;
          const areaCode = (valueLength === 10) ? String(newValue).slice(0, 3) : (valueLength === 3) ? newValue : '';
          return (areaCode.length === 3) ? areaCode : null;
        }
      } else if (template.control === 'company.phone' && template.name.toLowerCase() === 'company phone') {
        if (!isNil(value) && !isEmpty(value)) {
          const newValue = value.replace(/\D+/g, '');
          const valueLength = String(newValue).length;
          const phone = (valueLength === 10) ? String(newValue).slice(3) : (valueLength === 7) ? newValue : '';
          return (phone.length === 7) ? phone : null;
        }
      } else if (template.control === 'searchType') {
        const dropdownLabel = this.findInDropdown.find(item => item.value === value);
        return (isEmpty(dropdownLabel)) ? null : dropdownLabel.label;
      } else {
        return (isEmpty(value)) ? null : value;
      }

      return null;
    }
  }

  /**
   * Get applied filter object
   * @param {any} controlValue the value
   * @param {any} template control template
   * @returns {any} string or array
   */
  getFilterObject(controlValue: any, template: AppliedFilter): any {
    return {
      value: controlValue,
      control: template.control,
      name: template.name,
      showRemoveFilter: template.showRemoveFilter,
      order: template.order
    };
  }
}
