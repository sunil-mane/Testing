import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, Injectable } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ProjectSearchFiltersHelper } from './project-search-filters.helper';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { AppliedFilter, AppliedFilterHelper } from '../../models/AppliedFilter';
import { SharedModule } from '../../shared.module';
import { environment } from '../../../../environments/environment';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';
import * as appliedFilter from '../../config/applied-filters-project-search.json';
import * as headerdropdown from '../../config/headerdropdown.json';
import * as projectFormData from '../../../../mocks/projectFormData.json';


@Injectable()
export class FakeLookupApiService {
  constructor() { }

  getProjectStageNameById(id: string): string {
    return id;
  }
  getProjectStageIdByName(name: string): string {
    return name;
  }

  getProjectTypeNameByCode(code: string): string {
    return code;
  }
  getProjectTypeCodeByName(name: string): string {
    return name;
  }

  getValuationLowHighById(id: string, type: 'low' | 'high'): number {
    return 123;
  }
  getValuationIdByLowHigh(lowHighValue: number, type: 'low' | 'high'): string {
    return 'N';
  }


  getCompanyTypeNameById(id: string): string {
    return id;
  }
  getCompanyTypeIdByName(name: string): string {
    return name;
  }

  getCountryNameById(id: string): string {
    return id;
  }
  getCountryIdByName(name: string): string {
    return name;
  }

  getStatesNameById(id: string): string {
    return id;
  }
  getStatesIdByName(name: string): string {
    return name;
  }

  getCountyNameById(id: string): string {
    return id;
  }
  getCountyIdByName(name: string): string {
    return name;
  }
}


@Component({
  selector: 'app-test',
  template: '<h1>Project Search Filters Helper</h1>'
})
class TestComponent {
  /** Helper */
  helper: AppliedFilterHelper;

  constructor(public leftSidebarService: LeftSidebarService, private lookupApiService: LookupApiService) {
    this.helper = new ProjectSearchFiltersHelper(this.lookupApiService, this.leftSidebarService,
      (<any>headerdropdown).findInDropDown, environment.defaultDateFormat, environment.apiDateFormat);
  }
}

describe('ProjectSearchFiltersHelper', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let leftSidebarService: LeftSidebarService;
  let identifier: string;
  let helper: AppliedFilterHelper;
  let formData: any;
  const appliedFilterTemplate = (<any>appliedFilter).filters;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule],
      declarations: [TestComponent],
      providers: [
        {
          provide: LookupApiService,
          useClass: FakeLookupApiService
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    helper = component.helper;

    leftSidebarService = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'projectSearch';
    leftSidebarService.initMainForm('projectSearch');
    leftSidebarService.pushFormControlStatusList(leftSidebarFilter[identifier]);

    formData = Object.assign({}, (<any>projectFormData));
  }));

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', async(() => {
    expect(component).toBeTruthy();
    expect(helper instanceof ProjectSearchFiltersHelper).toBe(true);
  }));

  it('should return applied filter object', async(() => {
    const item: AppliedFilter = helper.getFilterObject('term', appliedFilterTemplate);
    expect(item.value).toBe('term');
  }));

  it('should return applied filter from data', async(() => {
    const items: AppliedFilter[] = helper.getFilters(formData);
    expect(items.length).toBeGreaterThan(0);
  }));

  it('should not return applied filter from data', async(() => {
    const items: AppliedFilter[] = helper.getFilters({});
    expect(items.length).toBe(0);
  }));

  it('should call triggerClearForm on removeFilter', async(() => {
    spyOn(leftSidebarService, 'triggerClearForm').and.callThrough();
    helper.removeFilter('project.bid.dateRange.start-project.bid.dateRange.end', null);
    helper.removeFilter('project.bid.dateCodes', 'ASAP, NDS');
    helper.removeFilter('project.bid.dateCodes', '');
    helper.removeFilter('project.stages', 'PS');
    helper.removeFilter('project.types', 'PT');
    helper.removeFilter('company.type', null);
    helper.removeFilter('company.location.countries.codes', 'USA');
    helper.removeFilter('project.location.countries.codes', 'USA');
    helper.removeFilter('company.location.states.codes', 'ALA');
    helper.removeFilter('project.location.states.codes', 'ALA');
    helper.removeFilter('company.location.counties.codes', 'USALA');
    helper.removeFilter('project.location.counties.codes', 'USALA');
    helper.removeFilter('term', null);
    helper.removeFilter('company.name', 'test');
    expect(leftSidebarService.triggerClearForm).toHaveBeenCalledTimes(15);
  }));

  it('should return value from data for area code and phone when value is 10 digit', async(() => {
    formData.company.phone = '1111111111';
    const phoneAreaCode = helper.getValue(formData, {
      name: 'Company area code',
      value: '',
      control: 'company.phone',
      order: 12
    });
    const phone = helper.getValue(formData, {
      name: 'Company Phone',
      value: '',
      control: 'company.phone',
      order: 13
    });
    expect(phoneAreaCode).toBe('111');
    expect(phone).toBe('1111111');
  }));

  it('should not return value from data for area code and phone value is empty', async(() => {
    formData.company.phone = '';
    const phoneAreaCode = helper.getValue(formData, {
      name: 'Company area code',
      value: '',
      control: 'company.phone',
      order: 12
    });
    const phone = helper.getValue(formData, {
      name: 'Company Phone',
      value: '',
      control: 'company.phone',
      order: 13
    });
    expect(phoneAreaCode).toBeNull();
    expect(phone).toBeNull();
  }));

  it('should return value from data for area code when value is 3 digit', async(() => {
    formData.company.phone = '111';
    const phoneAreaCode = helper.getValue(formData, {
      name: 'Company area code',
      value: '',
      control: 'company.phone',
      order: 12
    });
    expect(phoneAreaCode).toBe('111');
  }));

  it('should not return value from data for area code value is less than 3 digit', async(() => {
    formData.company.phone = '11';
    const phoneAreaCode = helper.getValue(formData, {
      name: 'Company area code',
      value: '',
      control: 'company.phone',
      order: 12
    });
    expect(phoneAreaCode).toBeNull();
  }));

  it('should return value from data for phone when value length is 7', async(() => {
    formData.company.phone = '1111111';
    const phone = helper.getValue(formData, {
      name: 'Company Phone',
      value: '',
      control: 'company.phone',
      order: 13
    });
    expect(phone).toBe('1111111');
  }));

  it('should not return value from data for phone when value length is less than 7', async(() => {
    formData.company.phone = '111111';
    const phone = helper.getValue(formData, {
      name: 'Company Phone',
      value: '',
      control: 'company.phone',
      order: 13
    });
    expect(phone).toBeNull();
  }));

  it('should not return value from data if project country, state and county if value is not empty', async(() => {
    formData.project.location.countries.codes = [];
    formData.project.location.states.codes = [];
    formData.project.location.counties.codes = [];
    const projectCountries = helper.getValue(formData, {
      name: 'Country',
      value: '',
      control: 'project.location.countries.codes',
      order: 6
    });
    const projectStates = helper.getValue(formData, {
      name: 'State',
      value: '',
      control: 'project.location.states.codes',
      order: 6
    });
    const projectCounties = helper.getValue(formData, {
      name: 'County',
      value: '',
      control: 'project.location.counties.codes',
      order: 6
    });
    expect(projectCountries).toBeNull();
    expect(projectStates).toBeNull();
    expect(projectCounties).toBeNull();
  }));

  it('should not return value from data if company country, state and county if value is not empty', async(() => {
    formData.company.location.countries.codes = [];
    formData.company.location.states.codes = [];
    formData.company.location.counties.codes = [];
    const companyCountries = helper.getValue(formData, {
      name: 'Company Country',
      value: '',
      control: 'company.location.countries.codes',
      order: 6
    });
    const companyStates = helper.getValue(formData, {
      name: 'Company State',
      value: '',
      control: 'company.location.states.codes',
      order: 6
    });
    const companyCounties = helper.getValue(formData, {
      name: 'Company County',
      value: '',
      control: 'company.location.counties.codes',
      order: 6
    });
    expect(companyCountries).toBeNull();
    expect(companyStates).toBeNull();
    expect(companyCounties).toBeNull();
  }));

  it('should return value from data if project country, state and county if value is not empty', async(() => {
    formData.project.location.countries.codes = ['USA'];
    formData.project.location.states.codes = ['ALA'];
    formData.project.location.counties.codes = ['USALA'];
    const projectCountries = helper.getValue(formData, {
      name: 'Country',
      value: '',
      control: 'project.location.countries.codes',
      order: 6
    });
    const projectStates = helper.getValue(formData, {
      name: 'State',
      value: '',
      control: 'project.location.states.codes',
      order: 6
    });
    const projectCounties = helper.getValue(formData, {
      name: 'County',
      value: '',
      control: 'project.location.counties.codes',
      order: 6
    });
    expect(projectCountries.length).toBe(1);
    expect(projectStates.length).toBe(1);
    expect(projectCounties.length).toBe(1);
  }));

  it('should return value from data if company country, state and county if value is not empty', async(() => {
    formData.company.location.countries.codes = ['USA'];
    formData.company.location.states.codes = ['ALA'];
    formData.company.location.counties.codes = ['USALA'];
    const companyCountries = helper.getValue(formData, {
      name: 'Company Country',
      value: '',
      control: 'company.location.countries.codes',
      order: 6
    });
    const companyStates = helper.getValue(formData, {
      name: 'Company State',
      value: '',
      control: 'company.location.states.codes',
      order: 6
    });
    const companyCounties = helper.getValue(formData, {
      name: 'Company County',
      value: '',
      control: 'company.location.counties.codes',
      order: 6
    });
    expect(companyCountries.length).toBe(1);
    expect(companyStates.length).toBe(1);
    expect(companyCounties.length).toBe(1);
  }));

  it('should not format date if date is null', async(() => {
    formData.project.bid.dateRange.start = 'date';
    formData.project.bid.dateRange.end = 'date';
    const value = helper.getValue(formData, {
      name: 'Bid Date',
      value: '',
      control: 'project.bid.dateRange.start-project.bid.dateRange.end',
      order: 5
    });
    expect(value).toBeUndefined();
  }));

  it('should return "value to value" when control contain "-" and is not valuation or daterange', async(() => {
    formData.project.bid.start = 'date';
    formData.project.bid.end = 'date';
    const value = helper.getValue(formData, {
      name: 'Bid Date',
      value: '',
      control: 'project.bid.start-project.bid.end',
      order: 5
    });
    expect(value).toBe('date to date');
  }));

  it('should return find in dropdown label', async(() => {
    formData.searchType = 'Notes text';
    const value = helper.getValue(formData, { control: 'searchType' });
    expect(value).toBe('Published Notes');
  }));

  it('should not return find in dropdown label if value is not in find in dropdown', async(() => {
    formData.searchType = 'test';
    const value = helper.getValue(formData, { control: 'searchType' });
    expect(value).toBeNull();
  }));

  it('should return filter object if dateCodes for value asap and/or no-date-set only', async(() => {
    formData.project.bid.dateCodes = ['asap', 'no-date-set', 'test'];
    const filter: AppliedFilter[] = helper.getFilters(formData);
    const dateCodesFilter: AppliedFilter = filter.find(item => item.control === 'project.bid.dateCodes');
    expect(dateCodesFilter.value).toBe('ASAP, NDS');
  }));

  it('should not return applied filter from data if value is array empty values', async(() => {
    helper.getValue = (data: any, template: AppliedFilter) => {
      return [null, ''];
    };
    const items: AppliedFilter[] = helper.getFilters(formData);
    expect(items.length).toBe(0);
  }));

  it('should return applied filter object for text search', async(() => {
    formData.searchType = 'Notes text';
    formData.term = 'test';
    const filter: AppliedFilter[] = helper.getFilters(formData);
    const termFilter: AppliedFilter = filter.find(item => item.control === 'term');
    expect(termFilter.value).toBe('test');
    expect(termFilter.name).toBe('Text search (Published Notes)');
  }));
});

