import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, Injectable } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CompanySearchFiltersHelper } from './company-search-filters.helper';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { LookupApiService } from '../../services/lookup-api.service';
import { AppliedFilter, AppliedFilterHelper } from '../../models/AppliedFilter';
import { SharedModule } from '../../shared.module';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';
import * as appliedFilter from '../../config/applied-filters-company-search.json';
import * as companyFormData from '../../../../mocks/companyFormData.json';

@Injectable()
export class FakeLookupApiService {
  constructor() { }

  getProjectStageNameById(id: string): string {
    return id;
  }
  getProjectStageIdByName(name: string): string {
    return name;
  }

  getProjectTypeNameByCode(code: string): string {
    return code;
  }
  getProjectTypeCodeByName(name: string): string {
    return name;
  }

  getValuationLowHighById(id: string, type: 'low' | 'high'): number {
    return 123;
  }
  getValuationIdByLowHigh(lowHighValue: number, type: 'low' | 'high'): string {
    return 'N';
  }


  getCompanyTypeNameById(id: string): string {
    return id;
  }
  getCompanyTypeIdByName(name: string): string {
    return name;
  }

  getCountryNameById(id: string): string {
    return id;
  }
  getCountryIdByName(name: string): string {
    return name;
  }

  getStatesNameById(id: string): string {
    return id;
  }
  getStatesIdByName(name: string): string {
    return name;
  }

  getCountyNameById(id: string): string {
    return id;
  }
  getCountyIdByName(name: string): string {
    return name;
  }
}


@Component({
  selector: 'app-test',
  template: '<h1>Company Search Filters Helper</h1>'
})
class TestComponent {
  /** Helper */
  helper: AppliedFilterHelper;

  constructor(public leftSidebarService: LeftSidebarService, private lookupApiService: LookupApiService) {
    this.helper = new CompanySearchFiltersHelper(this.lookupApiService, this.leftSidebarService);
  }
}

describe('CompanySearchFiltersHelper', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let leftSidebarService: LeftSidebarService;
  let identifier: string;
  let helper: AppliedFilterHelper;
  const appliedFilterTemplate = (<any>appliedFilter).filters;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule],
      declarations: [TestComponent],
      providers: [
        {
          provide: LookupApiService,
          useClass: FakeLookupApiService
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    helper = component.helper;

    leftSidebarService = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'companySearch';
    leftSidebarService.initMainForm('companySearch');
    leftSidebarService.pushFormControlStatusList(leftSidebarFilter[identifier]);
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(helper instanceof CompanySearchFiltersHelper).toBe(true);
  });

  it('should return applied filter object', async(() => {
    const item: AppliedFilter = helper.getFilterObject('term', appliedFilterTemplate[0]);
    expect(item.value).toBe('term');
  }));

  it('should return applied filter from data', async(() => {
    const items: AppliedFilter[] = helper.getFilters(companyFormData);
    expect(items.length).toBeGreaterThan(0);
  }));

  it('should not return applied filter from data', async(() => {
    const items: AppliedFilter[] = helper.getFilters({});
    expect(items.length).toBe(0);
  }));

  it('should not return applied filter from data if value is array empty values', async(() => {
    helper.getValue = (data: any, template: AppliedFilter) => {
      return [null, ''];
    };
    const items: AppliedFilter[] = helper.getFilters(companyFormData);
    expect(items.length).toBe(0);
  }));

  it('should return value from data', async(() => {
    const value = helper.getValue(companyFormData, appliedFilterTemplate[0]);
    expect(value).toBe('aaa');
  }));

  it('should not return value from data if country, state and county if value is not empty', async(() => {
    (companyFormData as any).company.location.countries.codes = [];
    (companyFormData as any).company.location.states.codes = [];
    (companyFormData as any).company.location.counties.codes = [];
    const countries = helper.getValue(companyFormData, {
      name: 'Country',
      value: '',
      control: 'company.location.countries.codes',
      order: 6
    });
    const states = helper.getValue(companyFormData, {
      name: 'State',
      value: '',
      control: 'company.location.states.codes',
      order: 6
    });
    const counties = helper.getValue(companyFormData, {
      name: 'County',
      value: '',
      control: 'company.location.counties.codes',
      order: 6
    });
    expect(countries).toBeNull();
    expect(states).toBeNull();
    expect(counties).toBeNull();
  }));

  it('should return value from data if country, state and county if value is not empty', async(() => {
    (companyFormData as any).company.location.countries.codes = ['USA'];
    (companyFormData as any).company.location.states.codes = ['ALA'];
    (companyFormData as any).company.location.counties.codes = ['USALA'];
    const countries = helper.getValue(companyFormData, {
      name: 'Country',
      value: '',
      control: 'company.location.countries.codes',
      order: 6
    });
    const states = helper.getValue(companyFormData, {
      name: 'State',
      value: '',
      control: 'company.location.states.codes',
      order: 6
    });
    const counties = helper.getValue(companyFormData, {
      name: 'County',
      value: '',
      control: 'company.location.counties.codes',
      order: 6
    });
    expect(countries.length).toBe(1);
    expect(states.length).toBe(1);
    expect(counties.length).toBe(1);
  }));

  it('should return value from data for area code and phone when value is 10 digit', async(() => {
    (companyFormData as any).company.phone = '1111111111';
    (companyFormData as any).company.fax = '2222222222';
    const phoneAreaCode = helper.getValue(companyFormData, {
      name: 'Company Phone area code',
      value: '',
      control: 'company.phone',
      order: 12
    });
    const phone = helper.getValue(companyFormData, {
      name: 'Company Phone',
      value: '',
      control: 'company.phone',
      order: 13
    });
    const faxAreaCode = helper.getValue(companyFormData, {
      name: 'Company Fax area code',
      value: '',
      control: 'company.fax',
      order: 14
    });
    const fax = helper.getValue(companyFormData, {
      name: 'Company Fax',
      value: '',
      control: 'company.fax',
      order: 15
    });
    expect(phoneAreaCode).toBe('111');
    expect(phone).toBe('1111111');
    expect(faxAreaCode).toBe('222');
    expect(fax).toBe('2222222');
  }));

  it('should not return value from data for area code and phone value is empty', async(() => {
    (companyFormData as any).company.phone = '';
    (companyFormData as any).company.fax = '';
    const phoneAreaCode = helper.getValue(companyFormData, {
      name: 'Company Phone area code',
      value: '',
      control: 'company.phone',
      order: 12
    });
    const phone = helper.getValue(companyFormData, {
      name: 'Company Phone',
      value: '',
      control: 'company.phone',
      order: 13
    });
    const faxAreaCode = helper.getValue(companyFormData, {
      name: 'Company Fax area code',
      value: '',
      control: 'company.fax',
      order: 14
    });
    const fax = helper.getValue(companyFormData, {
      name: 'Company Fax',
      value: '',
      control: 'company.fax',
      order: 15
    });
    expect(phoneAreaCode).toBeNull();
    expect(phone).toBeNull();
    expect(faxAreaCode).toBeNull();
    expect(fax).toBeNull();
  }));

  it('should return value from data for area code when value is 3 digit', async(() => {
    (companyFormData as any).company.phone = '111';
    (companyFormData as any).company.fax = '222';
    const phoneAreaCode = helper.getValue(companyFormData, {
      name: 'Company Phone area code',
      value: '',
      control: 'company.phone',
      order: 12
    });
    const faxAreaCode = helper.getValue(companyFormData, {
      name: 'Company Fax area code',
      value: '',
      control: 'company.fax',
      order: 14
    });
    expect(phoneAreaCode).toBe('111');
    expect(faxAreaCode).toBe('222');
  }));

  it('should not return value from data for area code value is less than 3 digit', async(() => {
    (companyFormData as any).company.phone = '11';
    (companyFormData as any).company.fax = '22';
    const phoneAreaCode = helper.getValue(companyFormData, {
      name: 'Company Phone area code',
      value: '',
      control: 'company.phone',
      order: 12
    });
    const faxAreaCode = helper.getValue(companyFormData, {
      name: 'Company Fax area code',
      value: '',
      control: 'company.fax',
      order: 14
    });
    expect(phoneAreaCode).toBeNull();
    expect(faxAreaCode).toBeNull();
  }));

  it('should return value from data for phone when value length is 7', async(() => {
    (companyFormData as any).company.phone = '1111111';
    (companyFormData as any).company.fax = '2222222';
    const phone = helper.getValue(companyFormData, {
      name: 'Company Phone',
      value: '',
      control: 'company.phone',
      order: 13
    });
    const fax = helper.getValue(companyFormData, {
      name: 'Company Fax',
      value: '',
      control: 'company.fax',
      order: 15
    });
    expect(phone).toBe('1111111');
    expect(fax).toBe('2222222');
  }));

  it('should not return value from data for phone when value length is less than 7', async(() => {
    (companyFormData as any).company.phone = '111111';
    (companyFormData as any).company.fax = '222222';
    const phone = helper.getValue(companyFormData, {
      name: 'Company Phone',
      value: '',
      control: 'company.phone',
      order: 13
    });
    const fax = helper.getValue(companyFormData, {
      name: 'Company Fax',
      value: '',
      control: 'company.fax',
      order: 15
    });
    expect(phone).toBeNull();
    expect(fax).toBeNull();
  }));

  it('should call triggerClearForm on removeFilter', async(() => {
    spyOn(leftSidebarService, 'triggerClearForm').and.callThrough();
    helper.removeFilter('company.type', null);
    helper.removeFilter('company.location.countries.codes', 'USA');
    helper.removeFilter('company.location.states.codes', 'ALA');
    helper.removeFilter('company.location.counties.codes', 'USALA');
    helper.removeFilter('term', null);
    helper.removeFilter('company.name', 'test');
    expect(leftSidebarService.triggerClearForm).toHaveBeenCalledTimes(6);
  }));
});

