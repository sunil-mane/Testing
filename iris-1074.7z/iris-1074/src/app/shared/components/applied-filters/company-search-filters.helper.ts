import { LookupApiService } from '../../services/lookup-api.service';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { AppliedFilter, AppliedFilterHelper } from '../../models/AppliedFilter';
import { isEmpty, isNil, isArray, isNumber, orderBy, get } from 'lodash';
import * as appliedFilter from '../../config/applied-filters-company-search.json';

export class CompanySearchFiltersHelper implements AppliedFilterHelper {
  /** Lookup API Service Instance */
  lookupApiService: LookupApiService;
  /** Left Sidebar Service */
  leftSidebarService: LeftSidebarService;
  /** Applied filter template */
  appliedFilterTemplate: Array<AppliedFilter>;

  constructor(lookupApiService: LookupApiService, leftSidebarService: LeftSidebarService) {
    // Lookup api service intstance
    this.lookupApiService = lookupApiService;
    // Left sidebar service intstance
    this.leftSidebarService = leftSidebarService;
    // Applied filter template
    this.appliedFilterTemplate = (<any>appliedFilter).filters;
  }
  /**
   * Project search applied filter array.
   * @returns Array<AppliedFilter> array of AppliedFilter
   */
  getFilters(data: any): Array<AppliedFilter> {
    const appliedFilters: Array<AppliedFilter> = [];
    this.appliedFilterTemplate.forEach((tpl) => {
      const controlValue = this.getValue(data, tpl);
      if (isNumber(controlValue) || !isEmpty(controlValue)) {
        if (isArray(controlValue)) {
          controlValue.forEach((val) => {
            if (!isNil(val) && !isEmpty(val)) {
              appliedFilters.push(this.getFilterObject(val, tpl));
            }
          });
        } else {
          appliedFilters.push(this.getFilterObject(controlValue, tpl));
        }
      }
    });
    return orderBy(appliedFilters, ['order'], ['asc']);
  }

  /**
   * Bind to remove filter button of applied filter component
   * @param {string} control Control name from appliedFilterTemplates
   * @param value
   */
  removeFilter(control: string, value: string) {
    if (control === 'company.type') {
      this.leftSidebarService.triggerClearForm(control);
    } else if (control === 'company.location.countries.codes') {
      const payload = { control: control, value: this.lookupApiService.getCountryIdByName(value) };
      this.leftSidebarService.triggerClearForm(payload);
    } else if (control === 'company.location.states.codes') {
      const payload = { control: control, value: this.lookupApiService.getStatesIdByName(value) };
      this.leftSidebarService.triggerClearForm(payload);
    } else if (control === 'company.location.counties.codes') {
      const payload = { control: control, value: this.lookupApiService.getCountyIdByName(value) };
      this.leftSidebarService.triggerClearForm(payload);
    } else {
      const payload = (isNil(value)) ? control : { control: control, value: value };
      this.leftSidebarService.triggerClearForm(payload);
    }
  }

  /**
   * Get applied filter value
   * @param data main form value
   * @param template applied filter template
   * @returns {any} string or array
   */
  getValue(data: any, template: AppliedFilter): any {
    const value = get(data, template.control);
    if (template.control === 'company.type') {
      return this.lookupApiService.getCompanyTypeNameById(value);
    } else if (template.control === 'company.location.countries.codes') {
      if (!isEmpty(value)) {
        const countryName = [];
        value.forEach((val) => { countryName.push(this.lookupApiService.getCountryNameById(val)); });
        return countryName;
      }
    } else if (template.control === 'company.location.states.codes') {
      if (!isEmpty(value)) {
        const stateName = [];
        value.forEach((val) => { stateName.push(this.lookupApiService.getStatesNameById(val)); });
        return stateName;
      }
    } else if (template.control === 'company.location.counties.codes') {
      if (!isEmpty(value)) {
        const countyName = [];
        value.forEach((val) => { countyName.push(this.lookupApiService.getCountyNameById(val)); });
        return countyName;
      }
    } else if ((template.control === 'company.phone' && template.name.toLowerCase() === 'company phone area code') ||
      (template.control === 'company.fax' && template.name.toLowerCase() === 'company fax area code')) {
      if (!isNil(value) && !isEmpty(value)) {
        const newValue = value.replace(/\D+/g, '');
        const valueLength = String(newValue).length;
        const areaCode = (valueLength === 10) ? String(newValue).slice(0, 3) : (valueLength === 3) ? newValue : '';
        return (areaCode.length === 3) ? areaCode : null;
      }
    } else if ((template.control === 'company.phone' && template.name.toLowerCase() === 'company phone') ||
      (template.control === 'company.fax' && template.name.toLowerCase() === 'company fax')) {
      if (!isNil(value) && !isEmpty(value)) {
        const newValue = value.replace(/\D+/g, '');
        const valueLength = String(newValue).length;
        const phone = (valueLength === 10) ? String(newValue).slice(3) : (valueLength === 7) ? newValue : '';
        return (phone.length === 7) ? phone : null;
      }
    } else {
      return (isEmpty(value)) ? null : value;
    }

    return null;
  }

  /**
   * Get applied filter object
   * @param {any} controlValue the value
   * @param {any} template control template
   * @returns {any} string or array
   */
  getFilterObject(controlValue: any, template: AppliedFilter): any {
    return {
      value: controlValue,
      control: template.control,
      name: template.name,
      showRemoveFilter: template.showRemoveFilter,
      order: template.order
    };
  }
}
