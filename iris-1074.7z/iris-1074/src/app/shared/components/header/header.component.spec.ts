import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { NgbModule, NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';
import { HeaderComponent } from './header.component';
import { FindInDropdowns } from '../../models/PageHeader';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BaseFormGroup } from '../../forms/base-form-group';
import { BaseFormControl } from '../../forms/base-form-control';
import { SharedModule } from '../../shared.module';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';
import * as headerdropdown from '../../config/headerdropdown.json';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let elements: DebugElement[];
  let dropdownConfig: NgbDropdownConfig;
  let findInDropdown: Array<FindInDropdowns>;
  let leftSidebarService: LeftSidebarService;
  let identifier: string;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule]
    }).compileComponents();

    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;

    dropdownConfig = fixture.debugElement.injector.get(NgbDropdownConfig);
    dropdownConfig.autoClose = 'outside';

    leftSidebarService = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'projectSearch';
    leftSidebarService.initMainForm(identifier);
    leftSidebarService.pushFormControlStatusList(leftSidebarFilter[identifier]);

    findInDropdown = (<any>headerdropdown).findInDropDown;
  }));

  it('should create', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should have filter dropdown from config', async(() => {
    fixture.detectChanges();
    expect(component.findInDropdown).toBe(findInDropdown);
  }));

  it('should have placehilder as "Find In"', async(() => {
    fixture.detectChanges();
    expect(component.placeholder).toBe('Find In');
  }));

  it('should have initialized "searchType" if page identifier is "projectSearch"', async(() => {
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.textSearchControl instanceof BaseFormControl).toBeTruthy();
    expect(component.textSearchOptionControl instanceof BaseFormControl).toBeTruthy();
    expect(component.textSearchFindInControl instanceof BaseFormControl).toBeTruthy();
    expect(component.textSearchFormGroup instanceof BaseFormGroup).toBeTruthy();
    expect(leftSidebarService.getMainForm.get('term')).toBeTruthy();
    expect(leftSidebarService.getMainForm.get('exactMatch')).toBeTruthy();
    expect(leftSidebarService.getMainForm.get('searchType')).toBeTruthy();
    expect(component.termPlaceholder).toBe('Search Projects');
    component.showDropdown.subscribe((res) => {
      expect(res).toBe(true);
    }).unsubscribe();
    component.ngOnDestroy();
  }));

  it('should not initialized "searchType" if page identifier is "companySearch"', async(() => {
    leftSidebarService.initMainForm('companySearch');
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.textSearchControl instanceof BaseFormControl).toBeTruthy();
    expect(component.textSearchOptionControl instanceof BaseFormControl).toBeTruthy();
    expect(component.textSearchFindInControl instanceof BaseFormControl).toBeTruthy();
    expect(component.textSearchFormGroup instanceof BaseFormGroup).toBeTruthy();
    expect(leftSidebarService.getMainForm.get('term')).toBeTruthy();
    expect(leftSidebarService.getMainForm.get('exactMatch')).toBeTruthy();
    expect(leftSidebarService.getMainForm.get('searchType')).toBeFalsy();
    expect(component.termPlaceholder).toBe('Search Companies');
    component.showDropdown.subscribe((res) => {
      expect(res).toBe(false);
    }).unsubscribe();
    component.ngOnDestroy();
  }));

  it('should call "resetAllForms" when mainFormReady is false', async(() => {
    spyOn(component, 'resetAllForms').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges();
    leftSidebarService.onDestroy();
    fixture.whenStable().then(() => {
      expect(component.resetAllForms).toHaveBeenCalled();
    });
    component.ngOnDestroy();
  }));

  it('should have initialized main form', async(() => {
    spyOn(leftSidebarService, 'initMainForm').and.callThrough();
    leftSidebarService.initMainForm(identifier);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(leftSidebarService.getMainForm instanceof BaseFormGroup).toBeTruthy();
      expect(leftSidebarService.initMainForm).toHaveBeenCalled();
      expect(leftSidebarService.getMainForm.get('term')).toBeTruthy();
      expect(leftSidebarService.getMainForm.get('exactMatch')).toBeTruthy();
      expect(leftSidebarService.getMainForm.get('searchType')).toBeTruthy();
    });
  }));

  it('shaould have default selected dropdown as "Entire Project"', async(() => {
    fixture.detectChanges();
    expect(component.selectedDropdownItem.label).toBe('Entire Project');
  }));

  it('shaould have default selected dropdown as first item of list', async(() => {
    component.findInDropdown.forEach((val) => { val.active = false; });
    fixture.detectChanges();
    expect(component.selectedDropdownItem).toEqual(component.findInDropdown[0]);
  }));

  it('should have "dropdown-item" button elements', async(() => {
    fixture.detectChanges();
    component.showDropdown.next(true);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      elements = fixture.debugElement.queryAll(By.css('div.dropdown-menu > button.dropdown-item'));
      expect(elements.length).toEqual(findInDropdown.length);
      elements.forEach((val, idx) => {
        const dom: HTMLElement = val.nativeElement;
        const value = dom.textContent;
        expect(value).toEqual(findInDropdown[idx].label);
      });
    });
  }));

  it('should have call "onItem" method on click of dropdow item', async(() => {
    fixture.detectChanges();
    component.showDropdown.next(true);
    fixture.detectChanges();
    spyOn(component, 'onItem').and.callThrough();
    component.findInDropdown[0].active = false;
    elements = fixture.debugElement.queryAll(By.css('div.dropdown-menu > button.dropdown-item'));
    elements[0].triggerEventHandler('click', null);
    component.findInDropdown[0].active = true;
    elements[0].triggerEventHandler('click', null);
    fixture.whenStable().then(() => {
      expect(component.onItem).toHaveBeenCalledTimes(2);
      expect(component.findInDropdown[0].active).toBeTruthy();
    });
  }));

  it('should call "onSearch" on clicking "Search" button', async(() => {
    fixture.detectChanges();
    spyOn(component, 'onSearch').and.callThrough();
    spyOn(leftSidebarService, 'searchTriggered').and.callThrough().and.stub();
    fixture.debugElement.query(By.css('#searchBtn')).triggerEventHandler('click', null);
    fixture.whenStable().then(() => {
      expect(component.onSearch).toHaveBeenCalled();
      expect(leftSidebarService.searchTriggered).toHaveBeenCalledWith(true, true);
    });
  }));

  it('should have call "ngOnDestroy"', async(() => {
    spyOn(component, 'ngOnDestroy').and.callThrough();
    component.ngOnInit();
    component.ngOnDestroy();
    fixture.whenStable().then(() => {
      expect(component.ngOnDestroy).toHaveBeenCalled();
      expect(component.clearFormSubscription).toBeDefined();
      expect(component.mainFormOnReadySubscription).toBeDefined();
      expect(component.clearFormSubscription.closed).toBe(true);
      expect(component.mainFormOnReadySubscription.closed).toBe(true);
    });
  }));

  it('should not reset form if control is null', async(() => {
    component.textSearchFormGroup.setValue({
      term: 'project',
      exactMatch: false,
      searchType: 'Project detail text'
    });
    leftSidebarService.triggerClearForm(null);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.textSearchFormGroup.get('term').value).toEqual('project');
      expect(component.textSearchFormGroup.get('exactMatch').value).toBeFalsy();
      expect(component.textSearchFormGroup.get('searchType').value).toEqual('Project detail text');
    });
  }));

  it('should reset form if control is "all"', async(() => {
    component.ngOnInit();
    component.textSearchFormGroup.setValue({
      term: 'project',
      exactMatch: false,
      searchType: 'Project detail text'
    });
    leftSidebarService.triggerClearForm('all');
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.textSearchFormGroup.get('term').value).toBe('');
      expect(component.textSearchFormGroup.get('exactMatch').value).toBeTruthy();
      expect(component.textSearchFormGroup.get('searchType').value).toEqual('Entire report');
    });
    component.ngOnDestroy();
  }));

  it('should reset term field', async(() => {
    component.ngOnInit();
    component.textSearchFormGroup.setValue({
      term: 'project',
      exactMatch: false,
      searchType: 'Project detail text'
    });
    leftSidebarService.triggerClearForm({ control: 'term', value: 'project' });
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.textSearchFormGroup.get('term').value).toBeFalsy();
    });
    component.ngOnDestroy();
  }));

  it('should reset searchType field', async(() => {
    component.ngOnInit();
    component.textSearchFormGroup.setValue({
      term: 'project',
      exactMatch: false,
      searchType: 'Project detail text'
    });
    leftSidebarService.triggerClearForm({ control: 'searchType', value: 'Project detail text' });
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.textSearchFormGroup.get('searchType').value).toBeFalsy();
      expect(component.selectedDropdownItem).toBeNull();
      component.findInDropdown.forEach(val => {
        expect(val.active).toBe(false);
      });
    });
    component.ngOnDestroy();
  }));

  it('should call "anyAllCheckHandler" when Any/All clicked', async(() => {
    spyOn(component, 'anyAllCheckHandler').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges();
    elements = fixture.debugElement.queryAll(By.css('.form-check-inline input'));
    elements[0].triggerEventHandler('click', null);
    fixture.whenStable().then(() => {
      expect(component.anyAllCheckHandler).toHaveBeenCalled();
    });
    component.ngOnDestroy();
  }));
});
