import { Component, Input, ChangeDetectionStrategy, OnInit, OnDestroy } from '@angular/core';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { BaseFormGroup } from '../../forms/base-form-group';
import { BaseFormControl } from '../../forms/base-form-control';
import { FindInDropdowns } from '../../models/PageHeader';
import { Subscription, BehaviorSubject } from 'rxjs';
import * as _ from 'lodash';
import * as headerdropdown from '../../config/headerdropdown.json';

/**
 * Header Component
 * Header component one input for FindIn dropdown and outputs two events search and save search on click of respective buttons
 */

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HeaderComponent implements OnInit, OnDestroy {
  // Search Text Form Group
  textSearchFormGroup: BaseFormGroup;
  // Search Text - Input Form Control
  textSearchControl: BaseFormControl;
  // Search Text - Radio Button Form Control
  textSearchOptionControl: BaseFormControl;
  // Search Text - FindIn dropdown Form Control
  textSearchFindInControl: BaseFormControl;
  // Select Dropdown Item
  selectedDropdownItem: FindInDropdowns;
  // Find In placeholder
  placeholder: string;
  // Show dropdown
  showDropdown: BehaviorSubject<boolean>;
  // Show Search Form
  showHeaderSearchForm: BehaviorSubject<boolean>;
  // Term placeholder text
  termPlaceholder: string;

  // Array of object, each object represent a primary or secondary dropdown item
  @Input() findInDropdown: Array<FindInDropdowns>;

  // Clear form subscription
  clearFormSubscription: Subscription;
  mainFormOnReadySubscription: Subscription;

  /**
   * Constructor
   * @param {NgbDropdownConfig} config config ng-angular modal configuration
   * @param {LeftSidebarService} leftSidebarService instance of LeftSidebarService
   */
  constructor(dropdownConfig: NgbDropdownConfig, public leftSidebarService: LeftSidebarService) {
    // Set autoClose of NgbDropdown on clicking anywhere outside
    dropdownConfig.autoClose = true;

    // Set default placehold
    this.placeholder = 'Find In';

    // Initialize termPlaceholder
    this.termPlaceholder = 'Search';

    // Initialize the Subject
    this.showDropdown = new BehaviorSubject<boolean>(false);

    // Initialize the Subject
    this.showHeaderSearchForm = new BehaviorSubject<boolean>(false);

    // Default dropdown
    this.findInDropdown = (<any>headerdropdown).findInDropDown;

    // Default selected Item
    const defaultActiveItem = this.findInDropdown.filter(val => val.active === true);
    this.selectedDropdownItem = (defaultActiveItem.length > 0) ? defaultActiveItem[0] : this.findInDropdown[0];

    this.textSearchControl = new BaseFormControl('Text Search', 'term', 'text', '', [], []);
    this.textSearchOptionControl = new BaseFormControl('Exact Match', 'exactMatch', 'radio', true, [], []);
    this.textSearchFindInControl = new BaseFormControl('FindIn', 'searchType', 'select', this.selectedDropdownItem.value, [], []);
    this.textSearchFormGroup = new BaseFormGroup('textSearchForm', {
      term: this.textSearchControl,
      exactMatch: this.textSearchOptionControl,
      searchType: this.textSearchFindInControl
    });
  }

  ngOnInit() {
    this.mainFormOnReadySubscription = this.leftSidebarService.mainFormReady$.subscribe((status) => {
      if (this.leftSidebarService.searchPageConfig) {
        this.showHeaderSearchForm.next(this.leftSidebarService.searchPageConfig.showHeaderSearch);
        this.showDropdown.next(this.leftSidebarService.searchPageConfig.showHeaderSearchDropdown);
        this.termPlaceholder = (this.leftSidebarService.searchPageConfig.termPlaceholder) ?
          this.leftSidebarService.searchPageConfig.termPlaceholder : '';

        if (this.leftSidebarService.searchPageConfig.showHeaderSearch) {
          if (status) {
            this.leftSidebarService.getMainForm.addControl('term', this.textSearchControl);
            this.leftSidebarService.getMainForm.addControl('exactMatch', this.textSearchOptionControl);
            if (this.leftSidebarService.searchPageConfig.showHeaderSearchDropdown) {
              this.leftSidebarService.getMainForm.addControl('searchType', this.textSearchFindInControl);
            } else {
              this.leftSidebarService.getMainForm.removeControl('searchType');
            }
          } else {
            this.resetAllForms();
            this.showHeaderSearchForm.next(false);
          }
        } else {
          this.leftSidebarService.getMainForm.removeControl('term');
          this.leftSidebarService.getMainForm.removeControl('exactMatch');
          this.leftSidebarService.getMainForm.removeControl('searchType');
        }
      }
    });

    // Reset field
    this.clearFormSubscription = this.leftSidebarService.clearForm$.subscribe((control) => {
      if (!_.isNil(control)) {
        if (_.isString(control)) {
          if (control === 'all') {
            this.resetAllForms();
          }
        } else if (_.isObject(control)) {
          if (control.control === 'term') {
            this.textSearchFormGroup.get('term').reset();
          } else if (control.control === 'searchType') {
            this.textSearchFormGroup.get('searchType').reset();
            this.selectedDropdownItem = null;
            this.findInDropdown.forEach(val => { val.active = false; });
          }
        }
      }
    });
  }

  ngOnDestroy() {
    if (this.clearFormSubscription) {
      this.clearFormSubscription.unsubscribe();
    }
    if (this.mainFormOnReadySubscription) {
      this.mainFormOnReadySubscription.unsubscribe();
    }
  }

  /**
   * Search button click event listner
   * @listens HeaderComponent~search
   */
  public onSearch() {
    this.leftSidebarService.searchTriggered(true, true);
  }

  /**
   * Listens to click of dropdown button click and set the active property of the specific dropdown object to true/false
   * @param {number} itemIndex index of dropdown item object in dropdown array
   *
  */
  public onItem(itemIndex: number) {
    if (!this.findInDropdown[itemIndex].active) {
      this.findInDropdown.forEach(val => val.active = false);
      this.findInDropdown[itemIndex].active = true;
      this.selectedDropdownItem = this.findInDropdown[itemIndex];
      this.textSearchFindInControl.setValue(this.selectedDropdownItem.value);
    }
  }

  /**
   * Change event handler for exactMacth checkbox
   * @param event the event object
   */
  anyAllCheckHandler(value: boolean) {
    this.textSearchFormGroup.get('exactMatch').setValue(value);
  }

  /** Reset All form */
  resetAllForms() {
    this.textSearchFormGroup.reset({
      term: '',
      exactMatch: true,
      searchType: 'Entire report'
    });
    this.findInDropdown[0].active = true;
    this.selectedDropdownItem = this.findInDropdown[0];
  }

  /**
   * logout user
   */
  // invalidate() {
  //   localStorage.removeItem('DODGEAUTH');
  //   document.location.href = this.createLoginUrl();
  //   return false;
  // }

  /**
   * Create a SSO login URL
   */
  // private createLoginUrl(): string {
  //   return `${environment.ssoUrl}/login?returnUrl=${environment.siteUrl}/login`;
  // }
}
