import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LeftSidebarService } from '../../../shared/services/left-sidebar.service';
import { GridComponent } from '../grid/grid.component';
import { SumoLoggerService } from '../../../shared/services/sumo-logger.service';
import { RerouteProjectPopupComponent } from './../../../feed-content/reroute-project-popup/reroute-project-popup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MarkCompletePopupComponent } from '../../../feed-content/mark-complete-popup/mark-complete-popup.component';
import { ApiService } from '../../services/api.service';
import { RerouteActionResponse, RerouteActionRequest } from '../../models/RerouteAPI';
import { MarkFeedRequest } from '../../models/MarkFeedAPI';
import { ConfirmationDialogService } from './../../services/confirmation-dialog.service';
/**
 * Data grid actions New, Print, Export
 */
@Component({
  selector: 'app-grid-action-buttons',
  templateUrl: './grid-action-buttons.component.html',
  styleUrls: ['./grid-action-buttons.component.scss']
})
export class GridActionButtonsComponent implements OnInit {

  // Data grid instance
  @Input() grid: GridComponent;

  // Main form group identifier
  @Input() pageIdentifier: string;

  // Main form group identifier
  @Input() backRoute: string;

  // Page title
  title = '';
  fileName = '';
  feedId: string;

  constructor(public leftSidebarService: LeftSidebarService, private logger: SumoLoggerService, private modalService: NgbModal,
    public apiService: ApiService, public confirmationDialogService: ConfirmationDialogService, private router: Router,
    private activatedRoute: ActivatedRoute) {
    // Get feed Id
    this.activatedRoute.paramMap.subscribe((params) => {
      this.feedId = params.get('id');
    });
  }

  ngOnInit() {
    if (this.pageIdentifier === 'projectSearch') {
      this.title = 'Projects';
      this.fileName = 'Project Search';
    } else if (this.pageIdentifier === 'companySearch') {
      this.title = 'Companies';
      this.fileName = 'Company Search';
    } else if (this.pageIdentifier === 'feedContent') {
      this.title = 'Feed Content';
      this.fileName = 'EFeed Data';
    } else if (this.pageIdentifier === 'disposition') {
      this.title = 'Disposition';
      this.fileName = 'Disposition Data';
    } else if (this.pageIdentifier === 'qualification-tool') {
      this.title = 'Qualification Tool';
      this.fileName = 'Qualification Tool Data';
    } else if (this.pageIdentifier === 'editFeed' || this.pageIdentifier === 'createFeedProject') {
      this.title = 'Edit Feed';
      this.fileName = 'Edit Feed Data';
    }
  }

  /**
   * Export to CSV file functionality
   */
  export() {
    if (this.grid.selected.length === 0) {
      if (['projectSearch', 'companySearch'].includes(this.pageIdentifier)) {
        const offset = 0;
        const limit = 10000;
        this.exportAll(offset, limit);
      } else {
        this.grid.export(this.grid.rows, this.fileName);
      }

    } else {
      this.grid.export(this.grid.selected, this.fileName);
    }
  }
  /**
   * Export the records in the batch of 10000
   * @param offset Offset
   * @param limit Limit per file
   */
  public exportAll(offset, limit) {
    let total, start, count;
    this.leftSidebarService.export(offset, limit).subscribe(
      (res) => {
        if (this.pageIdentifier === 'projectSearch') {
          this.grid.export(res.data.projects, this.fileName);
        } else if (this.pageIdentifier === 'companySearch') {
          this.grid.export(res.data.companies, this.fileName);
        }
        total = res.data.metaData.total;
        start = res.data.metaData.start;
        count = res.data.metaData.count;
        offset = start + count - 1;
        if (offset < total) {
          this.exportAll(offset, limit);
        }
      },
      (err) => {
        this.logger.error(err);
      }
    );
    offset = offset + limit;
  }
  /**
   * Print
   */
  print() {
    this.grid.print(`${this.title} Search Result`);
  }
  /**
  * Reroute Project
  */
  rerouteProject() {
    // Get data from reroute popup
    this.showReroutePopup().then((response: RerouteActionRequest) => {
      // if response is not null
      if (response) {
        // add project ids to request from grid
        response.projects = this.grid.selected.map(x => parseInt(x.id, 0));
        // call api
        this.apiService.put('feed/reroute', response).subscribe((data: RerouteActionResponse) => {
          this.leftSidebarService.searchTriggered(true, true);
        },
          (err) => {
            this.logger.error(err);
          });
      }
    });
  }
  /**
   * show reroute popup
   */
  showReroutePopup() {
    const promise = new Promise((resolve, reject) => {
      const modalRef = this.modalService.open(RerouteProjectPopupComponent, { backdrop: 'static' });
      modalRef.result.then((result) => {
        resolve(result);
      }).catch((error) => {
        reject(error);
      });
    });
    return promise;
  }
  /**
  * Mark Compelte
  */
  markComplete() {
    // if one item is selected in grid then first get DR number associated with record
    if (this.grid.selected.length === 1) {
      // call api and get dr number
      this.apiService.get('feed/drnumber').subscribe((data: any) => {
        // if status is success then show mark complete popup
        this.showMarkCompletePopup(data.data.drnumber).then((reason: MarkFeedRequest) => {
          // update mark status
          this.updateMarkCompleteStatus(reason);
        });
      },
        (err) => {
          this.logger.error(err);
        });
    } else {
      // if more than one item is selected then show popup only
      this.showMarkCompletePopup(0).then((reason: MarkFeedRequest) => {
        // update mark reason
        this.updateMarkCompleteStatus(reason);
      });
    }
  }
  /**
   * Update mark complete status
   * @param response data from popup
   */
  updateMarkCompleteStatus(response: MarkFeedRequest) {
    response.projects = this.grid.selected.map(x => x.id);
    this.apiService.put('feed/complete', response).subscribe((data: any) => {
      // if status is success then update grid
      this.leftSidebarService.searchTriggered(true, true);
    },
      (err) => {
        this.logger.error(err);
      });
  }

  /**
   * show Unmark complete popup
   */
  showUnmarkCompletePopup() {
    // Unmark complete logic
    this.confirmationDialogService.confirm('Please confirm..', 'Do you want to unmark selected project?')
      .then((confirmed) => confirmed ? this.unMarkProject() : null)
      .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  }
  /**
   * unmark project
   */
  unMarkProject() {
    if (this.grid.selected.length === 1) {
      const feedNumber = this.grid.selected[0].projectId;
      if (feedNumber) {
        this.apiService.put(`feed/${feedNumber}/uncomplete`, {}).subscribe((data: any) => {
          // if status is success then update grid
          this.leftSidebarService.searchTriggered(true, true);
        },
          (err) => {
            this.logger.error(err);
          });
      }
    }
  }
  /**
     * show Mark complete popup with DR number
     */
  showMarkCompletePopup(DRNumber?: number) {
    const promise = new Promise((resolve, reject) => {
      const modalRef = this.modalService.open(MarkCompletePopupComponent, { backdrop: 'static' });
      modalRef.componentInstance.DRNumber = DRNumber;
      modalRef.result.then((result) => {
        resolve(result);
      }).catch((error) => {
        reject(error);
      });
    });
    return promise;
  }

  /**
   * Create Project
   */
  createProject() {
    this.router.navigate(['/feed/' + this.feedId + '/create']);
  }

  /**
   * Edit Project
   */
  editProject() {
    this.router.navigate(['/feed/' + this.feedId + '/edit']);
  }

  /**
   * Back to feed
   */
  backToFeed() {
    if (this.backRoute) {
      this.router.navigate([this.backRoute]);
    }
  }
}
