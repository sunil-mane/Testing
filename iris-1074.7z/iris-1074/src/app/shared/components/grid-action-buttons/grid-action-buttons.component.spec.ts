import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SharedModule } from '../../../shared/shared.module';
import { GridActionButtonsComponent } from './grid-action-buttons.component';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { CompanySearch } from '../../../../mocks/companySearch';
import { GridComponent } from '../grid/grid.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { of as observableOf, Observable } from 'rxjs';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from '../../../reducers';

describe('GridActionButtonsComponent', () => {
  let component: GridActionButtonsComponent;
  let fixture: ComponentFixture<GridActionButtonsComponent>;
  const companyReq = {
    url: 'company/search',
    body: {
      'pagination': {'limit': 100, 'offset': 0}
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), NgbModule.forRoot(), RouterTestingModule, StoreModule.forRoot(reducers, { metaReducers })],
      providers: [LocationStrategy, PathLocationStrategy]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridActionButtonsComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call "export" method', () => {
    const spy = spyOn(component.leftSidebarService, 'export').and.returnValue(observableOf(CompanySearch.getCompanies(companyReq, 2)));
    component.grid = TestBed.createComponent(GridComponent).componentInstance;
    const spy2 = spyOn(component.grid, 'export');
    component.pageIdentifier = 'companySearch';
    component.ngOnInit();
    component.export();
    expect(component.leftSidebarService.export).toHaveBeenCalledTimes(1);
    expect(component.grid.export).toHaveBeenCalledTimes(1);
  });

  it('should call "print" method', () => {
    component.grid = TestBed.createComponent(GridComponent).componentInstance;
    const spy = spyOn(component.grid, 'print');
    component.pageIdentifier = 'projectSearch';
    component.ngOnInit();
    component.print();
    expect(component.grid.print).toHaveBeenCalledTimes(1);
  });

});
