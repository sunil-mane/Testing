import { Component, Input, HostBinding, ChangeDetectionStrategy } from '@angular/core';

/**
 * Load Overlay Component
 *
 * Displays a reusable loading indicator overlay. It is meant to be a
 * common component that may be used inside other components to provide
 * a consistent load wait experience.
 */
@Component({
  selector: 'app-load-overlay',
  templateUrl: './load-overlay.component.html',
  styleUrls: ['./load-overlay.component.scss']
})
export class LoadOverlayComponent {


  /**
   * Overlay height
   */
  @Input() @HostBinding('style.height') height: string;

  /**
   * Overlay width
   */
  @Input() @HostBinding('style.width') width: string;

  /**
   * Overlay background color
   */
  @Input() @HostBinding('style.backgroundColor') background: string;

  /**
   * Overlay position from top
   */
  @Input() @HostBinding('class.top') indicatorAtTop = false;

  /**
   * Whether to show indicator spinner
   */
  @Input() indicator = true;

  /**
   * Whether to show progress indicator
   */
  @Input() progress: number | boolean = false;

  /**
   * Progress text
   */
  @Input() progressText: string | null = null;

  /**
   * Progress total
   */
  @Input() progressTotal: number | null = 100;

  /**
   * Calculates progress percentage based on input.
   */
  get percentage(): number {
    return false === this.progress
      ? 100
      : Math.round((+this.progress / this.progressTotal) * 100);
  }

}
