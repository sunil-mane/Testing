import { Component, OnInit, OnDestroy } from '@angular/core';
import { Alert, AlertType } from '../../models/Alert';
import { AlertService } from '../../services/alert.service';
import { Subscription } from 'rxjs';

/**
 * The Alert component controls the adding and removing of alerts.  It maintains an arry of alerts that are displayed by the component
 * template.
 */

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements OnInit, OnDestroy {
  alerts: Alert[] = [];
  subscription: Subscription;

  constructor(private alertService: AlertService) { }

  ngOnInit() {
    this.subscription = this.alertService.getAlert().subscribe((alert: Alert) => {
      if (!alert) {
        // clear alerts when an empty alert is received
        this.alerts = [];
        return;
      }
      this.alerts.push(alert);
    });
  }

  removeAlert(alert: Alert) {
    this.alerts = this.alerts.filter(x => x !== alert);
  }

  getMetadata(alert: Alert) {
    if (!alert) {
      return;
    }

    // return css class based on alert type
    switch (alert.type) {
      case AlertType.Success:
        return { cssClass: 'alert alert-success', icon: 'check-circle' };
      case AlertType.Error:
        return { cssClass: 'alert alert-danger', icon: 'exclamation-circle' };
      case AlertType.Info:
        return { cssClass: 'alert alert-info', icon: 'info-circle' };
      case AlertType.Warning:
        return { cssClass: 'alert alert-warning', icon: 'exclamation-triangle' };
    }
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
