import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AlertComponent } from './alert.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { Alert, AlertType } from '../../models/Alert';
import { AlertService } from '../../services/alert.service';
import { Subject } from 'rxjs/Subject';


describe('AlertComponent', () => {
  let component: AlertComponent;
  let fixture: ComponentFixture<AlertComponent>;
  let alertService: AlertService;
  let routerMock;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([])
      ],
      declarations: [
        AlertComponent
      ],
      providers: [
        AlertService
      ]
    });
    fixture = TestBed.createComponent(AlertComponent);
    component = fixture.componentInstance;
    alertService = TestBed.get(AlertService);
    routerMock = TestBed.get(RouterTestingModule);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have alerts', () => {
    component.ngOnInit();
    alertService.success('Success');
    fixture.detectChanges();
    expect(component.alerts.length).toEqual(1);
  });

  it('should not have alerts', () => {
    component.ngOnInit();
    alertService.clear();
    fixture.detectChanges();
    expect(component.alerts.length).toEqual(0);
  });

  it('should not return alert type css class', () => {
    fixture.detectChanges();
    expect(component.getMetadata(null)).toBeFalsy();
  });

  it('should remove alert', () => {
    component.ngOnInit();
    alertService.success('Success');
    alertService.error('Error');
    fixture.detectChanges();
    component.removeAlert(component.alerts[0]);
    expect(component.alerts.length).toEqual(1);
  });

  it('alert type should be success', () => {
    alertService.success('Success');
    expect(component.getMetadata({ type: AlertType.Success, message: 'Success' }).cssClass).toEqual('alert alert-success');
  });

  it('alert type should be warning', () => {
    alertService.success('Warning');
    expect(component.getMetadata({ type: AlertType.Warning, message: 'Warning' }).cssClass).toEqual('alert alert-warning');
  });

  it('alert type should be info', () => {
    alertService.success('Info');
    expect(component.getMetadata({ type: AlertType.Info, message: 'Info' }).cssClass).toEqual('alert alert-info');
  });

  it('alert type should be error', () => {
    alertService.success('Error');
    expect(component.getMetadata({ type: AlertType.Error, message: 'Error' }).cssClass).toEqual('alert alert-danger');
  });

});
