import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatePickerComponent } from './date-picker.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from './../../shared.module';

describe('DatePickerComponent', () => {
  let component: DatePickerComponent;
  let fixture: ComponentFixture<DatePickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), NgbModule.forRoot()],
      declarations: []
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should initialize variables', () => {
    component.model = { year: 2018, month: 2, day: 2 };
    expect(component.model).toBeTruthy();
    fixture.whenStable().then(() => {
      expect(component.value).toBeTruthy();
      expect(component.value).toBe('02/02/2018');
    });
  });
  it('should write value when writeValue is called', async(() => {
    component.model = { year: 2018, month: 2, day: 2 };
    component.writeValue('02-01-2018');
    fixture.whenStable().then(() => {
      expect(component.value).toBeTruthy();
      expect(component.value).toBe('02/01/2018');
      expect(component.model.year).toEqual(2018);
    });
  }));
  it('should write value when date select is called', async(() => {
    component.model = { year: 2018, month: 2, day: 2 };
    component.onDateSelect({});
    fixture.whenStable().then(() => {
      expect(component.value).toBeTruthy();
      expect(component.value).toBe('02/02/2018');
    });
  }));
  it('should set disabled when set disabled is called', async(() => {
    component.setDisabledState(true);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.disabled).toBe(true);
    });
  }));
  it('should set invalid date when year below 1000 is set', async(() => {
    component.model = { year: 18, month: 2, day: 2 };
    component.writeValue('01/01/18');
    component.validateDate('01/01/18');
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.model).toBe(null);
    });
  }));
});
