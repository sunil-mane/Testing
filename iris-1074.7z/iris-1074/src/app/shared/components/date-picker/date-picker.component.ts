import { Component, HostListener, Injectable, ViewChild, ElementRef, Input, forwardRef, OnInit, AfterViewInit } from '@angular/core';
import * as moment from 'moment';
import { NgbDateParserFormatter, NgbDateStruct, NgbInputDatepicker, NgbDatepicker } from '@ng-bootstrap/ng-bootstrap';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { environment } from '../../../../environments/environment';
import * as textMask from 'vanilla-text-mask/dist/vanillaTextMask.js';
import { PlacementArray } from '@ng-bootstrap/ng-bootstrap/util/positioning';

const DATE_FORMAT = environment.defaultDateFormat;
const API_FORMAT = environment.apiDateFormat;
/**
 * function to convert string date to bootstrap NgbDateStruct object
 * @param {string} date
 * @returns {NgbDateStruct | null}
 */
function dateToStruct(date: string): NgbDateStruct | null {
  if (!date) { return null; }
  let oDate = moment.utc(date, DATE_FORMAT);
  // check if current date is in API date format
  if (moment(date, API_FORMAT, true).isValid()) {
    oDate = moment.utc(date, API_FORMAT);
  }

  return {
    year: oDate.year(),
    month: oDate.month() + 1,
    day: oDate.date() || 1,
  };
}

/**
 * function to convert bootstrap NgbDateStruct object to moment utc time
 * @param {NgbDateStruct} struct
 * @returns {moment.Moment}
 */
function structToMoment(struct: NgbDateStruct): moment.Moment {
  if (struct != null) {
    return moment.utc([struct.year, struct.month - 1, struct.day || 1]);
  }
}

/**
 * A custom date formatter to override the bootstrap datepicker's basic implementation
 */

@Injectable()
export class DateParserFormatter extends NgbDateParserFormatter {

  parse(value: string): NgbDateStruct {
    return dateToStruct(value);
  }

  format(date: NgbDateStruct): string {
    if (!date) { return ''; }
    return structToMoment(date).format(DATE_FORMAT);
  }
}

const noop = () => { };

/**
 * A date component where user can either enter or select the date from a calendar popup.
 */

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.scss'],
  providers: [{ provide: NgbDateParserFormatter, useClass: DateParserFormatter },
  { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => DatePickerComponent), multi: true }]
})

export class DatePickerComponent implements ControlValueAccessor, OnInit, AfterViewInit {

  private onTouchedCallback: () => void = noop;
  private onChangedCallback: (_: any) => void = noop;

  public disabled: boolean;
  public model: NgbDateStruct;
  mask = [/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/];
  maskedInputController;
  /** Min date for the navigation. If not provided, 'year' select box will display 10 years before current month */
  @Input() minDate: NgbDateStruct;

  /** Max date for the navigation. If not provided, 'year' select box will display 10 years after current month*/
  @Input() maxDate: NgbDateStruct;

  /** placeholder string to display in the input box. */
  @Input() placeholder: string;

  /** Datepick placement */
  @Input() placement: PlacementArray;

  /** Dom Element references */
  @ViewChild('input') private input: ElementRef;
  @ViewChild('icon') private icon: ElementRef;
  @ViewChild('d') private datepicker: NgbInputDatepicker;

  /**
   * Handles datepicker closing when an outside click is detected.
   *
   * @param event Mouse event
   */
  @HostListener('document:click', ['$event']) onOutsideClick(event: MouseEvent) {
    // if control is not disabled
    if (!this.disabled) {
      // if datepicker is open then check for value
      if (this.datepicker.isOpen()) {
        const dpInstance = (this.datepicker as any)._cRef.instance; // TS hack to allow private member access
        const elRef: ElementRef = dpInstance._elementRef;

        if (
          this.input.nativeElement !== event.target &&
          this.icon.nativeElement !== event.target &&
          !this.icon.nativeElement.contains(event.target) &&
          !elRef.nativeElement.contains(event.target)
        ) {
          this.datepicker.close();
          event.stopPropagation();
        }
      }
      // if not and icon is clicked then open date picker
      if (!this.datepicker.isOpen()) {
        if (this.icon.nativeElement === event.target &&
          this.icon.nativeElement.contains(event.target)
        ) {
          this.datepicker.open();
        }
      }
    }
  }

  /**
   * Handles datepicker keypress event when keys are pressed on input box.
   *
   * @param event Mouse event
   */
  @HostListener('keyup', ['$event']) handleDeleteKeyboardEvent(event: KeyboardEvent) {
    // if text is empty or text is not a vaid date then do not update
    if (this.input.nativeElement.value.length && structToMoment(this.model).format(DATE_FORMAT) !== 'Invalid date') {
      this.onChangedCallback(structToMoment(this.model).format(API_FORMAT));
      // for onblur event
      this.onTouchedCallback();
    } else {
      // update form with empty string
      this.onChangedCallback('');
      // for onblur event
      this.onTouchedCallback();
    }
  }
  /**
   * Bind keyup event to textbox to bind space key event.
   *
   */
  onKeyUp(event) {
    if (event.code === 'Space') {
      if (!this.disabled) {
      this.datepicker.toggle();
      this.bindKeyboardEvent('keyup');
      }
    }
  }
  /**
   * Bind keyboard event to datepicker so that it can be hidden when focus/escape is removed.
   *
   */
  bindKeyboardEvent(eventName: string) {
    // bind event once datepicker is open
    setTimeout(() => {
      // get instance of datepicker.
      let dpInstance = (this.datepicker as any); // TS hack to allow private member access
      if (dpInstance && dpInstance._cRef) {
        dpInstance = dpInstance._cRef.instance;
        const elRef: ElementRef = dpInstance._elementRef;
        // bind blur event and if picker is open then hide it.
        elRef.nativeElement.addEventListener(eventName, (event: any) => {
          if (!elRef.nativeElement.contains(event.relatedTarget) && this.datepicker.isOpen()) {
            this.datepicker.close();
          } else {
            if (elRef.nativeElement.contains(event.relatedTarget)) {
              // bind event to inner element so that it will also close popup on focus lost
              event.relatedTarget.addEventListener(eventName, (event1: any) => {
                if (!elRef.nativeElement.contains(event1.relatedTarget) && this.datepicker.isOpen()) {
                  this.datepicker.close();
                }
              });
            }
          }
        });
      }
    }, 500);
  }
  /**
   * After view init of angular lifecycle
   *
   */
  ngAfterViewInit(): void {
    // create mask once input is displayed
    setTimeout(() => {
      this.maskedInputController = textMask.maskInput({
        inputElement: this.input.nativeElement,
        mask: this.mask,
        pipe: createAutoCorrectedDatePipe()
      });
    });
  }
  /**
   * Handles onBlur event for textbox.
   */
  onBlurMethod() {
    this.validateDate(this.input.nativeElement.value);
    if (this.model) {
      this.onChangedCallback(structToMoment(this.model).format(API_FORMAT));
      // for onblur event
      this.onTouchedCallback();
    }
  }

  /**
   * This method do the following validations:
   * MM: 1 to 12, single digit accepted pad with leading 0 (zero)
   * DD: 1 to 31, single digit accepted pad with leading 0 (zero)
   * YYYY: Any 4 digit number accepted, single digit pad with leading 200,
   * double digit pad with 20, 3 digits clear the field, any 4 digits are allowed.
   *
   * @param {string} date
   */
  validateDate(date: string) {
    // if text is there but the value is not valid date then empty textbox
    const dateLength = this.input.nativeElement.value.length;
    if (dateLength) {
      // if 7 digits are entered then date is set before 1000, in this case, remove date as it is invalid
      if (this.model.year < 1000 && this.model.year > 10) {
        this.input.nativeElement.value = '';
        this.model = null;
        // update form with empty string
        this.onChangedCallback('');
        // for onblur event
        this.onTouchedCallback();
      } else {
        // if parsed date is invalid
        if (structToMoment(this.model).format(DATE_FORMAT) === 'Invalid date') {
          this.input.nativeElement.value = '';
          this.model = null;
          // update form with empty string
          this.onChangedCallback('');
          // for onblur event
          this.onTouchedCallback();
          return;
        } else {
          // if date is valid but year is not then change year to 2000
          const lastchar = date.slice(date.length - 2, date.length);
          if (parseInt(lastchar, 0) < 10) {
            this.model.year = parseInt('20' + lastchar, 0);
            this.input.nativeElement.value = structToMoment(this.model).format(DATE_FORMAT);
          }
        }
        // if date is not in range then clear the field
        if (this.minDate && this.maxDate) {
          const minDate = structToMoment(this.minDate);
          const maxDate = structToMoment(this.maxDate);
          const selectedDate = structToMoment(this.model);
          if (selectedDate.isBefore(minDate) || selectedDate.isAfter(maxDate)) {
            this.input.nativeElement.value = '';
            this.model = null;
            // update form with empty string
            this.onChangedCallback('');
            // for onblur event
            this.onTouchedCallback();
          }
        }
      }
    } else {
      // invalid date
      this.input.nativeElement.value = '';
      this.model = null;
      // update form with empty string
      this.onChangedCallback('');
      // for onblur event
      this.onTouchedCallback();
    }
  }

  constructor() {
    // Enable dropdown by default
    this.disabled = false;
  }

  ngOnInit(): void {
    // this.disabled = false;
    // this.disabled = this.isDisabled;
  }

  /**
   * Control value accessor methods.
   */
  get value(): string {
    if (!this.model) { return ''; }
    return structToMoment(this.model).format(DATE_FORMAT);
  }

  /**
   * Control value accessor  registerOnChange event.
   */
  registerOnChange(fn: any): void {
    this.onChangedCallback = fn;
  }

  /**
   * Control value accessor  registerOnTouched event.
   */
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  /**
   * Control value accessor  writeValue event.
   */
  writeValue(obj: any): void {
    if (obj) {
      this.model = dateToStruct(obj);
    } else {
      this.input.nativeElement.value = '';
      this.model = null;
      this.onTouchedCallback();
      this.onChangedCallback('');
    }
  }

  /**
   * Date select callback .
   *
   * @param evt data from datepicker
   */
  onDateSelect(evt: any) {
    if (evt) {
      this.onChangedCallback(structToMoment(this.model).format(API_FORMAT));
      // for onblur event
      this.onTouchedCallback();

      return structToMoment(this.model).format(DATE_FORMAT);
    }
  }

  /**
   * set disabled property to given value .
   *
   * @param isDisabled true or false.
   */
  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

}
/**
 * Pipe for date picker mask.
 *
 * @param isDisabled true or false.
 */
const maxValueMonth = [31, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const formatOrder = ['yyyy', 'yy', 'mm', 'dd', 'HH', 'MM', 'SS'];
/**
 * Function for pipe to create default date formatting.
 *
 * @param isDisabled true or false.
 */
export default function createAutoCorrectedDatePipe(dateFormat = 'mm dd yyyy', {
  minYear = 1,
  maxYear = 9999
} = {}) {
  // split day and month from format
  const dateFormatArray = dateFormat
    .split(/[^dmyHMS]+/)
    .sort((a, b) => formatOrder.indexOf(a) - formatOrder.indexOf(b));
  // return function
  return function (conformedValue) {
    const indexesOfPipedChars = [];
    const maxValue = { 'dd': 31, 'mm': 12, 'yy': 99, 'yyyy': maxYear, 'HH': 23, 'MM': 59, 'SS': 59 };
    const minValue = { 'dd': 1, 'mm': 1, 'yy': 0, 'yyyy': minYear, 'HH': 0, 'MM': 0, 'SS': 0 };
    const conformedValueArr = conformedValue.split('');

    // Check first digit
    dateFormatArray.forEach((format) => {
      const position = dateFormat.indexOf(format);
      const maxFirstDigit = parseInt(maxValue[format].toString().substr(0, 1), 10);

      if (parseInt(conformedValueArr[position], 10) > maxFirstDigit) {
        conformedValueArr[position + 1] = conformedValueArr[position];
        conformedValueArr[position] = 0;
        indexesOfPipedChars.push(position);
      }
    });

    // Check for invalid date
    let month = 0;
    const isInvalid = dateFormatArray.some((format) => {
      const position = dateFormat.indexOf(format);
      const length = format.length;
      const textValue = conformedValue.substr(position, length).replace(/\D/g, '');
      const value = parseInt(textValue, 10);
      if (format === 'mm') {
        month = value || 0;
      }
      const maxValueForFormat = format === 'dd' ? maxValueMonth[month] : maxValue[format];
      if (format === 'yyyy' && (minYear !== 1 || maxYear !== 9999)) {
        const scopedMaxValue = parseInt(maxValue[format].toString().substring(0, textValue.length), 10);
        const scopedMinValue = parseInt(minValue[format].toString().substring(0, textValue.length), 10);
        return value < scopedMinValue || value > scopedMaxValue;
      }
      return value > maxValueForFormat || (textValue.length === length && value < minValue[format]);
    });

    if (isInvalid) {
      return false;
    }

    return {
      value: conformedValueArr.join(''),
      indexesOfPipedChars
    };
  };
}
