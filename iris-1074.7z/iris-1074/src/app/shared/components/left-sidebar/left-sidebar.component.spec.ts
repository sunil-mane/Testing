import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { LeftSidebarComponent } from './left-sidebar.component';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { SharedModule } from '../../shared.module';
import { FilterDropdown } from '../../models/LeftSidebar';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';

@Component({
  selector: 'app-test',
  template: `<app-left-sidebar #leftSidebar [pageIdentifier]="pageIdentifier" (visibleChange)="onVisibleChange(status)">
  <ng-template appIrisAccordion title="Project Search" id="projectSearchForm" [isActive]="true"></ng-template>
  <ng-template appIrisAccordion title="Project Address" id="projectAddressForm" [isActive]="true"></ng-template>
  <ng-template appIrisAccordion title="Other Project Info" id="otherProjectInfoForm" [isActive]="false"></ng-template>
  <ng-template appIrisAccordion title="Company/Contact Info" id="companyInfoForm" [isActive]="false"></ng-template>
  <ng-template appIrisAccordion title="Company/Contact Address" id="companyAddressForm" [isActive]="false"></ng-template>
  </app-left-sidebar>`
})
class TestComponent {
  pageIdentifier: string;
  hideShow: boolean;

  @ViewChild('leftSidebar') leftSidebar: LeftSidebarComponent;

  constructor() {
    this.pageIdentifier = 'projectSearch';
  }

  onVisibleChange(status) {
    this.hideShow = status;
  }
}

describe('LeftSidebarComponent with TestComponet', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let leftSidebarComponent: LeftSidebarComponent;
  let leftSidebarService: LeftSidebarService;
  let element: DebugElement;
  let elements: DebugElement[];
  let dom: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule],
      declarations: [TestComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    leftSidebarComponent = component.leftSidebar;
    leftSidebarService = fixture.debugElement.injector.get(LeftSidebarService);
  }));

  it('should create', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should initialize mainform, applied filters and form control status', async(() => {
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(leftSidebarService.getMainForm).toBeDefined();
    });
  }));

  it('should not have any active accordion if contentChecked is true', async(() => {
    fixture.detectChanges();
    leftSidebarComponent.contentChecked = true;
    leftSidebarComponent.activeAccordions = [];
    leftSidebarComponent.getActiveAccordionIds();
    fixture.whenStable().then(() => {
      expect(leftSidebarComponent.activeAccordions.length).toBe(0);
    });
  }));

  it('should have any active accordion if contentChecked is false', async(() => {
    fixture.detectChanges();
    leftSidebarComponent.contentChecked = false;
    leftSidebarComponent.activeAccordions = [];
    leftSidebarComponent.getActiveAccordionIds();
    fixture.whenStable().then(() => {
      expect(leftSidebarComponent.activeAccordions.length).toBe(2);
    });
  }));

  it('should display left sidebar by default', async(() => {
    fixture.detectChanges();
    element = fixture.debugElement.query(By.css('.aside-content'));
    dom = element.nativeElement;
    expect(dom.classList.contains('d-none')).toBe(false);
    expect(leftSidebarComponent.hideAside).toBe(false);
  }));

  it('should hide leftsidebar', async(() => {
    fixture.detectChanges();
    spyOn(leftSidebarComponent, 'toggleAside').and.callThrough();
    element = fixture.debugElement.query(By.css('.aside-button'));
    element.triggerEventHandler('click', null);
    fixture.whenStable().then(() => {
      expect(leftSidebarComponent.hideAside).toBe(true);
      expect(leftSidebarComponent.toggleAside).toHaveBeenCalledTimes(1);
    });
  }));

  it('should show leftsidebar', async(() => {
    spyOn(leftSidebarComponent, 'toggleAside').and.callThrough();
    const body: HTMLElement = document.getElementsByTagName('body')[0];
    body.classList.add('leftsibar-filter-closed');
    leftSidebarComponent.hideAside = true;
    fixture.detectChanges();
    element = fixture.debugElement.query(By.css('.aside-button'));
    element.triggerEventHandler('click', null);
    fixture.whenStable().then(() => {
      expect(leftSidebarComponent.hideAside).toBe(false);
      expect(leftSidebarComponent.toggleAside).toHaveBeenCalledTimes(1);
    });
  }));

  it('should trigger search', async(() => {
    fixture.detectChanges();
    spyOn(leftSidebarComponent, 'search').and.callThrough();
    spyOn(leftSidebarService, 'searchTriggered').and.callThrough().and.stub();
    element = fixture.debugElement.query(By.css('#leftSidebarSearchButton'));
    element.triggerEventHandler('click', null);
    fixture.whenStable().then(() => {
      expect(leftSidebarComponent.search).toHaveBeenCalled();
      expect(leftSidebarService.searchTriggered).toHaveBeenCalledWith(true, true);
    });
  }));

  it('should change on click of filter', async(() => {
    fixture.detectChanges();
    spyOn(leftSidebarComponent, 'onFilterItemClick').and.callThrough();
    spyOn(leftSidebarService, 'changeFormControlActiveStatus').and.callThrough();
    element = fixture.debugElement.query(By.css('.dropdown-item'));
    dom = element.nativeElement;
    dom.click();
    fixture.whenStable().then(() => {
      expect(leftSidebarComponent.onFilterItemClick).toHaveBeenCalled();
      expect(leftSidebarService.changeFormControlActiveStatus).toHaveBeenCalled();
    });
  }));

  it('should not display the accordion whose title do not match config', async(() => {
    const projectSearch: FilterDropdown[] = leftSidebarFilter[component.pageIdentifier];
    projectSearch[0].displayName = 'Test Title';
    leftSidebarService.pushFormControlStatusList(projectSearch);
    fixture.detectChanges();
    elements = fixture.debugElement.queryAll(By.css('.accordion .card'));
    expect(elements.length).toBe(4);
  }));

  it('searchPageConfig should be empty if page Identifier is null', async(() => {
    component.pageIdentifier = null;
    leftSidebarComponent.ngOnDestroy();
    leftSidebarComponent.ngOnInit();
    fixture.detectChanges();
    expect(leftSidebarService.searchPageConfig).toBeUndefined();
  }));
});
