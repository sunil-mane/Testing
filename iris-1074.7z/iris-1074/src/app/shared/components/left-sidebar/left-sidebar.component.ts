import {
  Component, ContentChildren, QueryList, Input, OnInit, ChangeDetectionStrategy, OnDestroy, AfterContentChecked,
  Renderer2, Output, EventEmitter, OnChanges, SimpleChanges
} from '@angular/core';
import { IrisAccordionDirective } from '../../directives/iris-accordion.directive';
import { LeftSidebarService } from '../../services/left-sidebar.service';
import { Observable, Observer } from 'rxjs';
import { findIndex, isEmpty, isNil } from 'lodash';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';
import * as leftSidebarFilter from '../../config/leftsidebarfilter.json';
import { FilterDropdownItems } from '../../models/LeftSidebar';
/**
 * This component contains the left sidebar, filter forms, filter dropdow and clear all link.
 */
@Component({
  selector: 'app-left-sidebar',
  exportAs: 'appLeftSidebar',
  templateUrl: './left-sidebar.component.html',
  styleUrls: ['./left-sidebar.component.scss'],
  providers: [NgbDropdownConfig],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LeftSidebarComponent implements OnInit, OnDestroy, AfterContentChecked, OnChanges {
  /** Boolean property for show/hide left sidebar */
  hideAside: boolean;

  // Active Accordions
  activeAccordions: Array<string>;

  // Main form group identifier
  @Input() pageIdentifier: string;

  /** Boolean Input for show/hide left sidebar */
  @Input() hideOrShowAside: boolean;

  /** Hide and Show */
  @Output() visibleChange: EventEmitter<boolean>;

  contentChecked: boolean;
  /**
   * Get all content children which are left sidebar accordion
   */
  @ContentChildren(IrisAccordionDirective) accordions: QueryList<IrisAccordionDirective>;

  /**
   * Constructor
   */
  constructor(dropdownConfig: NgbDropdownConfig, public leftSideBarService: LeftSidebarService, private renderer: Renderer2) {
    // Set initial value as false as by default left sidebar is visible
    this.hideAside = false;

    // Set initial value to empty array
    this.activeAccordions = [];

    // Set to false and set it to true in ngActerContentChecked
    this.contentChecked = false;

    // autoClose to outside
    dropdownConfig.autoClose = 'outside';

    // Initialize event
    this.visibleChange = new EventEmitter<boolean>();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['hideOrShowAside']) {
      this.hideShowAside(changes['hideOrShowAside'].currentValue);
    }
  }

  ngOnInit() {
    if (!isNil(this.pageIdentifier)) {
      // Init mainForm
      this.leftSideBarService.initMainForm(this.pageIdentifier);
      // Push filter config
      this.leftSideBarService.pushFormControlStatusList(leftSidebarFilter[this.pageIdentifier]);
    }
  }

  ngAfterContentChecked() {
    this.getActiveAccordionIds();
  }

  ngOnDestroy() {
    this.leftSideBarService.onDestroy();
    const body = document.getElementsByTagName('body')[0];
    if (body.classList.contains('leftsibar-filter-closed')) {
      this.renderer.removeClass(body, 'leftsibar-filter-closed');
    }
  }

  /**
   * This method binded to the click event of angled double arrow button.
   */
  toggleAside() {
    const body = document.getElementsByTagName('body')[0];
    if (body.classList.contains('leftsibar-filter-closed')) {
      this.renderer.removeClass(body, 'leftsibar-filter-closed');
    } else {
      this.renderer.addClass(body, 'leftsibar-filter-closed');
    }
    // Set value true/false
    this.hideAside = !this.hideAside;

    // Emit event
    this.visibleChange.emit(this.hideAside);
    this.leftSideBarService.changeVisibility(this.hideAside);
  }

  hideShowAside(hideOrShow: boolean) {
    const body = document.getElementsByTagName('body')[0];
    const showAside = (isNil(hideOrShow)) ? true : hideOrShow;

    // Add or remove class from body element
    if (showAside) {
      this.renderer.removeClass(body, 'leftsibar-filter-closed');
    } else {
      this.renderer.addClass(body, 'leftsibar-filter-closed');
    }

    // Set value true/false
    this.hideAside = !showAside;

    // Emit event
    this.visibleChange.emit(this.hideAside);
    this.leftSideBarService.changeVisibility(this.hideAside);
  }

  /**
   * Trigger search
   */
  search() {
    this.leftSideBarService.searchTriggered(true, true);
  }

  /**
   * Filter Accordion item based on Form Control Active status
   * @returns {Observable<Array<IrisAccordionDirective>>} Array of IrisAccordionDirective as Observable
   */
  filteredAccordion(): Observable<Array<IrisAccordionDirective>> {
    return Observable.create((observer: Observer<Array<IrisAccordionDirective>>) => {
      this.leftSideBarService.formControlActiveStatus$.subscribe(
        (status) => {
          let accordions: Array<IrisAccordionDirective>;
          if (isEmpty(status)) {
            accordions = this.accordions.filter(accordion => true);
          } else {
            accordions = this.accordions.filter((accordion) => {
              const groupIndex = findIndex(status, item => item.displayName === accordion.title);
              if (groupIndex >= 0) {
                return status[groupIndex].active;
              } else {
                return false;
              }
            });
          }
          observer.next(accordions);
        }
      );
    });
  }

  onFilterItemClick(event: MouseEvent, parentIndex: number, childIndex?: number) {
    this.leftSideBarService.changeFormControlActiveStatus(parentIndex, childIndex);
    event.preventDefault();
    event.stopPropagation();
  }

  /**
   * TrackBy for filter dropdow
   * @param {number} index index of the item
   * @param {FilterDropdownItems} item downdown item
   */
  filterDropdownTrackBy(index: number, item: FilterDropdownItems) {
    return item.active;
  }

  /**
   * Get active accordion ids
   */
  getActiveAccordionIds() {
    if (!this.contentChecked) {
      this.accordions.forEach((accordion) => {
        if (accordion.isActive) {
          this.activeAccordions.push('leftSidebar-' + accordion.id);
        }
      });
      this.contentChecked = true;
    }
  }

  /**
   * This helps to trigger change when value changes in left sidebar service.
   */
  get disableSearchButton(): boolean {
    return this.leftSideBarService.loadingStatus;
  }
}
