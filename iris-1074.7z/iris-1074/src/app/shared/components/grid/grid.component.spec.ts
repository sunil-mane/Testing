import { async, ComponentFixture, TestBed, tick, fakeAsync, getTestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { By } from '@angular/platform-browser';
import { GridComponent } from './grid.component';
import { SharedModule } from '../../shared.module';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from '../../../reducers';
/** Angular Third Party Modules */
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ApiService } from '../../services/api.service';
import { ProjectSearch } from '../../../../mocks/projectSearch';
import { CompanySearch } from '../../../../mocks/companySearch';

describe('GridComponent', () => {
  let component: GridComponent;
  let fixture: ComponentFixture<GridComponent>;
  let injector;
  let service: ApiService;
  let httpMock: HttpTestingController;

  const projectReq = {
    url: 'project/search'
  };

  const companyReq = {
    url: 'company/search'
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SharedModule.forRoot(),
        NgbModule.forRoot(),
        RouterTestingModule,
        HttpClientTestingModule,
        StoreModule.forRoot(reducers, { metaReducers })
      ],
      declarations: [
      ],
      providers: [LocationStrategy, PathLocationStrategy]
    })
      .compileComponents();
    injector = getTestBed();
    service = injector.get(ApiService);
    httpMock = injector.get(HttpTestingController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('should display No data to display when there is no data', async(() => {
    const dummyProjects: any[] = [];

    service.post('project/search', {}).subscribe((res: any[]) => {
      fixture.whenStable().then(() => {
        expect(By.css('empty-row').length).toBeGreaterThan(0);
      });
    });

    const request = httpMock.expectOne('https://api.dodgedev.com/cc/iris/project/search');
    expect(request.request.method).toBe('POST');
    request.flush(dummyProjects);
    httpMock.verify();
  }));

  it('should display project search results in data grid', () => {
    const dummyProjects: any[] = ProjectSearch.getProjects(projectReq, 2).data.projects;
    service.post(projectReq.url, {}).subscribe((res: any[]) => {
      expect(res.length).toBe(2);
      expect(res).toEqual(dummyProjects);
      component.rows = dummyProjects;
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(By.css('datatable-body-row').length).toBeGreaterThan(0);
      });
    });

    const request = httpMock.expectOne('https://api.dodgedev.com/cc/iris/project/search');
    expect(request.request.method).toBe('POST');
    request.flush(dummyProjects);
    httpMock.verify();
  });

  it('should go to given page number', () => {
    const dummyProjects: any[] = ProjectSearch.getProjects(projectReq, 102).data.projects;
    service.post(projectReq.url, {}).subscribe((res: any[]) => {
      component.rows = dummyProjects;
      component.ngOnInit();
      component.page(2);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(By.css('datatable-body-row').length).toBeGreaterThan(0);
      });
    });

    const request = httpMock.expectOne('https://api.dodgedev.com/cc/iris/project/search');
    expect(request.request.method).toBe('POST');
    request.flush(dummyProjects);
    httpMock.verify();
  });

  it('should call "print" method', () => {
    const spy = spyOn(component.util, 'printJSON');
    const dummyProjects: any[] = ProjectSearch.getProjects(projectReq, 2).data.projects;
    component.rows = dummyProjects;
    component.columns = [
      { name: 'TITLE', name2: 'Title', prop: 'name', isVisible: true, type: 'projectTitle', width: 500 },
      { name: 'ISSUE DATE', name2: 'IssueDate', prop: 'issuedDate', isVisible: true, type: 'date' },
      { name: 'PROJECT STAGE', name2: 'ProjectStage', prop: 'stage', isVisible: true },
      { name: 'PROJECT #', name2: 'Project', prop: 'id', isVisible: true },
      { name: 'VERSION #', name2: 'VersionNumber', prop: 'version', isVisible: true, width: 100 },
      { name: 'STATE', name2: 'State', prop: 'state', isVisible: true },
      { name: 'COMPANIES', name2: 'Companies', prop: 'company', isVisible: true, width: 100, type: 'companies' },
    ];
    component.ngOnChanges({});
    component.print('Title');
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('should call "print" for all selected row ', () => {
    const spy = spyOn(component.util, 'printJSON');
    const dummyProjects: any[] = ProjectSearch.getProjects(projectReq, 2).data.projects;
    component.rows = dummyProjects;
    component.columns = [
      { name: 'TITLE', name2: 'Title', prop: 'name', isVisible: true, type: 'projectTitle', width: 500 },
      { name: 'ISSUE DATE', name2: 'IssueDate', prop: 'issuedDate', isVisible: true, type: 'date' },
      { name: 'PROJECT STAGE', name2: 'ProjectStage', prop: 'stage', isVisible: true },
      { name: 'PROJECT #', name2: 'Project', prop: 'id', isVisible: true },
      { name: 'VERSION #', name2: 'VersionNumber', prop: 'version', isVisible: true, width: 100 },
      { name: 'STATE', name2: 'State', prop: 'state', isVisible: true },
      { name: 'COMPANIES', name2: 'Companies', prop: 'company', isVisible: true, width: 100, type: 'companies' },
    ];
    component.ngOnChanges({});
    component.selectAll(true);
    component.print('Title');
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('should call "print" for selected row ', () => {
    const spy = spyOn(component.util, 'printJSON');
    const dummyProjects: any[] = ProjectSearch.getProjects(projectReq, 2).data.projects;
    component.rows = dummyProjects;
    component.columns = [
      { name: 'TITLE', name2: 'Title', prop: 'name', isVisible: true, type: 'projectTitle', width: 500 },
      { name: 'ISSUE DATE', name2: 'IssueDate', prop: 'issuedDate', isVisible: true, type: 'date' },
      { name: 'PROJECT STAGE', name2: 'ProjectStage', prop: 'stage', isVisible: true },
      { name: 'PROJECT #', name2: 'Project', prop: 'id', isVisible: true, type: 'project' },
      { name: 'VERSION #', name2: 'VersionNumber', prop: 'version', isVisible: true, width: 100 },
      { name: 'STATE', name2: 'State', prop: 'state', isVisible: true },
      { name: 'COMPANIES', name2: 'Companies', prop: 'company', isVisible: true, width: 100, type: 'companies' },
    ];
    component.ngOnChanges({});
    component.select({ selected: dummyProjects[0] });
    component.print('Title');
    expect(spy).toHaveBeenCalledTimes(1);
  });


  it('should call "export" method', () => {
    const spy = spyOn(component.util, 'exportToExcel');
    const dummyCompanies: any[] = CompanySearch.getCompanies(companyReq, 2).data.companies;
    component.rows = dummyCompanies;
    component.columns = [
      { name: 'COMPANY', name2: 'Company', prop: 'name', isVisible: true, width: 500, type: 'companyTitle' },
      { name: 'SOURCE', name2: 'Source', prop: 'source', isVisible: true, width: 100, type: 'source' },
      { name: 'COMPANY CODE', name2: 'CompanyCode', prop: 'code', isVisible: true },
      { name: 'LAST UPDATE', name2: 'LastUpdate', prop: 'lastUpdate', isVisible: true, type: 'date' },
      { name: 'PROJECT', name2: 'Project', prop: 'project', isVisible: true, width: 100, type: 'projects' },
    ];
    component.ngOnChanges({});
    component.export(dummyCompanies, 'Company Search');
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('should initialize row information', () => {
    const dummyProjects: any[] = ProjectSearch.getProjects(projectReq, 2).data.projects;
    const row = dummyProjects[0];
    component.information = [
      { name: 'DR #', prop: 'id' },
      { name: 'Title', prop: 'name' }
    ];
    component.onIconMouseOver(row);
    expect(component.rowInformation).toBeTruthy();
  });

});
