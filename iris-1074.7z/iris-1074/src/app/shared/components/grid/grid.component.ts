import {
  Component, ViewEncapsulation, OnInit, Input, ViewChild, OnChanges,
  SimpleChanges, Output, EventEmitter, TemplateRef, ElementRef, HostBinding
} from '@angular/core';
import { Router } from '@angular/router';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { GridColumn } from '../../models/GridColumn';
import { UtilService } from '../../services/util.service';
import { RightSlidepanelService } from './../../services/right-slidepanel.service';
import { cloneDeep } from 'lodash';
import { OrderPipe } from '../../pipe/order.pipe';
import { Store } from '@ngrx/store';
import { AppState } from '../../store/app-state';
import * as feedContentActions from '../../store/feed-content/feed-content.actions';

/**
 * Common grid component
 */

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class GridComponent implements OnChanges, OnInit {

  /** Row information */
  public rowInformation = [];

  /** Page identifier */
  @Input() pageIdentifier = '';

  /** Server side pagination off by default */
  @Input() externalPaging = false;

  /** Show hide settings column */
  @Input() isSettingsApplicable = true;

  /** Hide and show information icon */
  @Input() isInformationOnMouseOver = true;

  /** Grid column definitions */
  @Input() columns: GridColumn[];

  /** Extra columns for export */
  @Input() columnsForExport: GridColumn[] = [];

  /** Grid column definitions */
  private columnsOptions: GridColumn[];

  /** Information on mouse over */
  @Input() information: GridColumn[];

  /** Whether grid is loading */
  @Input() loading = false;

  /** Number of rows to show per page */
  @Input() limit = 100;

  /** Total rows count */
  @Input() total = 0;

  /** Offset of current row set */
  @Input() offset = 0;

  /** Grid internal offset */
  iOffset = 0;

  _rows: any[] = [];

  /** Grid data */
  @Input('rows')
  get rows() {
    return this._rows;
  }

  set rows(value) {
    this._rows = value;
  }

  /** Whether to use single or multiple sort columns. */
  @Input() sortType: 'single' | 'multi' = 'single';

  /** Default sort columns */
  @Input() sorts = [];

  /** Whether the pagination limit is applicable */
  @Input() isPaginationLimitVisible = true;

  /** Whether the pagination is applicable */
  @Input() isPaginationVisible = true;

  /** Whether record selection is applicable */
  @Input() isRecordSelectionApplicable = true;

  /** Previous selection cahche */
  previouslySelected: any[] = [];

  /** Selected rows */
  selected: any[] = [];

  /** Grid Messages */
  messages: any;

  /** Is Form value empty */
  @Input() searchStatus: string;

  /** NG Datatable component reference */
  @ViewChild(DatatableComponent) grid: DatatableComponent;

  /** To get the user selected row */
  @Output() recordSelected: EventEmitter<any[]> = new EventEmitter<any[]>();

  /** For server side pagination*/
  @Output() pageChanged: EventEmitter<number> = new EventEmitter<number>();

  /** For server side sorting */
  @Output() sortChanged: EventEmitter<number> = new EventEmitter<number>();

  @ViewChild('companiesTemplate') companiesTemplate: TemplateRef<any>;
  @ViewChild('dateTemplate') dateTemplate: TemplateRef<any>;
  @ViewChild('phoneTemplate') phoneTemplate: TemplateRef<any>;
  @ViewChild('companyTitleTemplate') companyTitleTemplate: TemplateRef<any>;
  @ViewChild('projectTitleTemplate') projectTitleTemplate: TemplateRef<any>;
  @ViewChild('feedTitleTemplate') feedTitleTemplate: TemplateRef<any>;
  @ViewChild('projectsTemplate') projectsTemplate: TemplateRef<any>;
  @ViewChild('sourceTemplate') sourceTemplate: TemplateRef<any>;
  @ViewChild('contactEmailTemplate') contactEmailTemplate: TemplateRef<any>;
  @ViewChild('contactTitleTemplate') contactTitleTemplate: TemplateRef<any>;

  @HostBinding('class') componentClass: string;

  constructor(public util: UtilService, public rightPanelService: RightSlidepanelService, public el: ElementRef,
    public router: Router, public store: Store<AppState>) {
    this.componentClass = 'app-grid';
  }

  /**
   * Setup data on init
   */
  ngOnInit(): void {
    this.messages = {
      // Message to show when array is presented
      // but contains no values
      emptyMessage: 'No data to display',

      // Footer total message
      totalMessage: 'total'
    };
  }

  /**
   * Re-render table data when changes are detected
   */
  ngOnChanges(changes: SimpleChanges): void {
    // Deep copy
    if (!this.columnsOptions) {
      this.columns.forEach((item) => {
        if (item.type) {
          switch (item.type) {
            case 'date':
              item.cellTemplate = this.dateTemplate;
              item.childTemplate = this.dateTemplate;
              break;
            case 'phone':
              item.cellTemplate = this.phoneTemplate;
              item.childTemplate = this.phoneTemplate;
              break;
            case 'companies':
              item.cellTemplate = this.companiesTemplate;
              break;
            case 'projects':
              item.cellTemplate = this.projectsTemplate;
              break;
            case 'projectTitle':
              item.cellTemplate = this.projectTitleTemplate;
              break;
            case 'companyTitle':
              item.cellTemplate = this.companyTitleTemplate;
              item.childTemplate = this.contactTitleTemplate;
              break;
            case 'feedTitle':
              item.cellTemplate = this.feedTitleTemplate;
              break;
            case 'source':
              item.cellTemplate = this.sourceTemplate;
              break;
            case 'email':
              item.childTemplate = this.contactEmailTemplate;
              break;
            default:
              item.cellTemplate = null;
              break;
          }
        }
        const cssClass = 'datatable-header-cell-label';
        item.minWidth = this.util.getTextWidth(item.name, cssClass) + 40;
      });

      this.columnsOptions = cloneDeep(this.columns);
    }

    if (changes['searchStatus']) {
      const message = {
        emptyMessage: this.searchStatus,
        totalMessage: 'total'
      };
      this.messages = message;
    }
    if (changes['loading']) {
      this.rightPanelService.showRightPanel = false;
      const el = this.el.nativeElement.querySelector('.datatable-row-center');
      if (el) {
        el.style.transform = 'translate3d(0px, 0px, 0px)';
      }
    }
  }

  /**
   * Handle sort event
   */

  sort(event) {
    if (!this.externalPaging) {
      this.iOffset = 0;
      this.offset = 0;
    }
    this.sortChanged.emit(event);
  }

  /**
   * Handle data selection
   *
   * @param param0 Selected data
   */
  select({ selected }): void {
    this.selected = selected;
    this.recordSelected.emit(this.selected);
  }

  /**
   * Select all projects
   *
   * @param allSelected Whether we are selecting or deselecting rows
   */
  selectAll(allSelected: boolean): void {
    this.previouslySelected = [...this.selected];
    this.selected = allSelected && this.rows ? [...this.rows] : [];
    this.recordSelected.emit(this.selected);
  }

  /**
   * Paginate to page number
   *
   * @param page Page number
   */
  page(page: number): void {
    this.offset = Math.floor((page - 1) * this.limit);
    this.iOffset = page - 1;
    if (this.externalPaging) {
      this.pageChanged.emit(page);
    }
  }

  /**
   * Track row by identifier
   *
   * @param row Grid row data
   */
  identifyRow(row: any): string | number {
    return row.id;
  }

  /**
   * Show more information of individual Projects which is in search result on mouse over
   * @param row Row information JSON object
   */
  onIconMouseOver(row) {
    this.rowInformation.length = 0;
    this.rowInformation = this.util.formatDataForMouseOver(row, this.information);
  }

  /**
   * Toggle display state of a given grid column
   *
   * @param name Column name, index
   */
  toggleColumn(name: string, index: number): void {
    this.columns[index].isVisible = !this.columns[index].isVisible;
  }

  /**
   * Reset columns
   */
  resetColumns(): void {
    this.columns = cloneDeep(this.columnsOptions);
  }

  toggleExpandRow(row) {
    this.grid.rowDetail.toggleExpandRow(row);
  }

  /**
   * Export to Excel
   * @param rows Data to export
   * @param fileName CSV file name
   */
  export(rows, fileName: string) {
    const headers = [];
    let columns = cloneDeep(this.columns);
    columns = [...columns, ...this.columnsForExport];
    columns = new OrderPipe().transform(columns, 'order');
    columns.forEach(col => {
      if (col.type === 'companies' || col.type === 'projects' || col.type === 'source') {
        // Ignore
      } else {
        headers.push(col.name2);
      }
    });
    const data = this.util.formatDataForPrint(rows, columns, 'export');
    this.util.exportToExcel(data, fileName, { headers });
  }
  /**
   * Print
   */
  print(title: string) {
    const props = [];
    let rows = [];
    if (this.selected.length > 0) {
      rows = this.selected;
    } else {
      rows = this.rows;
    }
    this.columns.filter(col => col.isVisible).forEach(col => {
      if (col.type === 'companies' || col.type === 'projects' || col.type === 'source') {
        // Ignore
      } else {
        props.push(col.name);
      }
    });
    const data = this.util.formatDataForPrint(rows, this.columns.filter(col => col.isVisible), 'print');
    this.util.printJSON(data, props, title);
  }

  /**
   * Handle column reordering
   */
  reorder({ column, newValue, prevValue }: any): void {
    // We must remove fixed columns from the calculation.
    let subtractor = this.isRecordSelectionApplicable ? 1 : 0;
    subtractor = this.isSettingsApplicable ? subtractor + 1 : subtractor;
    let previousIndex = prevValue - subtractor;
    let newIndex = newValue - subtractor;
    const cols = this.columns.map((col) => {
      return { ...col };
    });

    // Put the column to the right of fixed columns.
    if (0 > newIndex) { newIndex = 0; }

    // In case of hidden columns
    previousIndex = this.getIndex(previousIndex, cols);
    newIndex = this.getIndex(newIndex, cols);

    if (newIndex > previousIndex) {
      const movedCol = cols[previousIndex];
      for (let i = previousIndex; i < newIndex; i++) {
        cols[i] = cols[i + 1];
      }
      cols[newIndex] = movedCol;
    } else {
      const movedCol = cols[previousIndex];
      for (let i = previousIndex; i > newIndex; i--) {
        cols[i] = cols[i - 1];
      }
      cols[newIndex] = movedCol;
    }
    this.columns = cols;
  }

  /**
   * Calculate index considering hidden columns
   * @param index Current index
   * @param columns Grid columns
   */
  getIndex(index: number, columns: GridColumn[]): number {
    let newIndex = index;
    columns.forEach((col, i) => {
      if (!col.isVisible && i <= index) {
        newIndex++;
      }
    });
    return newIndex;
  }
  /**
   * Open qualification tool
   */
  openQualificationTool(row: any) {
    this.store.dispatch(new feedContentActions.SaveFeedContentAction({ name: this.pageIdentifier, value: row }));
    this.router.navigate([`/feed/${row.id || row.projectId}/qualification/matched`]);
  }

}
