/**
 * Pagination Component
 *
 * Accepts incoming pagination criteria and creates a paginator based
 * on input. Has callback event handlers to signal to parent component
 * that a pagination page change has occurred.
 *
 */
import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PaginationComponent {

  /**
   * Total number of paginated records.
   */
  @Input() total: number;

  /**
   * Current beginning number for paginated records.
   */
  @Input() offset: number;

  /**
   * Number of records to show per page.
   */
  @Input() limit: number;

  /**
   * Page change event emitter.
   */
  @Output() pageChange = new EventEmitter<number>();

  /**
   * Calculates and returns the active page number.
   */
  getCurrentPage(): number {
    return Math.ceil(((this.offset / this.limit) || 0) + 1);
  }

  /**
   * Calculates and returns the last page number.
   */
  getLastPage(): number {
    return Math.ceil(this.total / this.limit);
  }

  /**
   * Tests if given page is the active page.
   *
   * @param page Page comparator
   */
  isCurrentPage(page: number): boolean {
    return page === this.getCurrentPage();
  }

  /**
   * Callback handler for pagination item click.
   *
   * @param page Clicked page number
   */
  onPageClick(page: number): void {
    this.pageChange.emit(page);
  }

  /**
   * Callback handler for last page pagination item click.
   */
  onPreviousPageClick(): void {
    this.pageChange.emit(this.getCurrentPage() - 1);
  }

  /**
   * Callback handler for next page pagination item click.
   */
  onNextPageClick(): void {
    this.pageChange.emit(this.getCurrentPage() + 1);
  }

  /**
   * Returns an array containing pages to be displayed.
   */
  getPagesToShow(): number[] {
    const currentPage = this.getCurrentPage();
    const pages = [currentPage];

    if (1 !== currentPage) {
      pages.unshift(currentPage - 1);
    }

    if (this.getLastPage() > currentPage) {
      pages.push(currentPage + 1);
    }

    return pages;
  }
}
