import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PaginationComponent } from './pagination.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core/src/debug/debug_node';
import { Observable } from 'rxjs/Observable';

describe('PaginationComponent', () => {
  let component: PaginationComponent;
  let paginator: DebugElement;
  let fixture: ComponentFixture<PaginationComponent>;
  let items: DebugElement[];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PaginationComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('100 result paginator with 10 page limit on page 1', () => {

    beforeEach(setup(100, 10, 0));

    it('should have active page 1 as first item', () => {
      expect(items[0].nativeElement.textContent).toContain('1');
      expect(items[0].nativeElement.className).toContain('active');
    });

    it('should have page 2 as second item', () => {
      expect(items[1].nativeElement.textContent).toContain('2');
    });

    it('should have disabled … as third item', () => {
      expect(items[2].nativeElement.textContent).toContain('…');
      expect(items[2].nativeElement.className).toContain('disabled');
    });

    it('should have page 10 as fourth item', () => {
      expect(items[3].nativeElement.textContent).toContain('10');
    });

    it('should have › as fifth item', () => {
      expect(items[4].nativeElement.textContent).toContain('›');
    });
  });

  describe('100 result paginator with 10 page limit on page 2', () => {

    beforeEach(setup(100, 10, 10));

    it('should have ‹ as first item', () => {
      expect(items[0].nativeElement.textContent).toContain('‹');
    });

    it('should have page 1 as second item', () => {
      expect(items[1].nativeElement.textContent).toContain('1');
    });

    it('should have active page 2 as third item', () => {
      expect(items[2].nativeElement.textContent).toContain('2');
      expect(items[2].nativeElement.className).toContain('active');
    });

    it('should have page 3 as fourth item', () => {
      expect(items[3].nativeElement.textContent).toContain('3');
    });

    it('should have disabled … as fifth item', () => {
      expect(items[4].nativeElement.textContent).toContain('…');
      expect(items[4].nativeElement.className).toContain('disabled');
    });

    it('should have page 10 as sixth item', () => {
      expect(items[5].nativeElement.textContent).toContain('10');
    });

    it('should have › as seventh item', () => {
      expect(items[6].nativeElement.textContent).toContain('›');
    });
  });

  describe('100 result paginator with 10 page limit on page 4', () => {

    beforeEach(setup(100, 10, 30));

    it('should have disabled … as third item', () => {
      expect(items[2].nativeElement.textContent).toContain('…');
      expect(items[2].nativeElement.className).toContain('disabled');
    });

    it('should have active page 4 as fifth item', () => {
      expect(items[4].nativeElement.textContent).toContain('4');
      expect(items[4].nativeElement.className).toContain('active');
    });

    it('should have disabled … as seventh item', () => {
      expect(items[6].nativeElement.textContent).toContain('…');
      expect(items[6].nativeElement.className).toContain('disabled');
    });
  });

  describe('100 result paginator with 10 page limit on page 10', () => {

    beforeEach(setup(100, 10, 90));

    it('should have active page 10 as last item', () => {
      const lastItem = items[items.length - 1];
      expect(lastItem.nativeElement.textContent).toContain('10');
      expect(lastItem.nativeElement.className).toContain('active');
    });
  });

  describe('5 result paginator with 10 page limit', () => {

    beforeEach(setup(5, 10, 0));

    it('should not be displayed', () => {
      expect(paginator).toBeNull();
    });
  });

  // Private functions

  function setup(total: number, limit: number, offset: number) {
    return () => {
      fixture = TestBed.createComponent(PaginationComponent);
      component = fixture.componentInstance;

      // Manual input binding
      component.total = total;
      component.limit = limit;
      component.offset = offset;

      fixture.detectChanges();

      paginator = fixture.debugElement.query(By.css('ul.pagination'));

      if (paginator) {
        items = paginator.children;
      }
    };
  }

});
