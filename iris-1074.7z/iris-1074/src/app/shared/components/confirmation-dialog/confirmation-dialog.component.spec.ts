import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationDialogComponent } from './confirmation-dialog.component';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from './../../shared.module';

describe('ConfirmationDialogComponent', () => {
  let component: ConfirmationDialogComponent;
  let fixture: ComponentFixture<ConfirmationDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), NgbModule.forRoot()],
      providers: [NgbActiveModal]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should close modal when decline is called ', async () => {
    const spy = spyOn(component.activeModal, 'close').and.callThrough();
    component.decline();
    expect(spy).toHaveBeenCalledWith(false);
  });
  it('should close modal when accept is called ', async () => {
    const spy = spyOn(component.activeModal, 'close').and.callThrough();
    component.accept();
    expect(spy).toHaveBeenCalledWith(true);
  });
  it('should close modal when dismiss is called ', async () => {
    const spy = spyOn(component.activeModal, 'dismiss').and.callThrough();
    component.dismiss();
    expect(spy).toHaveBeenCalled();
  });
});
