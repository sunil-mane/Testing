import { Component, Input } from '@angular/core';
import { PageTabNavigation } from '../../models/PageTabNavigation';

@Component({
  selector: 'app-content-tab-navigation',
  templateUrl: './content-tab-navigation.component.html',
  styleUrls: ['./content-tab-navigation.component.scss']
})
export class ContentTabNavigationComponent {

  /** Tab Configuration */
  @Input() tabs: PageTabNavigation[];

  constructor() {
    this.tabs = [];
  }
}
