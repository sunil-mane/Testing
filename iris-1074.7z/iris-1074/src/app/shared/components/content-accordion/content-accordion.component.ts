import { Component, ContentChildren, QueryList, AfterContentChecked } from '@angular/core';
import { IrisAccordionDirective } from '../../directives/iris-accordion.directive';
import { LeftSidebarLinks } from '../../models/LeftSidebar';

@Component({
  selector: 'app-content-accordion',
  templateUrl: './content-accordion.component.html',
  styleUrls: ['./content-accordion.component.scss']
})
export class ContentAccordionComponent implements AfterContentChecked {
  /** Active Accordions */
  activeAccordions: Array<string>;

  /** Flag for content checked */
  contentChecked: boolean;

  /** Links of left sidebar */
  linksForLeftSidebar: LeftSidebarLinks[];

  /*** Get all content children which are left sidebar accordion  */
  @ContentChildren(IrisAccordionDirective) accordions: QueryList<IrisAccordionDirective>;

  constructor() {
    // Set initial value to empty array
    this.activeAccordions = [];
    this.linksForLeftSidebar = [];

    // Set initial value to false
    this.contentChecked = false;
  }

  ngAfterContentChecked() {
    this.getActiveAccordionIdsAndLinksForLeftSidebar();
  }

  /**
   * Get active accordion ids
   */
  getActiveAccordionIdsAndLinksForLeftSidebar() {
    if (!this.contentChecked) {
      this.accordions.forEach((accordion) => {
        // Create links array
        this.linksForLeftSidebar.push({
          label: accordion.title,
          panelId: 'irisContentAccordion-' + accordion.id + '-header'
        });

        if (accordion.isActive) {
          // Set Active links
          this.activeAccordions.push('irisContentAccordion-' + accordion.id);
        }
      });
      this.contentChecked = true;
    }
  }
}
