import { Component, Input, Inject } from '@angular/core';
import { LeftSidebarLinks } from '../../models/LeftSidebar';
import { DOCUMENT } from '@angular/common';
import { PageScrollService, PageScrollInstance } from 'ngx-page-scroll';

@Component({
  selector: 'app-left-sidebar-links',
  templateUrl: './left-sidebar-links.component.html',
  styleUrls: ['./left-sidebar-links.component.scss']
})
export class LeftSidebarLinksComponent {

  /** Links array */
  @Input() links: LeftSidebarLinks[];

  /** Container Id of scroll object */
  @Input() container: string;

  /** Page scroll offset */
  @Input() pageScrollOffset: number;

  constructor(private pageScrollService: PageScrollService, @Inject(DOCUMENT) private document: any) {
    this.links = [];
  }

  scrollToContent(id: string) {
    const pageScrollInstance: PageScrollInstance = PageScrollInstance.newInstance({
      document: this.document,
      scrollTarget: '#' + id,
      scrollingViews: [this.document.getElementById(this.container)],
      pageScrollOffset: this.pageScrollOffset,
      pageScrollDuration: 500
    });
    this.pageScrollService.start(pageScrollInstance);
  }
}
