import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../shared.module';
import { TreeviewModule } from 'ngx-treeview';

import { LeftSidebarLinksComponent } from './left-sidebar-links.component';

describe('LeftSidebarLinksComponent', () => {
  let component: LeftSidebarLinksComponent;
  let fixture: ComponentFixture<LeftSidebarLinksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(), SharedModule.forRoot(), TreeviewModule.forRoot(), RouterTestingModule, HttpClientTestingModule],
      providers: [LocationStrategy, PathLocationStrategy, NgbActiveModal]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeftSidebarLinksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
