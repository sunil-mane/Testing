import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PhoneMaskComponent } from './phone-mask.component';
import { SharedModule } from '../../shared.module';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';

describe('PhoneMaskComponent', () => {
  let component: PhoneMaskComponent;
  let fixture: ComponentFixture<PhoneMaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), RouterTestingModule],
      providers: []
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhoneMaskComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call setCursur function', () => {
    const spy = spyOn(component, 'setCursor');
    fixture.detectChanges();
    const inputDom = fixture.debugElement.query(By.css('input.form-control')).nativeElement;
    inputDom.click();
    expect(spy).toHaveBeenCalled();
  });

  it('should accept area code', () => {
    component.phone = '123';
    fixture.detectChanges();
    const inputDom = fixture.debugElement.query(By.css('input.form-control')).nativeElement;
    inputDom.click();
    inputDom.blur();
    expect(component.phone).toEqual('123');
  });

});
