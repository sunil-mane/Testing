import { Component } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
/**
 * Custom form control component for phone and Fax
 */
@Component({
  selector: 'app-phone-mask',
  templateUrl: './phone-mask.component.html',
  providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: PhoneMaskComponent, multi: true }]
})
export class PhoneMaskComponent implements ControlValueAccessor {
  // Phone number mask
  public mask = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];

  // Phone number
  phone: string;

  /**
   * onChange method for ControlValueAccessor
   */
  onChange = (value: string) => { };

  /**
   * onTouched method for ControlValueAccessor
   */
  onTouched = () => { };

  /**
   * writeValue method for ControlValueAccessor
   */
  writeValue(value: string) {
    this.phone = value;
  }

  /**
 * registerOnChange method for  ControlValueAccessor
 */
  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  /**
   * registerOnTouched method for  ControlValueAccessor
   */
  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  /**
 * Get value getter for ControlValueAccessor
 */
  get value(): string {
    return this.phone;
  }
  /**
   * Update phone number on blur
   * @param event update phone number
   */
  updatePhone(event) {
    let phoneMask = '';
    const phone = event.target.value;
    const phoneNumberPattern = /^\(+(\d{3})\)+[ ]+(\d{3})[-]+(\d{4})$/;
    if (phoneNumberPattern.test(phone) || phone.replace(/\D+/g, '') === '') {
      phoneMask = phone;
    } else {
      const areaCode = phone.split(' ')[0];
      const numberOnly = phone.split(' ')[1];
      const areaCodePattern = /^\(+(\d{3})\)$/;
      const numberOnlyPattern = /(\d{3})[-]+(\d{4})$/;
      if (!areaCodePattern.test(areaCode) && !numberOnlyPattern.test(numberOnly)) {
        phoneMask = phone.replace(/\d+/g, '_');
      } else if (!areaCodePattern.test(areaCode)) {
        phoneMask = areaCode.replace(/\d+/g, '_') + numberOnly;
      } else {
        phoneMask = areaCode + numberOnly.replace(/\d+/g, '_');
      }
      this.writeValue(phoneMask);
    }
    this.onChange(phoneMask);
    this.onTouched();
  }

  /**
   * Set cursor at beginning
   * @param event Event
   */
  setCursor(event) {
    const number = event.target.value.replace(/\D+/g, '');
    if (number.length === 0) {
      event.target.setSelectionRange(1, 1);
      event.target.focus();
    }
  }


}
