import { Component, ContentChildren, QueryList } from '@angular/core';
import { IrisCardsDirective } from '../../directives/iris-cards.directive';

@Component({
  selector: 'app-content-cards',
  templateUrl: './content-cards.component.html',
  styleUrls: ['./content-cards.component.scss']
})
export class ContentCardsComponent {

  /*** Get all content children which are cards  */
  @ContentChildren(IrisCardsDirective) cards: QueryList<IrisCardsDirective>;

  constructor() { }
}
