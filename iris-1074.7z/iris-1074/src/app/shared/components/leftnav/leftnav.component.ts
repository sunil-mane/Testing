import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { LeftNavLinks } from '../../models/LeftNav';

/**
 * Left Navigation Component
 * Takes array of objects as Input where each object is type of LeftNavlink and render left navigation links
 */
@Component({
  selector: 'app-left-nav',
  templateUrl: './leftnav.component.html',
  styleUrls: ['./leftnav.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LeftNavigationComponent {

  /**
   * Left nav links array
   */
  @Input() navLinks: Array<LeftNavLinks>;

  /**
   * Constructor
   */
  constructor() {
    // Default links
    this.navLinks = [
      { label: 'Home', url: ['/dashboard'], icon: ['fas', 'fa-home'] }
      , { label: 'Projects', url: ['/projects/search'], icon: ['fas', 'fa-briefcase'] }
      , { label: 'Companies', url: ['/companies/search'], icon: ['fas', 'fa-building'] }
      , { label: 'Feed Content', url: ['/feed'], icon: ['fas', 'fa-list-alt'] }
    ];
  }
}
