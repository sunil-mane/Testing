import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { LeftNavigationComponent } from './leftnav.component';
import { LeftNavLinks } from '../../models/LeftNav';

describe('LeftNavigationComponent', () => {
  let component: LeftNavigationComponent;
  let fixture: ComponentFixture<LeftNavigationComponent>;
  let elements: DebugElement[];
  let navLinks: Array<LeftNavLinks>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [LeftNavigationComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(LeftNavigationComponent);
    component = fixture.componentInstance;
    navLinks = [
      { label: 'Menu 1', url: ['/menu1'], icon: ['fas', 'fa-users'] },
      { label: 'Menu 2', url: ['/menu2'], icon: ['fas', 'fa-users'] }
    ];
  }));

  it('should create', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should have 2 "li" elements', async(() => {
    component.navLinks = navLinks;
    fixture.detectChanges();

    elements = fixture.debugElement.queryAll(By.css('ul > li'));

    expect(component.navLinks.length).toEqual(2);
    expect(elements.length).toEqual(2);
  }));
});
