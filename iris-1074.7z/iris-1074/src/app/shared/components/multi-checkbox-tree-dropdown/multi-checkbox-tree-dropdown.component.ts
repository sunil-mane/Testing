import {
  ChangeDetectionStrategy, Component, forwardRef, Input, Output, EventEmitter, TemplateRef, OnInit,
  ViewChild, Injector, ViewEncapsulation, AfterViewInit, ElementRef, HostListener, Renderer2
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import {
  TreeviewI18n, TreeviewItem, TreeviewConfig, TreeviewHelper, TreeviewComponent,
  TreeviewEventParser, OrderDownlineTreeviewEventParser, DownlineTreeviewItem, TreeviewSelection, DropdownTreeviewComponent,
} from 'ngx-treeview';
import { isEqual, isNil, remove, reverse } from 'lodash';
import { Stage, Stages } from '../../models/ProjectStageLookup';
import { ProjectType, ProjectTypes } from '../../models/ProjectTypeLookup';
import { DefaultTreeviewI18n } from './tree-dropdown-i18n';


/* filter item class */

class FilterTreeviewItem extends TreeviewItem {
  private readonly refItem: TreeviewItem;
  constructor(item: TreeviewItem) {
    super({
      text: item.text,
      value: item.value,
      disabled: item.disabled,
      checked: item.checked,
      collapsed: item.collapsed,
      children: item.children
    });
    this.refItem = item;
  }

  updateRefChecked() {
    this.children.forEach(child => {
      if (child instanceof FilterTreeviewItem) {
        child.updateRefChecked();
      }
    });

    let refChecked = this.checked;
    if (refChecked) {
      for (const refChild of this.refItem.children) {
        if (!refChild.checked) {
          refChecked = false;
          break;
        }
      }
    }
    this.refItem.checked = refChecked;
  }
}

// Multi select accessor to override DOM event with new dropdown component
export const MULTI_SELECT_INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => MultiCheckboxTreeDropdownComponent),
  multi: true
};


// Multi select accessor to override DOM event with new dropdown component
export const TREE_DROPDOWN_TEXT: any = {
  provide: TreeviewI18n,
  useExisting: forwardRef(() => MultiCheckboxTreeDropdownComponent),
  multi: true
};
/**
 * UpdateTreeLeaf
 * Update tree when checkbox is checked or removed from DOM. Customization is done to support reactive form control.
 * @param {TreeviewItem} item
 * @param {string[]} selected
 * @returns {TreeviewItem}
 */
const updateTreeLeaf = (item: TreeviewItem, selected: string[]) => {
  const shouldBeChecked = selected.indexOf(item.value) !== -1;

  // do not mutate if there are no changes
  if (item.checked === shouldBeChecked) {
    return item;
  }

  const modifiedItem = {
    ...item,
    checked: shouldBeChecked
  };

  return new TreeviewItem(modifiedItem);

};
/**
 * updateTreeParent
 * update tree parent when child is selected.
 * @param {TreeviewItem} item
 * @param {string[]} selected
 * @returns {TreeviewItem}
 */
const updateTreeParent = (item: TreeviewItem, selected: string[]) => {

  const children = item.children.map(child => mapItem(child, selected));

  // do not mutate parent if there are no changes
  if (isEqual(children, item.children)) {
    return item;
  }

  const modifiedParent = {
    ...item,
    children
  };

  return new TreeviewItem(modifiedParent, true);

};

/**
 * Recursively map items and set checked property without mutating the original items
 * @param {TreeviewItem} item
 * @param {string[]} selected
 * @returns {TreeviewItem}
 */
const mapItem = (item: TreeviewItem, selected: string[]) => {

  if (item.children && item.children.length > 0) {
    return updateTreeParent(item, selected);
  }

  // update TreeLeave item
  return updateTreeLeaf(item, selected);
};
@Component({
  selector: 'app-multi-checkbox-tree-dropdown',
  templateUrl: './multi-checkbox-tree-dropdown.component.html',
  styleUrls: ['./multi-checkbox-tree-dropdown.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [
    MULTI_SELECT_INPUT_CONTROL_VALUE_ACCESSOR,
    { provide: TreeviewEventParser, useClass: OrderDownlineTreeviewEventParser },
    { provide: TreeviewI18n, useClass: DefaultTreeviewI18n }
  ]
})

/**
 * Multiselect checkbox tree Component defination
 */

export class MultiCheckboxTreeDropdownComponent implements ControlValueAccessor, OnInit, AfterViewInit {
  // tree view component from view
  @ViewChild(TreeviewComponent) treeviewComponent: TreeviewComponent;
  @ViewChild(DropdownTreeviewComponent) dropdownTreeviewComponent: DropdownTreeviewComponent;
  // treeview config
  @Input() config: TreeviewConfig = TreeviewConfig.create({
    hasAllCheckBox: false,
    hasFilter: true,
    hasCollapseExpand: false,
    maxHeight: 250,
  });
  treeViewService: any;
  @Input() placeholder: string;
  // constructor
  constructor(private injector: Injector, private elementRef: ElementRef, private renderer: Renderer2) {
    this.treeViewService = injector.get(TreeviewI18n);
  }
  // treeview items
  private _items: TreeviewItem[];
  private selected: string[] = [];

  rows: string[];
  // internal functions to call by ControlValueAccessor
  private onTouched: Function;
  private onModelChange: Function;
  @Output() onchange: EventEmitter<any> = new EventEmitter();
  @Input() template: TemplateRef<any>;
  @Input() isMultiSelect = true;
  filterItems: TreeviewItem[] = [];
  filterText = '';
  // list of items
  @Input('items')
  set items(items: TreeviewItem[]) {
    this.filterItems = [...items];
    // modify items so selected values are checked ( and all others will be unchecked )
    this.updateItems(items, this.selected);
  }
  /**
   * items
   * getter for items
   */
  get items() {
    return this._items;
  }
  /**
   * OnInit event.
   */
  ngOnInit() {
    this.treeViewService.setPlaceHolder(this.placeholder);
  }
  /**
   * OnAfterViewInit event.
   */
  ngAfterViewInit() {
    // bind keypress to document and get tab key event
    this.elementRef.nativeElement.ownerDocument.addEventListener('keyup', this.onKeyDown.bind(this));
    this.elementRef.nativeElement.querySelector('button').removeEventListener('click', this.onClick.bind(this), false);
    this.elementRef.nativeElement.querySelector('button').addEventListener('click', this.onClick.bind(this), false);
  }
  onClick(event: any) {
    setTimeout(() => {
      this.elementRef.nativeElement.querySelector('[data-search]').focus();
    }, 500);
  }

  /**
   * custom filter method to filter from start
   */
  onCustomFilterTextChange(text: string) {
    this.filterText = text;
    this.updateFilterItems();
  }

  /**
   * update filter items
   */
  private updateFilterItems() {
    if (this.filterText !== '') {
      const filterItems: TreeviewItem[] = [];
      const filterText = this.filterText.toLowerCase();
      this.items.forEach(item => {
        const newItem = this.filterItem(item, filterText);
        if (!isNil(newItem)) {
          filterItems.push(newItem);
        }
      });
      this.filterItems = [...filterItems];
    } else {
      this.filterItems = [...this.items];
    }
    this.filterItems.forEach((element) => {
      element.correctChecked();
    });
  }
  /**
   * filter with search criteria
   * @param item treeviewitem
   * @param filterText text to search
   */
  private filterItem(item: TreeviewItem, filterText: string): TreeviewItem {
    const isMatch = item.text.toLowerCase().startsWith(filterText);
    if (isMatch) {
      return item;
    } else {
      if (!isNil(item.children)) {
        const children: TreeviewItem[] = [];
        item.children.forEach(child => {
          const newChild = this.filterItem(child, filterText);
          if (!isNil(newChild)) {
            children.push(newChild);
          }
        });
        if (children.length > 0) {
          const newItem = new FilterTreeviewItem(item);
          newItem.collapsed = false;
          newItem.children = children;
          return newItem;
        }
      }
    }
    return undefined;
  }
  /**
    * callback if single select is enabled
    * @param item Selected treeview item
    */
  select(item: TreeviewItem) {
    if (item.children === undefined) {
      this.selectItem(item);
    }
  }
  /**
    * callback if single select is enabled
    */
  private selectItem(item: TreeviewItem) {
    this.dropdownTreeviewComponent.dropdownDirective.close();
    if (this.treeViewService.selectedItem !== item) {
      this.treeViewService.selectedItem = item;
      if (true) {
        // trigger change on form
        this.onModelChange(item.value);
        this.onTouched();
        // trigger change to parent component
        this.onchange.emit(item.value);
        this.treeViewService.setPlaceHolder(item.text);
      }
    }
  }

  /**
   * Handles keydown event to hide dropdown.
   *
   * @param event keydown event
   */
  onKeyDown(event: any) {
    const hasClass = this.elementRef.nativeElement.querySelector('[ngxdropdownmenu]').classList.contains('show');
    if ((event.key === 'Tab') && hasClass) {
      // remove class from dropdown because dropdowns hide function is not working now.
      this.renderer.removeClass(this.elementRef.nativeElement.querySelector('[ngxdropdownmenu]'), 'show');
      this.renderer.removeClass(this.elementRef.nativeElement.querySelector('.dropdown'), 'show');

      this.dropdownTreeviewComponent.dropdownDirective.close();
    }
    if ((event.key === 'Enter')) {
      if (this.elementRef.nativeElement.ownerDocument.contains(document.activeElement)) {
        this.renderer.removeClass(this.elementRef.nativeElement.querySelector('[ngxdropdownmenu]'), 'show');
        this.renderer.removeClass(this.elementRef.nativeElement.querySelector('.dropdown'), 'show');
        this.dropdownTreeviewComponent.dropdownDirective.close();
      }
    }
    if (event.code === 'Space') {
      setTimeout(() => {
        this.elementRef.nativeElement.querySelector('[data-search]').focus();
      }, 500);
    }
  }
  /**
   * onSelect
   * Callback of tree dropdown selected event, this callback will return list of values of selected options.
   * @param items: Selected items from list
   */
  public onSelect(items) {
    // sort values so isEqual comparison works
    const selected = [...items].sort();
    this.selected = selected;

    // trigger change on form
    this.onModelChange(selected);
    this.onTouched();
    // trigger change to parent component
    this.onchange.emit(selected);
  }
  /**
    * onSelectChange
    * Detail callback of tree dropdown selected event, this callback will return selected object from list
    * @param {DownlineTreeviewItem[]} items: Selected items from list
    */
  onSelectedChange(downlineItems: DownlineTreeviewItem[]) {
    this.rows = [];
    const values = [];
    const items = [];
    // foreach selecte items
    downlineItems.forEach(downlineItem => {
      const item = downlineItem.item;
      // push selected item object from list.
      items.push(item);
      // push value of selected item list.
      values.push(item.value);
      let parent = downlineItem.parent;
      // if parent is there then push parent as well
      while (!isNil(parent)) {
        parent = parent.parent;
      }
    });
    // sort values so isEqual comparison works
    const selected = [...values].sort();
    this.selected = selected;

    // trigger change on form
    this.onModelChange(selected);
    this.onchange.emit(items);
    this.onTouched();
  }
  /**
  * onSelect
  * Remove item from list if we have remove icon
  * @param {TreeviewItem} item: Selected items from list
  */
  removeItem(item: TreeviewItem) {
    let isRemoved = false;
    for (const tmpItem of this.items) {
      if (tmpItem === item) {
        remove(this.items, item);
      } else {
        isRemoved = TreeviewHelper.removeItem(tmpItem, item);
        if (isRemoved) {
          break;
        }
      }
    }

    if (isRemoved) {
      this.treeviewComponent.raiseSelectedChange();
    }
  }
  /**
   * set the checked property on all Treeview items
   * @param {TreeviewItem[]} items
   * @param {string[]} selected
   */
  private updateItems(items: TreeviewItem[], selected: string[]) {

    // recursively walk through all treeview items and set the checked value
    this._items = items.map(item => mapItem(item, selected));
    this.selected = selected;
    this.filterItems = this.items;
  }

  /********************************
   * ControlValue methods
   ********************************/

  /**
   * This is called from a form input to set the internal value
   * @param {string[]} selected
   */
  writeValue(selected: string[]): void {
    // sort values so isEqual comparison works
    if (!selected) {
      // if reset is clicked on form
      for (let i = 0; i < this.selected.length; i++) {
        // foreach selected item, reset it on main list
        const item = TreeviewHelper.findItemInList(this.items, this.selected[i]);
        if (item && item.checked) {
          item.checked = false;
          item.correctChecked();
        }
      }
      this.selected = [];
      // reset all items in list
      this.items.forEach((element) => {
        element.correctChecked();
      });
      this.filterItems = [...this.items];
      // reload dropdown
      this.dropdownTreeviewComponent.treeviewComponent.raiseSelectedChange();
    }

    if (selected) {
      selected = [...selected].sort();
      this.filterItems = [...this.items];
      // this code is required if we do not support single remove from applied filters
      // if (isEqual(this.selected, selected)) {
      //    return;
      // }
      this.updateItems(this.items, selected);
    }
  }
  /**
   * This is an event callback for change from control value accessor
   * @param {Function} fn
   */
  registerOnChange(fn: Function) {
    this.onModelChange = fn;
  }
  /**
  * This is an event callback for touch event from control value accessor
  * @param {any} fn
  */
  registerOnTouched(fn: () => any): void {
    this.onTouched = fn;
  }
  /**
  * This is an event callback for disabled state from control value accessor
  * @param {Boolean} isDisabled boolean flag if item is disabled.
  */
  setDisabledState?(isDisabled: boolean): void {
    throw new Error('Method not implemented.');
  }
}
/**
 * Helper class for treeview data
 */
export class TreeViewDataHelper {
  /**
  * This method is to format city dropdown with new api data and persist old city data.
  * @param {any} statesData JSON data from api.
  * @param {TreeviewItem[]} cityDropdown Current city dropdown data.
  */
  static formatCityDropdown(statesData: any, cityDropdown: TreeviewItem[]) {
    // temporary variable for counties
    const tempCounties = [];
    let tempCityDropdown = [];
    for (let i = 0; i < statesData.length; i++) {
      const stateData = statesData[i];
      // check if selected state is already in counties dropdown. If yes then just push it to new dropdown
      const existingState = cityDropdown.filter(x => x.value === stateData.id);
      if (existingState.length) {
        tempCounties.push(existingState[0]);
      } else {
        // item is added
        const cityList = this.createTreeViewItem(stateData.name, stateData.id, true);
        cityList.collapsed = false;
        // fill data with temorary counties
        for (let j = 0; j < stateData.cities.length; j++) {
          const city = stateData.cities[j];
          // if it is first object, then we have to update object because it is bydefault added.
          if (cityList.children.length === 1 && j === 0) {
            cityList.children[0].text = city.name;
            cityList.children[0].value = city.name;
          } else {
            // else add new item in treeview
            const cityObj = this.createTreeViewItem(city.name, city.name, false);
            cityObj.collapsed = false;
            cityList.children.push(cityObj);
          }
        }
        tempCounties.push(cityList);
      }
      tempCityDropdown = [...tempCounties];
    }
    // removed item if it is unselected in states and still exist in dropdown.
    if (tempCityDropdown.length > statesData.length) {
      const filter = tempCityDropdown.filter(x => (statesData.indexOf(x.value) === -1));
      if (filter.length) {
        const index = tempCityDropdown.findIndex(x => x.value === filter[0].value);
        const tempCity = tempCityDropdown;
        tempCity.splice(index, 1);
        tempCityDropdown = tempCity;
      }
    }
    return tempCityDropdown;
  }
  /**
  * This method is to format city dropdown with new api data and persist old city data.
  * @param {any} statesData JSON data from api.
  * @param {TreeviewItem[]} cityDropdown Current city dropdown data.
  */
  static formatCountyDropdown(statesData: any, cityDropdown: TreeviewItem[]) {
    // temporary variable for counties
    const tempCounties = [];
    let tempCityDropdown = [];
    for (let i = 0; i < statesData.length; i++) {
      const stateData = statesData[i];
      // check if selected state is already in counties dropdown. If yes then just push it to new dropdown
      const existingState = cityDropdown.filter(x => x.value === stateData.id);
      if (existingState.length) {
        tempCounties.push(existingState[0]);
      } else {
        // item is added
        const countyList = this.createTreeViewItem(stateData.name, stateData.id, true);
        countyList.collapsed = false;
        // fill data with temorary counties
        for (let j = 0; j < stateData.counties.length; j++) {
          const city = stateData.counties[j];
          // if it is first object, then we have to update object because it is bydefault added.
          if (countyList.children.length === 1 && j === 0) {
            countyList.children[0].text = city.name;
            countyList.children[0].value = city.id;
          } else {
            // else add new item in treeview
            const countyObj = this.createTreeViewItem(city.name, city.id, false);
            countyObj.collapsed = false;
            countyList.children.push(countyObj);
          }
        }
        tempCounties.push(countyList);
      }
      tempCityDropdown = [...tempCounties];
    }
    // removed item if it is unselected in states and still exist in dropdown.
    if (tempCityDropdown.length > statesData.length) {
      const filter = tempCityDropdown.filter(x => (statesData.indexOf(x.value) === -1));
      if (filter.length) {
        const index = tempCityDropdown.findIndex(x => x.value === filter[0].value);
        const tempCity = tempCityDropdown;
        tempCity.splice(index, 1);
        tempCityDropdown = tempCity;
      }
    }
    return tempCityDropdown;
  }
  /**
  * This method is to format stage dropdown with new api data and persist old stage data.
  * @param {Stages[]} stagesData JSON data from api.
  * @param {TreeviewItem[]} stageDropdown Current stage dropdown data.
  */
  static formatProjectTypesDropdown(projectTypes: ProjectTypes[], typeDropdown: TreeviewItem[]) {
    // temporary variable for counties
    const tempStages = [];
    let tempTypesDropdown = [];

    for (let i = 0; i < projectTypes.length; i++) {
      const stageData = projectTypes[i];
      // check if selected state is already in counties dropdown. If yes then just push it to new dropdown
      const existingState = tempTypesDropdown.filter(x => x.value === stageData.code);
      // item is added
      const projectTypeList = this.createTreeViewItem(stageData.name, stageData.code, true, false);
      // fill data with temorary counties
      for (let j = 0; j < stageData.subtypes.length; j++) {
        const stage = stageData.subtypes[j];
        let projectTypeObj;
        // if it is first object, then we have to update object because it is bydefault added.
        if (projectTypeList.children.length === 1 && j === 0) {
          projectTypeObj = projectTypeList.children[0];
          projectTypeObj.text = stage.name;
          projectTypeObj.value = stage.code;
        } else {
          // else add new item in treeview
          projectTypeObj = this.createTreeViewItem(stage.name, stage.code, true);
          projectTypeList.children.push(projectTypeObj);
        }

        if (stage.subtypes) {
          projectTypeObj.children = [new TreeviewItem({ text: '', value: '', collapsed: true })];
          for (let k = 0; k < stage.subtypes.length; k++) {
            const substage = stage.subtypes[k];
            if (projectTypeObj.children.length === 1 && k === 0) {
              projectTypeObj.children[0].text = substage.name;
              projectTypeObj.children[0].value = substage.code;
            } else {
              const tempStage = this.createTreeViewItem(substage.name, substage.code, false);
              projectTypeObj.children.push(tempStage);
            }
          }
        }
      }
      if (existingState.length > 0) {
        projectTypeList.children.forEach(element => {
          existingState[0].children.push(element);
        });
      } else {
        tempStages.push(projectTypeList);
      }
      tempTypesDropdown = [...tempStages];
    }
    // removed item if it is unselected in states and still exist in dropdown.
    if (tempTypesDropdown.length > projectTypes.length) {
      const filter = tempTypesDropdown.filter(x => (projectTypes.indexOf(x.value) === -1));
      if (filter.length) {
        const index = tempTypesDropdown.findIndex(x => x.value === filter[0].value);
        const tempStage = tempTypesDropdown;
        tempStage.splice(index, 1);
        tempTypesDropdown = tempStage;
      }
    }
    return tempTypesDropdown;
  }
  /**
  * This method is to format stage dropdown with new api data and persist old stage data.
  * @param {Stages[]} stagesData JSON data from api.
  * @param {TreeviewItem[]} stageDropdown Current stage dropdown data.
  */
  static formatProjectStageDropdown(projectStage: Stages[], stageDropdown: TreeviewItem[]) {
    // temporary variable for counties
    const tempStages = [];
    let tempStageDropdown = [];
    for (let i = 0; i < projectStage.length; i++) {
      const stageData = projectStage[i];
      // check if selected state is already in counties dropdown. If yes then just push it to new dropdown
      const existingState = stageDropdown.filter(x => x.value === stageData.id);
      if (existingState.length) {
        tempStages.push(existingState[0]);
      } else {
        // item is added
        const stageList = this.createTreeViewItem(stageData.name, stageData.id, true);
        stageList.collapsed = false;
        // fill data with temorary counties
        for (let j = 0; j < stageData.stage.length; j++) {
          const stage = stageData.stage[j];
          // if it is first object, then we have to update object because it is bydefault added.
          if (stageList.children.length === 1 && j === 0) {
            stageList.children[0].text = stage.name;
            stageList.children[0].value = stage.id;
            stageList.children[0].collapsed = false;
          } else {
            // else add new item in treeview
            const stageObj = this.createTreeViewItem(stage.name, stage.id, false);
            stageObj.collapsed = false;
            stageList.children.push(stageObj);
          }
        }
        tempStages.push(stageList);
      }
      tempStageDropdown = [...tempStages];
    }
    // removed item if it is unselected in states and still exist in dropdown.
    if (tempStageDropdown.length > projectStage.length) {
      const filter = tempStageDropdown.filter(x => (projectStage.indexOf(x.value) === -1));
      if (filter.length) {
        const index = tempStageDropdown.findIndex(x => x.value === filter[0].value);
        const tempStage = tempStageDropdown;
        tempStage.splice(index, 1);
        tempStageDropdown = tempStage;
      }
    }
    return tempStageDropdown;
  }
  /**
  * This method is to create single treenode
  * @param {string} text label to display.
  * @param {string} value value to return when item is checked.
  * @param {boolean} isParent parent flag.
  */
  static createTreeViewItem(text: string, value: string, isParent: boolean, disabled?: boolean) {
    let treeItem = new TreeviewItem({
      text: text, value: value, checked: false, disabled: disabled, collapsed: true
    });
    // if node is parent then add a default child item to tree as it is required by plugin.
    if (isParent) {
      treeItem = new TreeviewItem({
        text: text, value: value, collapsed: true, checked: false, disabled: disabled,
        children: [{ text: '', value: '', checked: false }]
      });
    }
    return treeItem;
  }
}
