import { async, ComponentFixture, TestBed, inject, fakeAsync } from '@angular/core/testing';
import { Injector } from '@angular/core';

import {
  MultiCheckboxTreeDropdownComponent, MULTI_SELECT_INPUT_CONTROL_VALUE_ACCESSOR,
  TreeViewDataHelper
} from './multi-checkbox-tree-dropdown.component';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { SharedModule } from './../../shared.module';
import {
  TreeviewI18n, TreeviewEventParser, OrderDownlineTreeviewEventParser, TreeviewModule, TreeviewItem
} from 'ngx-treeview';
import { DefaultTreeviewI18n } from './tree-dropdown-i18n';
import { Lookups } from '../../../../mocks/lookups';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';

describe('MultiCheckboxTreeDropdownComponent', () => {
  let component: MultiCheckboxTreeDropdownComponent;
  let fixture: ComponentFixture<MultiCheckboxTreeDropdownComponent>;
  let injectorService: Injector;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, TreeviewModule.forRoot(), SharedModule.forRoot()],
      providers: [{ provide: TreeviewI18n, useClass: DefaultTreeviewI18n },
        MULTI_SELECT_INPUT_CONTROL_VALUE_ACCESSOR,
      { provide: TreeviewEventParser, useClass: OrderDownlineTreeviewEventParser }, LocationStrategy]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiCheckboxTreeDropdownComponent);
    component = fixture.componentInstance;

    injectorService = fixture.debugElement.injector.get(Injector);
    component.treeViewService = injectorService.get(TreeviewI18n);
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  // it('should initialize variables', () => {
  //   expect(component.treeViewService).toBeTruthy();
  //   expect(component.config).toBeTruthy();
  //   expect(component.dropdownTreeviewComponent).toBeTruthy();
  // });
  it('should set placeholder when component is initialized', () => {
    component.placeholder = 'Select One';
    const spy = spyOn(component.treeViewService, 'setPlaceHolder').and.callThrough();
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should set selected when array is passed', fakeAsync(() => {
    spyOn(component.onchange, 'emit');
    component.registerOnChange((value: any) => { });
    component.registerOnTouched(() => { });
    component.onSelect([]);
    // fixture.detectChanges();
    expect(component.onchange.emit).toHaveBeenCalledWith([]);
  }));

  it('should remove treeview item when selected item is passed', async(() => {
    component.registerOnChange((value: any) => { });
    component.registerOnTouched(() => { });
    // spyOn(component.treeviewComponent, 'raiseSelectedChange');
    const treeviewitem = new TreeviewItem({ text: 'test2', value: 'test2' });
    const treeviewitems = [treeviewitem, new TreeviewItem({
      text: 'test', value: 'test',
      children: [new TreeviewItem({ text: 'child1', value: 'child1' }),
      new TreeviewItem({ text: 'child2', value: 'child2' })
      ]
    })];
    component.items = treeviewitems;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.removeItem(component.items[0]);
      expect(component.items.length).toBe(1);
    });
  }));

  it('should update dropdown if selected items are passed', async () => {
    const treeviewitem = new TreeviewItem({ text: 'test2', value: 'test2', checked: true });
    const treeviewitems = [treeviewitem, new TreeviewItem({
      text: 'test', value: 'test',
      children: [new TreeviewItem({ text: 'child1', value: 'child1' }),
      new TreeviewItem({ text: 'child2', value: 'child2' })
      ]
    })];
    component.items = treeviewitems;
    component.registerOnChange((value: any) => { });
    component.registerOnTouched(() => { });
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.writeValue(['test2']);
      expect(component.items[0].checked).toBe(true);
    });
  });

  it('should update city dropdown if data is passed to helper', async () => {
    const cityData = Lookups.getCities('NJ');
    const dropdownItems = [];
    const cityDropdown = TreeViewDataHelper.formatCityDropdown(cityData.data.states, dropdownItems);
    expect(cityDropdown.length).toBeGreaterThan(0);
  });
  it('should update county dropdown if data is passed to helper', async () => {
    const cityData = Lookups.getCounties('NJ');
    const dropdownItems = [];
    const countyDropdown = TreeViewDataHelper.formatCountyDropdown(cityData.data.states, dropdownItems);
    expect(countyDropdown.length).toBeGreaterThan(0);
  });
  it('should update project stage dropdown if data is passed to helper', async () => {
    const cityData = Lookups.getProjectStage();
    const dropdownItems = [];
    const stageDropdown = TreeViewDataHelper.formatProjectStageDropdown(cityData.data.stages, dropdownItems);
    expect(stageDropdown.length).toBeGreaterThan(0);
  });
  it('should update project type dropdown if data is passed to helper', async () => {
    const typeData: any = Lookups.getProjectType();
    const dropdownItems = [];
    const typeDropdown = TreeViewDataHelper.formatProjectTypesDropdown(typeData.data.types, dropdownItems);
    expect(typeDropdown.length).toBeGreaterThan(0);
  });
});
