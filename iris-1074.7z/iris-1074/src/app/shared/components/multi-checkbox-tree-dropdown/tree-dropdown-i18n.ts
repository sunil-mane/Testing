import { Injectable } from '@angular/core';
import { TreeviewItem, TreeviewSelection, TreeviewI18n } from 'ngx-treeview';

/**
 * DefaultTreeviewI18n
 * Update default messages from treeview tool to custom one.
 */

@Injectable()
export class DefaultTreeviewI18n extends TreeviewI18n {
  // default placeholder
  placeHolder = 'Select Option';

  constructor() {
    super();
  }
  /**
 * Set placeholder
 * Update placeholder message for dropdown.
 * @param {string} placeholder text to set on dropdown
 */
  setPlaceHolder(placeholder: string) {
    this.placeHolder = placeholder;
  }
  /**
   * Get Text
   * Default method from treeview to get text for dropdown.
   * @param {TreeviewSelection} selection list of selected and unselected items from list
   */
  getText(selection: TreeviewSelection): string {
    if (selection) {
      if (selection.uncheckedItems.length === 0 && selection.checkedItems.length === 0) {
        return this.placeHolder;
      }
      if (selection.uncheckedItems.length === 0 && selection.checkedItems.length > 0) {
        return `${this.placeHolder} (${selection.checkedItems.length})`;
      }
      switch (selection.checkedItems.length) {
        case 0:
          return this.placeHolder;
        case 1:
          return selection.checkedItems[0].text;
        default:
          return `${this.placeHolder} (${selection.checkedItems.length})`;
      }
    }
  }
  /**
   * Get All Checkbox Text
   * Default method from treeview to get text for all checkbox label.
   */
  getAllCheckboxText(): string {
    return 'All';
  }
  /**
   * Get Filter Placeholder Text
   * Default method from treeview to get placeholder text for filter.
   */
  getFilterPlaceholder(): string {
    return 'Filter';
  }
  /**
   * No items in list text
   * Default method from treeview to get text if no items are in treeview.
   */
  getFilterNoItemsFoundText(): string {
    return 'No items found';
  }
  /**
   * Get Tooltip for collapse and expand
   * Default method from treeview to get tooltip text for collapse and expand button.
   * @param {boolean} isCollapse current status of treeitem
   */
  getTooltipCollapseExpandText(isCollapse: boolean): string {
    return isCollapse ? 'Expand' : 'Collapse';
  }
}
