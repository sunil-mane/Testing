import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DrSearchComponent } from './dr-search.component';

describe('DrSearchComponent', () => {
  let component: DrSearchComponent;
  let fixture: ComponentFixture<DrSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DrSearchComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DrSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
