import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dr-search',
  templateUrl: './dr-search.component.html',
  styleUrls: ['./dr-search.component.scss']
})
export class DrSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
