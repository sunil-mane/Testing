import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../shared.module';

@Component({
  template: `<button id="testButton" class="btn btn-secondary btn-sm" appNoDblClick>Test</button>`
})
class TestComponent {
  constructor() { }
}

describe('NoDblClickDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let buttonDom: HTMLInputElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule],
      declarations: [TestComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    buttonDom = fixture.debugElement.query(By.css('#testButton')).nativeElement;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should disable button click', async(() => {
    fixture.detectChanges();
    buttonDom.click();
    expect(buttonDom.hasAttribute('disabled')).toBe(true);
  }));
});

