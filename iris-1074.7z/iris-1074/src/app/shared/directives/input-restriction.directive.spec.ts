import { InputRestrictionDirective } from './input-restriction.directive';
import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Component } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { SharedModule } from '../shared.module';
import { LeftSidebarService } from '../services/left-sidebar.service';
import { BaseFormGroup } from '../forms/base-form-group';
import { BaseFormControl } from '../forms/base-form-control';
import { NgControl, FormsModule } from '@angular/forms';


@Component({
  template: `<form id="pdf-menu" novalidate [formGroup]="textSearchFormGroup">
  <input type="text" formControlName="term" class="form-control" appInputRestriction="noSpecialChars">
  </form>`
})
class TestInputComponent {
  /** Search Text Form Group */
  textSearchFormGroup: BaseFormGroup;

  /** Search Text - Input Form Control */
  textSearchControl: BaseFormControl;

  constructor() {
    this.textSearchControl = new BaseFormControl('Text Search', 'term', 'text', '', [], []);
    this.textSearchFormGroup = new BaseFormGroup('textSearchForm', {
      term: this.textSearchControl
    });
  }
}

xdescribe('AppInputRestrictionDirective', () => {

  let component: TestInputComponent;
  let fixture: ComponentFixture<TestInputComponent>;
  let inputEl: HTMLElement;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule, FormsModule],
      declarations: [TestInputComponent]
    });
    fixture = TestBed.createComponent(TestInputComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input')).nativeElement;
  });

  it('should allow valid value when keypress event', () => {
    fixture.detectChanges();
    fixture.componentInstance.textSearchControl.setValue('test');
    const event = new KeyboardEvent('keydown', {
      key: 'Enter'
    });
    inputEl.dispatchEvent(event);
    // fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(fixture.componentInstance.textSearchControl.value).toBe('test');
    });
  });

  it('should not allow invalid valid value when keypress event', () => {
    fixture.detectChanges();
    fixture.componentInstance.textSearchControl.setValue('test$');
    // inputEl.dispatchEvent(new ClipboardEvent('paste', {
    //   dataType: 'text/plain',
    //   data: '123'
    // }));
    // inputEl.dispatchEvent(event);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(fixture.componentInstance.textSearchControl.value).toBe('123');
    });
  });
});
