import { Directive, TemplateRef, Input } from '@angular/core';

/**
 * This directive must be used to wrap content to be displayed in accordion.
 */
@Directive({ selector: 'ng-template[appIrisAccordion]' })
export class IrisAccordionDirective {

  /** Accordion title  */
  @Input() title: string;

  /** Accordion id which is same as filter parent id  */
  @Input() id: string;

  /** Whether the accordion is active / expanded */
  @Input() isActive: boolean;

  /**
   * Contructor
   * @param {TemplateRef} templateRef template reference
   */
  constructor(public templateRef: TemplateRef<any>) { }
}
