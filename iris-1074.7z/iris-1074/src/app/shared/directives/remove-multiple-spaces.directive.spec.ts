import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { SharedModule } from '../shared.module';
import { BaseFormGroup } from '../forms/base-form-group';
import { BaseFormControl } from '../forms/base-form-control';

@Component({
  template: `<form id="pdf-menu" novalidate [formGroup]="textSearchFormGroup">
  <input type="text" formControlName="{{ textSearchControl.modelProperty }}" class="form-control" appRemoveMultipleSpaces>
  </form>`
})
class TestRemoveMultipleSpacesComponent {
  /*** Search Text Form Group */
  textSearchFormGroup: BaseFormGroup;

  /*** Search Text - Input Form Control */
  textSearchControl: BaseFormControl;

  constructor() {
    this.textSearchControl = new BaseFormControl('Text Search', 'term', 'text', '', [], []);
    this.textSearchFormGroup = new BaseFormGroup('textSearchForm', {
      term: this.textSearchControl
    });
  }
}

describe('RemoveMultipleSpacesDirective', () => {
  let component: TestRemoveMultipleSpacesComponent;
  let fixture: ComponentFixture<TestRemoveMultipleSpacesComponent>;
  let inputEl: DebugElement;
  let inputDom: HTMLInputElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule],
      declarations: [TestRemoveMultipleSpacesComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TestRemoveMultipleSpacesComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    inputDom = inputEl.nativeElement;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should remove space on blur', async(() => {
    component.textSearchControl.setValue('TEST  SPACE');
    fixture.detectChanges();
    inputDom.dispatchEvent(new Event('blur'));
    expect(inputDom.value).toBe('TEST SPACE');
  }));

  it('should remove space on input', async(() => {
    component.textSearchControl.setValue('TEST  SPACE');
    fixture.detectChanges();
    inputDom.dispatchEvent(new Event('input'));
    expect(inputDom.value).toBe('TEST SPACE');
  }));
});
