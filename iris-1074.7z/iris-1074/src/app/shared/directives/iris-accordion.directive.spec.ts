import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component } from '@angular/core';
import { IrisAccordionDirective } from './iris-accordion.directive';

@Component({
  template: `<ng-template appIrisAccordion title="Company/Contact Address" id="companyAddressForm" [isActive]="false">
  Sample</ng-template>`
})
class TestComponent {
  constructor() { }
}

describe('TriggerSearchDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, IrisAccordionDirective]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

