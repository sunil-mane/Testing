import { Directive, HostListener, Inject, ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustomSwitchKeypress]'
})
export class CustomSwitchKeypressDirective {

  constructor(public elementRef: ElementRef) { }
  /**
   * Bind space key to change selection
   * Trigger search
   * @param {any} event the event object
   */
  @HostListener('keydown', ['$event'])
  public stopPropagationOfEnter(event: KeyboardEvent) {
    // if space is pressed then change selection.
    if (event.code.toLowerCase() === 'space') {
      if (this.elementRef.nativeElement.querySelector('span')) {
        this.elementRef.nativeElement.querySelector('span').click();
      } else if (this.elementRef.nativeElement.querySelector('.custom-control-label')) {
        this.elementRef.nativeElement.querySelector('.custom-control-label').click();
      }
      event.stopPropagation();
      event.preventDefault();
    }
  }
}
