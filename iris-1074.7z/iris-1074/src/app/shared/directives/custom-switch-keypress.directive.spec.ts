import { CustomSwitchKeypressDirective } from './custom-switch-keypress.directive';
import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Component } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { SharedModule } from '../shared.module';
import { LeftSidebarService } from '../services/left-sidebar.service';
import { BaseFormGroup } from '../forms/base-form-group';
import { BaseFormControl } from '../forms/base-form-control';
import * as leftSidebarFilter from '../config/leftsidebarfilter.json';
import { NgControl, FormsModule } from '@angular/forms';

@Component({
  template: `<form id="pdf-menu" novalidate [formGroup]="textSearchFormGroup">
  <div class="col pr-0 pl-0 switch-wrapper" id="custom-switch" appCustomSwitchKeypress tabindex="0">
  <div class="form-control-switch">
    Any
    <label>
      <input type="checkbox" formControlName="term" checked>
      <span id="custom-switch-span"></span>
    </label>
    All
  </div>
</div></form>`
})
class TestInputComponent {
  /** Search Text Form Group */
  textSearchFormGroup: BaseFormGroup;

  /** Search Text - Input Form Control */
  textSearchControl: BaseFormControl;

  constructor() {
    this.textSearchControl = new BaseFormControl('Text Search', 'term', 'text', '', [], []);
    this.textSearchFormGroup = new BaseFormGroup('textSearchForm', {
      term: this.textSearchControl
    });
  }
  exactMarchCheckHandler(event) {

  }
}

describe('CustomSwitchKeypressDirective', () => {
  let component: TestInputComponent;
  let fixture: ComponentFixture<TestInputComponent>;
  let inputDom: HTMLInputElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule, FormsModule],
      declarations: [TestInputComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TestInputComponent);
    component = fixture.componentInstance;
    inputDom = fixture.debugElement.query(By.css('.switch-wrapper')).nativeElement;
  }));

  it('should create an instance', () => {
    expect(component).toBeTruthy();
  });


});
