import { Directive, ElementRef, HostListener, Inject, Optional, Renderer2, Input } from '@angular/core';
import { COMPOSITION_BUFFER_MODE, DefaultValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Directive({
  selector: '[appRemoveMultipleSpaces]',
  providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: RemoveMultipleSpacesDirective, multi: true }]
})
export class RemoveMultipleSpacesDirective extends DefaultValueAccessor {
  /**
   * Input element DOM object
   */
  private el: HTMLInputElement;

  /**
   *  Creates an instance of RemoveMultipleSpacesDirective.
   * @param {Renderer2} renderer
   * @param {ElementRef} elementRef
   * @param {boolean} compositionMode
   */
  constructor(@Inject(Renderer2) renderer: Renderer2, @Inject(ElementRef) elementRef: ElementRef,
    @Optional() @Inject(COMPOSITION_BUFFER_MODE) compositionMode: boolean) {

    super(renderer, elementRef, compositionMode);

    this.el = elementRef.nativeElement;
  }

  /**
   * Updates the  value on the blur event.
   *
   */
  @HostListener('blur', ['$event.target.value'])
  onBlur(value: string): void {
    this.removeMultipleSpaces(value, true);
  }

  /**
   * Updates the value on the input event.
   */
  @HostListener('input', ['$event.target.value'])
  updateValue(value: string): void {
    this.removeMultipleSpaces(value);
  }

  /**
   * Write a value to the element.   *
   * @param {string} value - new value.
   */
  writeValue(value: string): void {
    super.writeValue(value);
  }

  /**
   * Remove multiple spaces of the value and sets it to the element.   *
   * @private
   * @param {string} value - value
   */
  removeMultipleSpaces(value: string, isBlur?: boolean): void {
    // Replace multiple spaces with single space
    const cleanValue = value.replace(/  +/g, ' ');

    // Trigger onChange of DefaultValueAccessor
    if (isBlur) {
      // Assign the cleaned value to input
      this.el.value = cleanValue.trim();
      //  Trigger change on DefaultValueAccessor
      this.onChange(cleanValue.trim());
      // Trigger touched on DefaultValueAccessor
      this.onTouched();
    } else {
      // Assign the cleaned value to input
      this.el.value = cleanValue;
      // Trigger change on DefaultValueAccessor
      this.onChange(cleanValue);
    }
  }
}
