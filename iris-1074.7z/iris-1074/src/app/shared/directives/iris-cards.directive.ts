import { Directive, TemplateRef, Input } from '@angular/core';

/**
 * This directive must be used to wrap content to be displayed in accordion.
 */
@Directive({ selector: 'ng-template[appIrisCards]' })
export class IrisCardsDirective {

  /** Accordion title  */
  @Input() title: string;

  /**
   * Contructor
   * @param {TemplateRef} templateRef template reference
   */
  constructor(public templateRef: TemplateRef<any>) { }
}
