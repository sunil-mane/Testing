import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Component } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { SharedModule } from '../shared.module';
import { LeftSidebarService } from '../services/left-sidebar.service';
import { BaseFormGroup } from '../forms/base-form-group';
import { BaseFormControl } from '../forms/base-form-control';
import * as leftSidebarFilter from '../config/leftsidebarfilter.json';
import { NgControl, FormsModule } from '@angular/forms';

@Component({
  template: `<form id="pdf-menu" novalidate [formGroup]="textSearchFormGroup">
  <input type="text" formControlName="term" class="form-control" appTriggerSearch>
  </form>`
})
class TestTriggerSearchComponent {
  /** Search Text Form Group */
  textSearchFormGroup: BaseFormGroup;

  /** Search Text - Input Form Control */
  textSearchControl: BaseFormControl;

  constructor() {
    this.textSearchControl = new BaseFormControl('Text Search', 'term', 'text', '', [], []);
    this.textSearchFormGroup = new BaseFormGroup('textSearchForm', {
      term: this.textSearchControl
    });
  }
}

describe('TriggerSearchDirective', () => {
  let component: TestTriggerSearchComponent;
  let fixture: ComponentFixture<TestTriggerSearchComponent>;
  let leftSidebarService: LeftSidebarService;
  let identifier: string;
  let inputDom: HTMLInputElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule, FormsModule],
      declarations: [TestTriggerSearchComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TestTriggerSearchComponent);
    component = fixture.componentInstance;
    inputDom = fixture.debugElement.query(By.css('input')).nativeElement;
    leftSidebarService = fixture.debugElement.injector.get(LeftSidebarService);
    identifier = 'projectSearch';
    leftSidebarService.pushFormControlStatusList(leftSidebarFilter[identifier]);
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call searchTriggered', fakeAsync(() => {
    spyOn(leftSidebarService, 'searchTriggered').and.callThrough().and.stub();
    fixture.componentInstance.textSearchControl.setValue('test');
    const event = new KeyboardEvent('keydown', {
      key: 'Enter'
    });
    inputDom.dispatchEvent(event);
    fixture.detectChanges();
    tick(200);
    fixture.whenStable().then(() => {
      expect(leftSidebarService.searchTriggered).toHaveBeenCalled();
    });
  }));

  it('should not call searchTriggered', async(() => {
    fixture.detectChanges();
    spyOn(leftSidebarService, 'searchTriggered').and.callThrough().and.stub();
    const event = new KeyboardEvent('keydown', {
      key: 'Space'
    });
    inputDom.dispatchEvent(event);
    fixture.detectChanges();
    expect(leftSidebarService.searchTriggered).toHaveBeenCalledTimes(0);
  }));
});

