import { Directive, ElementRef, HostListener, Input, Renderer } from '@angular/core';

@Directive({
  selector: '[appInputRestriction]'
})
export class InputRestrictionDirective {
  inputElement: ElementRef;
  renderer: Renderer;

  @Input('appInputRestriction') appInputRestriction: string;

  constructor(el: ElementRef, _renderer: Renderer) {
    this.inputElement = el;
    this.renderer = _renderer;
  }

  @HostListener('keypress', ['$event']) onKeyPress(event) {
    if (this.appInputRestriction === 'integer') {
      this.integerOnly(event);
    } else if (this.appInputRestriction === 'noSpecialChars') {
      this.noSpecialChars(event);
    }
  }

  integerOnly(event) {
    const e = <KeyboardEvent>event;
    if (e.key === 'Tab' || e.key === 'TAB') {
      return;
    }
    if ([46, 8, 9, 27, 13, 110].indexOf(e.keyCode) !== -1 ||
      // Allow: Ctrl+A
      (e.keyCode === 65 && e.ctrlKey === true) ||
      // Allow: Ctrl+C
      (e.keyCode === 67 && e.ctrlKey === true) ||
      // Allow: Ctrl+V
      (e.keyCode === 86 && e.ctrlKey === true) ||
      // Allow: Ctrl+X
      (e.keyCode === 88 && e.ctrlKey === true)) {
      // let it happen, don't do anything
      return;
    }
    if (['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].indexOf(e.key) === -1) {
      e.preventDefault();
    }
  }

  noSpecialChars(event) {
    const e = <KeyboardEvent>event;
    if (e.key === 'Tab' || e.key === 'TAB') {
      return;
    }
    let k;
    k = event.keyCode;  // k = event.charCode;  (Both can be used)
    if ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || k === 32 || k === 42 || (k >= 48 && k <= 57)) {
      return;
    }
    e.preventDefault();
  }

  @HostListener('paste', ['$event']) onPaste(event: ClipboardEvent) {
    let regex;
    if (this.appInputRestriction === 'integer') {
      regex = /[0-9]/g;
    } else if (this.appInputRestriction === 'noSpecialChars') {
      regex = /[a-zA-Z0-9\u0600-\u06FF]/g;
    }
    const e = event;
    const pasteData = e.clipboardData.getData('text/plain');
    let m;
    let matches = 0;
    while ((m = regex.exec(pasteData)) !== null) {
      // This is necessary to avoid infinite loops with zero-width matches
      if (m.index === regex.lastIndex) {
        regex.lastIndex++;
      }
      // The result can be accessed through the `m`-variable.
      m.forEach((match, groupIndex) => {
        matches++;
      });
    }
    if (matches === pasteData.length) {
      // remove invalid paste attribute if text is valid
      this.renderer.setElementAttribute(this.inputElement.nativeElement, 'invalid-paste', null);
      return;
    } else {
      event.stopImmediatePropagation();
      // add additinal attribute to specify if there is invalid paste already
      this.renderer.setElementAttribute(this.inputElement.nativeElement, 'invalid-paste', 'true');
      return false;
    }
  }

}

@Directive({
  selector: '[appToUpperCase]'
})
export class ToUpperCaseDirective {
  elementRef;
  constructor(el: ElementRef, _renderer: Renderer) {
    this.elementRef = el;
  }

  @HostListener('input', ['$event']) onKeyDown(event: any) {
    if ([46, 8, 9, 27, 13, 110].indexOf(event.keyCode) !== -1 ||
      // Allow: Ctrl+A
      (event.keyCode === 65 && event.ctrlKey === true) ||
      // Allow: Ctrl+C
      (event.keyCode === 67 && event.ctrlKey === true) ||
      // Allow: Ctrl+V
      (event.keyCode === 86 && event.ctrlKey === true) ||
      // Allow: Ctrl+X
      (event.keyCode === 88 && event.ctrlKey === true)) {
      // let it happen, don't do anything
      return;
    }
    if (event.target['value']) {
      const data = event.target['value'].toUpperCase();
      if (event.target['value'] === data) {
        return false;
      } else {
        event.target['value'] = data;
        event.stopPropagation(); // stop propagation
        // must create a "input" event, if not, there are no change in your value
        const evt = document.createEvent('HTMLEvents');
        evt.initEvent('input', false, true);
        event.target.dispatchEvent(evt);
      }
    }

  }
  @HostListener('paste', ['$event']) onPaste(event) {
    const e = <ClipboardEvent>event;
    const pasteData = e.clipboardData.getData('text/plain');
    // check if already a paste event happend with invalid input
    const isInvalidInput = this.elementRef.nativeElement.getAttribute('invalid-paste');
    if (pasteData && !isInvalidInput) {
      event.target['value'] += pasteData.toUpperCase();
      event.stopImmediatePropagation(); // stop propagation
      event.stopPropagation();
      event.preventDefault();
      // must create a "input" event, if not, there are no change in your value
      const evt = document.createEvent('HTMLEvents');
      evt.initEvent('input', false, true);
      event.target.dispatchEvent(evt);
    }

  }

}
