import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { SharedModule } from '../shared.module';
import { BaseFormGroup } from '../forms/base-form-group';
import { BaseFormControl } from '../forms/base-form-control';

@Component({
  template: `<form id="pdf-menu" novalidate [formGroup]="textSearchFormGroup">
  <input type="text" formControlName="term" class="form-control" appAutofocus>
  </form>`
})
class TestComponent {
  /** Search Text Form Group */
  textSearchFormGroup: BaseFormGroup;

  /** Search Text - Input Form Control */
  textSearchControl: BaseFormControl;

  constructor() {
    this.textSearchControl = new BaseFormControl('Text Search', 'term', 'text', '', [], []);
    this.textSearchFormGroup = new BaseFormGroup('textSearchForm', {
      term: this.textSearchControl
    });
  }
}

describe('AutofocusDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), HttpClientTestingModule, RouterTestingModule],
      declarations: [TestComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
  }));

  it('should create', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should focus input on load', async(() => {
    fixture.detectChanges();
    const focusedElements = document.activeElement;
    expect(focusedElements.classList.contains('form-control')).toBe(true);
  }));
});

