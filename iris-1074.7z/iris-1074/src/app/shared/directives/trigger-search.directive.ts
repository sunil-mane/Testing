import { Directive, HostListener } from '@angular/core';
import { LeftSidebarService } from '../services/left-sidebar.service';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appTriggerSearch]'
})
export class TriggerSearchDirective {

  constructor(private leftSidebarService: LeftSidebarService, private control: NgControl) { }

  /**
   * Stop Enter keydown propagation to fix dropdown getting focused on enter issue
   * Trigger search
   * @param {any} event the event object
   */
  @HostListener('keydown', ['$event'])
  public stopPropagationOfEnter(event: KeyboardEvent) {
    // if tab is pressed and form control is not valid then reset it.
    if (event.keyCode === 9 || event.key.toLowerCase() === 'tab') {
      setTimeout(() => {
        if (!this.control.valid) {
          this.control.reset();
        }
      });
    }
    if (event.keyCode === 13 || event.key.toLowerCase() === 'enter') {
      (<HTMLInputElement>event.target).blur();
      setTimeout(() => {
        // if control is not valid then reset field
        if (this.control.valid) {
          this.leftSidebarService.searchTriggered(true, true);
          event.stopPropagation();
          event.preventDefault();
        } else {
          this.control.reset();
        }
      });
    }
  }
}
