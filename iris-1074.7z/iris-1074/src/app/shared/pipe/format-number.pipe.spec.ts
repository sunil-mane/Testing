import { FormatNumberPipe } from './format-number.pipe';

describe('FormatNumberPipe', () => {
  let pipe: FormatNumberPipe;

  beforeEach(() => {
    pipe = new FormatNumberPipe();
  });

  it('should ignore string input', () => {
    expect(pipe.transform('string')).toEqual('string');
  });

  it('should reformat comma-able number', () => {
    expect(pipe.transform(1000)).toEqual('1,000');
  });

  it('should not add commas unless necessary', () => {
    expect(pipe.transform(100)).toEqual('100');
  });
});
