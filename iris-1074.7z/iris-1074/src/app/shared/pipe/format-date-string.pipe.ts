import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
/**
 * If given date is valid date then format it else return as it is
 */
@Pipe({
  name: 'formatDateString'
})
export class FormatDateStringPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (moment(value).isValid()) {
      return moment.parseZone(value).format(args);
    } else {
      return value;
    }
  }

}
