/**
 * Format number pipe
 */
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatNumber'
})
export class FormatNumberPipe implements PipeTransform {
  /**
   * Transform number into comma separated value
   *
   * Bypasses value if it is a string.
   *
   * @param value Value to transform
   */
  transform(value: number | string): string {
    if (typeof value === 'string') {
      return value;
    }

    const parts = value.toString().split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    return parts.join('.');
  }

}
