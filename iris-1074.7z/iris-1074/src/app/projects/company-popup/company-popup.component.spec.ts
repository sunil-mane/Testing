import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';

import { CompanyPopupComponent } from './company-popup.component';
import { RightSlidepanelService } from '../../shared/services/right-slidepanel.service';
import { SharedModule } from '../../shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Lookups } from '../../../mocks/lookups';
describe('CompanyPopupComponent', () => {
  let component: CompanyPopupComponent;
  let fixture: ComponentFixture<CompanyPopupComponent>;
  let rightSideBarService: RightSlidepanelService;
  let httpMock: HttpTestingController;
  const companyMock = Lookups.getCompanies(1212);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule.forRoot(), RouterTestingModule, HttpClientTestingModule],
      declarations: [],
      providers: [RightSlidepanelService]
    })
      .compileComponents();
  }));
  afterEach(() => {
    httpMock.verify();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyPopupComponent);
    component = fixture.componentInstance;
    rightSideBarService = component.rightPanelService;
    // fixture.detectChanges();
    httpMock = getTestBed().get(HttpTestingController);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should initialize variables', () => {
  //   fixture.detectChanges();
  //   expect(rightSideBarService.showRightPanel).toBe(false);
  //   expect(component.companyList).toBeTruthy();
  // });

  // it('should receive project number when subscriber is called', async () => {
  //   const spy = spyOn(rightSideBarService, 'getCompaniesForProject').and.returnValue(Promise.resolve([]));
  //   component.rightPanelService.setProjectNumber(2);
  //   fixture.detectChanges();
  //   component.rightPanelService.ProjectNumber.subscribe((projectNumber: number) => {
  //     expect(projectNumber).toEqual(2);
  //   });
  // });

  // it('should receive project number when subscriber is called 1', async () => {
  //   component.rightPanelService.setProjectNumber(2);
  //   fixture.detectChanges();
  //   component.rightPanelService.ProjectNumber.subscribe((data: any) => {
  //     expect(data).toBeTruthy();
  //   });
  //   const req = httpMock.expectOne(`https://api.dodgedev.com/cc/iris/project/2/companies`);
  //   expect(req.request.method).toBe('GET');
  //   req.flush(companyMock);
  // });

  // it('should call company api if project number subscriber is called', async () => {
  //   const spy = spyOn(rightSideBarService, 'getCompaniesForProject').and.returnValue(Promise.resolve([]));
  //   // spyOn(apiService, 'fetchData').and.returnValue(Promise.resolve(promisedData));
  //   component.rightPanelService.setProjectNumber(2);
  //   fixture.detectChanges();
  //   component.rightPanelService.ProjectNumber.subscribe((projectNumber: number) => {
  //     if (projectNumber > 0) {
  //       expect(spy).toHaveBeenCalled();
  //     }
  //   });
  // });
});
