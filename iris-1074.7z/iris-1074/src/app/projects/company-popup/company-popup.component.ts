import { Component, OnInit, OnDestroy } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';
import { Subscription } from 'rxjs';
import { RightSlidepanelService } from '../../shared/services/right-slidepanel.service';
import { Company } from '../../shared/models/CompanyPopupLookup';
import { AlertService } from '../../shared/services/alert.service';

/**
 * Company popup component
 */
@Component({
  selector: 'app-company-popup',
  templateUrl: './company-popup.component.html',
  styleUrls: ['./company-popup.component.scss'],
  animations: [
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({ transform: 'translateX(100%)', opacity: 0 }),
          animate('500ms', style({ transform: 'translateX(0)', opacity: 1 }))
        ]),
        transition(':leave', [
          style({ transform: 'translateX(0)', opacity: 1 }),
          animate('500ms', style({ transform: 'translateX(100%)', opacity: 0 }))
        ])
      ]
    )
  ]
})
export class CompanyPopupComponent implements OnInit, OnDestroy {
  // list of companies
  companyList: Company[] = [];
  // Observable subscription
  ProjectNumberSubscription: Subscription;

  // constructor
  constructor(public rightPanelService: RightSlidepanelService, private alertService: AlertService) { }

  /**
   * ngOnInit method
   */
  ngOnInit() {
    // subscribe for project number change from right panel service
    this.ProjectNumberSubscription = this.rightPanelService.ProjectNumber.subscribe((projectNumber: number) => {
      // if number is greater than 0 then call api
      this.alertService.clear();
      if (projectNumber > 0) {
        this.rightPanelService.getCompaniesForProject(projectNumber).then((companies: Company[]) => {
          this.rightPanelService.showRightPanel = true;
          this.companyList = companies;
        }).catch((reason) => {
          this.alertService.error(reason.error.data);
        });
      }
    });
  }

  ngOnDestroy() {
    if (this.ProjectNumberSubscription) {
      this.ProjectNumberSubscription.unsubscribe();
    }
    this.rightPanelService.showRightPanel = false;
    this.rightPanelService.setProjectNumber(null);
  }
}
