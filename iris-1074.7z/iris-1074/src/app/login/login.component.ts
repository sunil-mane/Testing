import { Component, OnInit } from '@angular/core';
import { getTokenContent, AuthToken } from '@dodge/js-auth-client';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/services/auth.service';

@Component({
  template: 'Logging you in..'
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private authService: AuthService) { }

  ngOnInit() {
    const params = this.activatedRoute.snapshot.queryParams;
    if (params['accessToken']) {
      const rawToken = params['accessToken'];
      const refreshToken = params['refreshToken'];
      // const expiresAt = params['expiresAt'];
      // const decodedToken = getTokenContent(rawToken);
      this.authService.setStorage(new AuthToken(rawToken, refreshToken));
    }

    this.router.navigate(['dashboard']);
  }

}
