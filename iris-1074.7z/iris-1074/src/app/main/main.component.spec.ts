import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MainComponent } from './main.component';
import { SharedModule } from '../shared/shared.module';


describe('MainComponent', () => {
  let component: MainComponent;
  let fixture: ComponentFixture<MainComponent>;
  let dom: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgbModule.forRoot(), SharedModule.forRoot()],
      declarations: [ MainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MainComponent);
    component = fixture.debugElement.componentInstance;
    dom = fixture.debugElement.nativeElement;
  }));
  it('should create the app', async(() => {
    expect(component).toBeTruthy();
  }));
  it(`should have common header`, async(() => {
    expect(dom.querySelector('app-header')).toBeTruthy();
  }));
  it(`should have common left nav`, async(() => {
    expect(dom.querySelector('app-left-nav')).toBeTruthy();
  }));
});
