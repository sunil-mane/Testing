/* SystemJS module definition */
declare var module: NodeModule;

interface NodeModule {
  id: string;
}

/* Include json files for configuration */
declare module '*.json' {
  const value: any;
  export default value;
}

declare var SLLogger: any;
