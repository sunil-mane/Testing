export const environment = {
  production: true,
  apiPath: '/iris/',
  apiSvcUrl: 'https://qa.api.construction.com/cc',
  apiAuthorizationHeader: 'Bearer eyJraWQiOiJHREtma21sT3NSbVcxbGN5M25vbUM4K0pQNnhXa21iMm1SVEJmVHprb2F3PSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI1ZTE2Mjk5My0yMmUyLTQyYjEtYjc1Mi02ZDFkY2ZmOTZlZDciLCJldmVudF9pZCI6ImJiYjhkMDVmLTcwYWItMTFlOC1hNmExLTgxMzM0NTIyNTY2NiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYXdzLmNvZ25pdG8uc2lnbmluLnVzZXIuYWRtaW4iLCJhdXRoX3RpbWUiOjE1MjkwNzQzNTIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX3J3UFdOYUI1ZyIsImV4cCI6MTUyOTA3Nzk1MiwiaWF0IjoxNTI5MDc0MzUyLCJqdGkiOiJmMjY5YjMzNS1jMDYxLTQwNWQtODNjMC0xZDJjNGNhZDRmMTIiLCJjbGllbnRfaWQiOiI2azM3dnVuZnQ1dmV1ZzFodjducmo3dW8xdiIsInVzZXJuYW1lIjoiaXJpcy5kZXZlbG9wZXJAY29uc3RydWN0aW9uLmNvbSJ9.LsiNXEWF4NBMufBBYukRKvWfWaRmksAIBbkUlMO9E6NLRxKHRi79Fc_MVgpZRLkVpKOp0ozTbLvq6Tp-02nAL6OWJqT359uX7yS3utlamdrpOzmA-jMx5DnA_mnIcGoal49sd4JuhOODm1tDQrnmquB0SreyW2UAMcTzbh7-IX1lDBRRHOfNyNrydWpW73bxysgmQY9FQaxXIH9-VfW_3Wjfl7iv-ruu_vO3SoOPbmOQ1HMgAddsk5qyGfiUgbHZVkqI21zYAFAepkq88GfDIqZXZizwywXEiPc-5rU8EMcrHra5wR9SC7cMoWGC3S4kN1d-fceq92pmUbSOjvTYCw',
  isDebugMode: false,
  logToConsole: false,
  defaultDateFormat: 'MM/DD/YYYY',
  apiDateFormat: 'YYYY-MM-DD',
  sumoLogicUrl: 'https://endpoint1.collection.us2.sumologic.com/receiver/v1/http/',
  sumoLogicCC: 'ZaVnC4dhaV217v_DVmfOk7yd1JkIX4_rlf5mr0k0f8GR7HoGRjhkHvPB5dQewtlyK0Gf8e1eJ0SNGeU4n0vA4ndCKK8oVbAs04h2MVFM64BbNXlPddescw==',
  siteUrl: 'https://qa.iris.construction.com',
  ssoUrl: 'https://qa.auth.construction.com',
  ssoHost: 'https://qa.api.construction.com',
  JAPIHost: 'http://dev-nlb2-common-nlb-335307cc4cfd4b86.elb.us-east-1.amazonaws.com:1024/japi_user_details/preference',
  appId: 'IRIS',
  enableMocks: false
};
