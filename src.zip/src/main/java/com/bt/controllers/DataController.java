package com.bt.controllers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bt.exceptions.InvalidRequestException;
import com.bt.jsonBean.AuthResponse;
import com.bt.jsonBean.BulkSearch;
import com.bt.jsonBean.Credentials;
import com.bt.jsonBean.ErrorResponce;
import com.bt.jsonBean.SearchResponse;
import com.bt.lucene.LuceneTester;
import com.bt.services.V21Properties;
import com.bt.services.V21SearchHelper;
import com.bt.services.V21SearchServices;
import com.bt.util.V21FileUtility;

@RestController
public class DataController {
	static String FS = File.separator;
	
	LuceneTester tester = new LuceneTester();
	V21SearchServices searchService= new V21SearchServices();
	V21SearchHelper searchHelper= new V21SearchHelper();
	String dirPath= searchHelper.dataDir+FS;
	@Autowired
	private V21Properties v21Properties;
	
	@RequestMapping(value = "/search", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public SearchResponse  getListOfFlows(
			@RequestParam(value="emsId",required=false) String emsId,
			@RequestParam(value="date",required=false) String date,
			@RequestParam(value="flowId",required=false)String flowId,
			@RequestParam(value="errorCode",required=false)String errorCode,
			@RequestParam(value="emailResult",required=false)String emailResult,
			@RequestParam(value="jsonObject",required=false)String jsonObject,
			@RequestParam(value="error",required=false)String error
			) {
		if (emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && (flowId==null || "".equals(flowId)) && (null!=error && !"".equals(error))) {
			
			System.out.println("Third use case:with Error Code for EMS ID: firstSearchCall"+dirPath);
			
			//throw new InvalidRequestException("EmsId not Found", "EMS Id: 101", null);
			return searchService.firstSearchCall(emsId, date, error);
		}
		
		else if (emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && (flowId!=null || !"".equals(flowId)) && (null!=error && !"".equals(error))) {
			
			System.out.println("Third use case:with Error Code for Flow ID: "+flowId);
			
			//throw new InvalidRequestException("EmsId not Found", "EMS Id: 101", null);
			return searchService.secondUseCase(date, flowId, error);
		}
		
		else if (emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && (flowId==null || "".equals(flowId))) {
			
			System.out.println("First use case: firstSearchCall"+dirPath);
			
			//throw new InvalidRequestException("EmsId not Found", "EMS Id: 101", null);
			return searchService.firstSearchCall(emsId, date);
		}else if (!(flowId==null || "".equals(flowId)) && date!=null && !"".equals(date) && errorCode!=null && !"".equals(errorCode)) {
			System.out.println("Second Use Case");
			boolean err=false;
			if (errorCode.equals("true")) {
				  err = true;
			}  
			
			return searchService.secondUseCase(searchHelper.dateForOperation(date), flowId,err);
		}else if(emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && (flowId!=null || !"".equals(flowId))) {
			System.out.println("First use case: secondSearchCall :"+emsId);
			return searchService.secondSearchCall(emsId, date, flowId);
		}else if (!(flowId==null || "".equals(flowId)) && date!=null && !"".equals(date)){
			String flowIds[]=flowId.split(",");
			
			if (flowIds.length>1) {
				System.out.println("Fourth Use Case");
				return searchService.fourthUseCase(searchHelper.dateForOperation(date), flowIds,false);
			}else {
				System.out.println("Second Use Case");
				return searchService.secondUseCase(searchHelper.dateForOperation(date), flowId,false);
			}
			
			
		}else if (date!=null && !"".equals(date) && (errorCode!=null || !"".equals(errorCode))) {
			List<String> errors=new ArrayList<String>();
			for(String error1:errorCode.split(",")){
				errors.add(error1);
			}
			System.out.println("Third Use Case");
			return searchService.thirdUseCase(searchHelper.dateForOperation(date), errors);
		}
		/*else if (null!=emailResult && ""!=emailResult && null!=jsonObject ) {
			
			System.out.println("Send Email....");
			return searchService.sendEmail(emailResult, jsonObject);
		}*/
		
		else {
			return null;
		}
		 


	}
	
	@RequestMapping(value = "/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public SearchResponse  getBulkSearchResult(
			
			@RequestBody BulkSearch bulkSearch
			) {
		System.out.println(bulkSearch.toString());
			System.out.println("Bulk search initiated");
			 System.out.println(bulkSearch.toString());
			if (bulkSearch!=null) {
				String flowIds[]=bulkSearch.getFlowId().split(",");
				
				if (flowIds.length>0) {
					System.out.println("Fourth Use Case");
					return searchService.fourthUseCase(searchHelper.dateForOperation(bulkSearch.getDate()), flowIds,false);
				}/*else {
					System.out.println("Second Use Case");
					return searchService.secondUseCase(searchHelper.dateForOperation(bulkSearch.getDate()), bulkSearch.getFlowId(),false);
				}*/
			}
			return null;
			
	}

	@RequestMapping(value = "/searchFile", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public String  getListOfFiles(
			@RequestParam("emsId") String emsId,
			@RequestParam("date") String date,
			@RequestParam(value="flowId",required=false)String flowId,
			@RequestParam(value="fileName",required=false)String fileName
			) {
		String xmlFile="";
		System.out.println("executing searchFile");
		if (emsId!=null && !"".equals(emsId) && date!=null && !"".equals(date) && flowId!=null || !"".equals(flowId)&& fileName!=null || !"".equals(fileName)) {
			System.out.println("inside searchFile :"+fileName);
			
			date=searchHelper.dateForOperation(date);
			String newPath=dirPath+FS+date+FS+emsId+FS+flowId+FS+fileName;
			System.out.println("newPath :"+newPath);
			File file = new File(dirPath+FS+date+FS+emsId+FS+flowId+FS+fileName);
			if (file.exists()) {
				try {
					
					BufferedReader br = new BufferedReader(new FileReader(file));
					String sCurrentLine;
					while ((sCurrentLine = br.readLine()) != null) {
						xmlFile+=sCurrentLine;
					}
					br.close();
				} catch (Exception e) {
				}
			}else {
				System.out.println("dir not exist");
				throw new InvalidRequestException("Invalid Entry", "emsId: "+emsId);
			}
			
		}else {
			 
		}
		return xmlFile;

	}
	
	@RequestMapping(value = "/zip", method = RequestMethod.POST, produces="application/zip")
    public byte[] zipFiles(@RequestBody SearchResponse searchResponse) {
		
		return V21FileUtility.zipFiles(searchResponse);
		
	}
	
	
	@RequestMapping(value = "/sendEmail",method = RequestMethod.POST, produces="application/json")
	public ErrorResponce sendEmail(@RequestBody SearchResponse searchResponse, 
			@RequestParam("emailResult") String emailResult ){
		ErrorResponce response=new ErrorResponce();
		
		if (null!=emailResult && ""!=emailResult && null!=searchResponse ) {
			
			System.out.println("Send Email....");
			response=searchService.sendEmail(emailResult, searchResponse);
			if(("Success")!=response.getMessage()){
				throw new InvalidRequestException("Error while sending Email to "+emailResult);
			}
			return response;			
		}
		else{			
			response.setMessage("Failure");
			throw new InvalidRequestException("Error while sending Email to "+emailResult);
		}
		
		}

	


	  @RequestMapping(value = "/authUser",method = RequestMethod.POST)
      public AuthResponse authUser(@RequestBody Credentials credentials)
      {
            //v21Properties.setCredentialsStr(credentialsStr);
            System.out.println("Authenticating user: ");
            AuthResponse response=new AuthResponse();
            if (null!=credentials ) {

                  if(searchService.validateUser(credentials,v21Properties.getAllUsers())){            

                        response.setAuthToken(credentials);       
                        System.out.println("User Authenticated");
                        
                  }else {
                        response.setAuthToken(null);  
                        System.out.println("Invalid user");
                  }
            }
            return response;
            

      }


}
	