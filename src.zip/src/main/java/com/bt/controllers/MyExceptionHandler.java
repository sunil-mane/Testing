package com.bt.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bt.jsonBean.ErrorResponce;
import com.bt.exceptions.InvalidRequestException;

@ControllerAdvice
public class MyExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({ InvalidRequestException.class })
     
    protected ResponseEntity<Object> handleInvalidRequest(InvalidRequestException e, WebRequest request) {
       System.out.println("Exception Caughr : InvalidRequestException");
       ErrorResponce responce = new ErrorResponce();
       responce.setMessage(e.getMessage());
       responce.setCode(e.getCode());
        return handleExceptionInternal(e, responce,null, HttpStatus.UNPROCESSABLE_ENTITY, request);
    }

}