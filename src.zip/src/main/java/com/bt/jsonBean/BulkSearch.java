package com.bt.jsonBean;

public class BulkSearch {
	public String getDate() {
		return date;
	}
	@Override
	public String toString() {
		return "BulkSearch [date=" + date + ", flowId=" + flowId + "]";
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getFlowId() {
		return flowId;
	}
	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}
	private String date;
	private String flowId;
}
