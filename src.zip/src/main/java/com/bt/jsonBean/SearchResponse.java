package com.bt.jsonBean;

public class SearchResponse {
	
	private SearchCriteria search;
	private SearchResult result;
	
	public SearchCriteria getSearch() {
		return search;
	}
	public void setSearch(SearchCriteria search) {
		this.search = search;
	}
	public SearchResult getResult() {
		return result;
	}
	public void setResult(SearchResult result) {
		this.result = result;
	}
	
	
	
}
