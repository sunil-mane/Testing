package com.bt.jsonBean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sun.org.apache.xml.internal.security.utils.Base64;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthResponse {
	
	private String authToken;

	
	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(Credentials credentials) {
		if (credentials!=null) {
			String userdetails=credentials.getUsername()+":"+credentials.getPassword();
			this.authToken=Base64.encode(userdetails.getBytes());
		}
	}

	
}	
    
    
	