package com.bt.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.springframework.web.bind.annotation.RequestParam;

import com.bt.jsonBean.SearchResponse;
import com.bt.services.V21SearchHelper;

public class V21FileUtility {

	static String FS = File.separator;
	
	public static Properties loadPropertyFile(String configPath){
		System.out.println("Inside LoadPropertyFile .. ");
		
		FileInputStream fileInputSteam=null;
		Properties props = new Properties();
		try {
			fileInputSteam = new FileInputStream(configPath);
			props.load(fileInputSteam);
			
		} catch (Exception e) {
				// TODO Auto-generated catch block
			System.err.println("Error occured in loadProperty Method");	
			e.printStackTrace();
				
		}
		finally{
			try {
				if(null!=fileInputSteam){
					fileInputSteam.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.err.println("Error occured while closing fileInputStream in loadProperty Method");
				e.printStackTrace();
			}
		}
		return props;
		
	}
	
	
	public static void zipFile(List<String> filesList, String zipFilePath) { 

	       try { 

	           FileOutputStream fileOutputStream = new FileOutputStream(zipFilePath); 

	           ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream); 
	           
	           for(String filepath:filesList){
	        	   File inputFile=new File(filepath);
	           
		           ZipEntry zipEntry = new ZipEntry(inputFile.getName()); 
		           zipOutputStream.putNextEntry(zipEntry);
		           FileInputStream fileInputStream = new FileInputStream(inputFile); 
		           byte[] buf = new byte[1024]; 
		           int bytesRead; 
		           while ((bytesRead = fileInputStream.read(buf)) > 0) { 
		               zipOutputStream.write(buf, 0, bytesRead); 
		           } 
		           fileInputStream.close();
		           System.out.println("Regular file :" + inputFile.getCanonicalPath()+" is zipped to archive :"+zipFilePath);
	           }
	           
	           
	           zipOutputStream.closeEntry();
	           zipOutputStream.close(); 
	           fileOutputStream.close(); 
	           
	           System.out.println("Done file Zipping "); 
	       } catch (IOException e) { 
	           e.printStackTrace(); 
	       } 
	   } 

	
	public ArrayList<File> getFileListFromJson(SearchResponse searchResponse){
		ArrayList<File> files = new ArrayList<File>();
		
		if(searchResponse!=null){
			List<com.bt.jsonBean.SearchList> resultList=searchResponse.getResult().getData();
			
			V21SearchHelper helper=new V21SearchHelper();
			
			
			
			
			//String href="search?date=06-10-16&emsId=100&flowId=566343512&filename=Response_Him_DSLM_55193063_114088737_19_Aug_16_21_45_03_661.xml";
			String href="";
			
			for(com.bt.jsonBean.SearchList sList:resultList){
				String filePath=helper.dataDir;
				 href=sList.getHref();	
				 System.out.println("here Href: "+href);
				 String[] pathArray=href.split("&");
				 
				 for(int i=0;i<pathArray.length;i++){
					 System.out.println("here pathArray: "+pathArray[i]);
					 String token=pathArray[i];
					 if(token.contains("date") && token.contains("-")){
						token= token.replaceAll("-", "_");
					 }
					 if(token.contains("2016")){
							token= token.replaceAll("2016", "16");
						 }
					 token=token.substring(token.indexOf('='));
					 filePath=filePath+token.trim();				
				 }
				 filePath= filePath.replaceAll("=", FS).trim();
				 filePath=filePath.replaceAll(FS+FS, FS);
				 System.out.println("filePath here after "+filePath);				 
				 
				 files.add(new File(filePath));
			}
			
		}
		else{
			System.out.println("Received invaild searchResponse");
		}
		
		return files;
	}
	
	
	 public static List<File> getAllFiles(File dir, List<File> fileList) {
	 		try {
	 			File[] files = dir.listFiles();
	 			System.out.println("Dir path "+dir.getAbsolutePath());
	 			for (File file : files) {
	 				fileList.add(file);
	 				if (file.isDirectory()) {
	 					System.out.println("directory:" + file.getCanonicalPath());
	 					getAllFiles(file, fileList);
	 				} else {
	 					System.out.println("     file:" + file.getCanonicalPath());
	 				}
	 			}
	 		} catch (IOException e) {
	 			e.printStackTrace();
	 		}
	 		return fileList;
	 	}
	
	 public static byte[] zipFiles(SearchResponse searchReponseObject) {
	        //setting headers
	       
			if(null!= searchReponseObject){
			//SearchResponse searchReponseObject=(SearchResponse) jsonObject;
			List<File> files = new ArrayList<File>();
			List<File> newFiles = new ArrayList<File>();
		
			V21FileUtility util=new V21FileUtility();
			files=util.getFileListFromJson(searchReponseObject);
			for(File dirpath:files){
				newFiles=getAllFiles(dirpath, newFiles);
			}
			//files=util.getFileListFromJson(null);
			
	        try {
	        	//creating byteArray stream, make it bufforable and passing this buffor to ZipOutputStream
		        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(byteArrayOutputStream);
		        ZipOutputStream zipOutputStream = new ZipOutputStream(bufferedOutputStream);
		              
		        //packing files
		        for (File file : newFiles) {
		        	
		            //new zip entry and copying inputstream with file to zipOutputStream, after all closing streams
		            zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
		            FileInputStream fileInputStream = new FileInputStream(file);
		            IOUtils.copy(fileInputStream, zipOutputStream);
						
		            fileInputStream.close();
		            zipOutputStream.closeEntry();
		        	
		        }
		
		        if (zipOutputStream != null) {
		            zipOutputStream.finish();
		            zipOutputStream.flush();
		            IOUtils.closeQuietly(zipOutputStream);
		        }
		        IOUtils.closeQuietly(bufferedOutputStream);
		        IOUtils.closeQuietly(byteArrayOutputStream);
		        return byteArrayOutputStream.toByteArray();
	        
	        } catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Exception while Zipping files");
					return null;
				} 
			}
			else{
				System.out.println("Received empty json Object");
				return null;
			}
	    }
	
	 
	 
	
	 
}
