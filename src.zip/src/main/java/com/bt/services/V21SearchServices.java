package com.bt.services;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bt.exceptions.InvalidRequestException;
import com.bt.jsonBean.Credentials;
import com.bt.jsonBean.ErrorResponce;
import com.bt.jsonBean.SearchCriteria;
import com.bt.jsonBean.SearchList;
import com.bt.jsonBean.SearchResponse;
import com.bt.jsonBean.SearchResult;

public class V21SearchServices {
	
	V21SearchHelper helper = new V21SearchHelper();
	static String FS = File.separator; 
	
	
	public SearchResponse fourthUseCase(String dateForOperation, String[] flowIds, boolean b) {

		SearchResponse response = new SearchResponse();
		SearchResult result=helper.searchWithFlowIDs(dateForOperation, Arrays.asList(flowIds), false);
		response.setResult(result);
		return response;
	}



	public SearchResponse thirdUseCase(String dateForOperation, List<String> errors) {
		SearchResult result=	helper.searchErrorFiles(dateForOperation, errors);
		SearchResponse response = new SearchResponse();
		response.setResult(result);
		return response;
	}



	public SearchResponse secondUseCase(String date, String flowId,Boolean errorCode) {
		SearchResult  result=null;
		
		List<String> flowIds=new ArrayList<String>();
		flowIds.add(flowId);
		
		if (errorCode) {
			result=helper.searchWithFlowIDs(date, flowIds, false,true);
		} else {
			
			result=helper.searchWithFlowIDs(date, flowIds, false,false);
		} 
		
		SearchResponse response = new SearchResponse();
		response.setResult(result);
		return response;
		
		}
	
	
	public SearchResponse secondUseCase(String date, String flowId,String error) {
		SearchResult  result=null;
		String flowIdNew="";
		String emsId="";
		String href="";
		String fileName="";
		 List<SearchList> searchLists=new ArrayList<SearchList>();			
		
		List<String> errorFileList=new ArrayList<String>();
		List<String> flowIds=new ArrayList<String>();
		flowIds.add(flowId);
		
		errorFileList=helper.searchWithFlowIDs(date, flowIds, error,true);
		
		
		int count=0;
		  HashMap<String, String> map=new HashMap<String, String>();
		  for(String filePath:errorFileList){
			   SearchList searchList=new SearchList();
			  
			   String[] filenames=filePath.split(FS);
			   
			   System.out.println("filenames--len"+filenames.length);
				  for(int j=filenames.length-1;j>=0;j--){
					  
					  fileName=filenames[j];
					   System.out.println("filename--len"+fileName);
					  
					  flowId=filenames[j-1];
					   System.out.println("flowId--len"+flowId);									   

					  emsId=filenames[j-2];
					   System.out.println("emsId--len"+emsId);

					  date=filenames[j-3];	
					   System.out.println("date--len"+date);

					  href="search?date="+helper.dateToUser(date)+"&emsId="+emsId+"&flowId="+flowId+"&fileName="+fileName;;
					   System.out.println("href--len"+href);
					   map.put(flowId, href);

					  break;
				  }
			   
			   
		   }	
		  
		  Set<String> keys=map.keySet();
		  for(String s:keys){
			  SearchList searchList=new SearchList();
			  searchList.setHref(map.get(s));
			   searchList.setId(flowId);
			   searchList.setLabel(flowId);	
			   searchLists.add(searchList);
			   count++;
		  }	
			
			
		
		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		
		return response;
		
		}
	
	
	public List<String> ThurdUseCaseWithFlowID(String date, List<String> flowIds, String errorCode) {
		SearchResult  result=null;	
		
		List<String> errorFileList=new ArrayList<String>();
		
		errorFileList=helper.searchWithFlowIDs(date, flowIds, errorCode,true);
		return errorFileList;
		
		
		
		
		}
	
	
	public SearchResponse firstSearchCall(String emsId, String date) {
		System.out.println("firstSearchCall");
		List<SearchList> searchLists = new ArrayList<SearchList>();
		date=helper.dateForOperation(date);
		String dir=V21SearchHelper.dataDir+FS+date;
		System.out.println("First search call 1"+dir);
		File dateDir = new File(dir);
		System.out.println("dateDir---1"+dateDir);

		if (dateDir.exists()) {

			File emsIdDir = new File(dir+FS+emsId);
			
			System.out.println("emsIdDir---1"+emsIdDir);

			if (emsIdDir.exists()) {

				File listOfFiles[]=emsIdDir.listFiles();
				System.out.println("ListOfFiles---1"+listOfFiles.length);

				for (int i = 0; i < listOfFiles.length; i++) {
					File flowIdFile=listOfFiles[i];
					if (flowIdFile.isDirectory()) {

						SearchList searchList = new SearchList();

						String id=flowIdFile.getName();
						
						String tmpStr[]=flowIdFile.getName().split("_");
						String label=tmpStr[0];
						
						System.out.println("label---1"+label);

						searchList.setLabel(label);

						//String flowPath=flowIdFile.getPath();

						String href="search?date="+helper.dateToUser(date)+"&&emsId="+emsId+"&&flowId="+id+"";
						System.out.println("href---1"+href);
						//search?date=01-10-2016&emsId=emsId-100&flowId=100_111
						searchList.setId(flowIdFile.getName());
						searchList.setHref(href);

						searchLists.add(searchList);
						
						System.out.println("href "+href);

					}else {
						continue;
					}
				}
				System.out.println(searchLists.size());
				
			}else {
				System.out.println("emsId dir not exist");
				throw new InvalidRequestException("V21 has not received the request with the desired EMS id within the specified date range or please check if the EMS Id : " +emsId+ " is correct or not.", "emsId: "+emsId);
			}
		}else {
			System.out.println("date dir not exist");
			throw new InvalidRequestException("Invalid Date", "Date: "+helper.dateToUser(date));
		}

		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		return response;
	}


	public SearchResponse firstSearchCall(String emsId, String date, String error) {
		System.out.println("firstSearchCall with ErrorCode");
		List<SearchList> searchLists = new ArrayList<SearchList>();
		date=helper.dateForOperation(date);
		String dir=V21SearchHelper.dataDir+FS+date;
		System.out.println("First search call 1"+dir);
		File dateDir = new File(dir);
		System.out.println("dateDir---1"+dateDir);
		String flowId="";
		String href="";

		if (dateDir.exists()) {

			File emsIdDir = new File(dir+FS+emsId);
			
			System.out.println("emsIdDir---1"+emsIdDir);

			if (emsIdDir.exists()) {

				File listOfFiles[]=emsIdDir.listFiles();
				
				List<String> flowIdList=new ArrayList<String>();
				System.out.println("ListOfFiles---1"+listOfFiles.length);
				
				for (int i = 0; i < listOfFiles.length; i++) {
					File flowIdFile=listOfFiles[i];
					if (flowIdFile.isDirectory()) {				
						flowIdList.add(flowIdFile.getName());
					}
					
				}
				
				List<String> fileListNew=ThurdUseCaseWithFlowID(date, flowIdList, error);						
				
				int count=0;
				  HashMap<String, String> map=new HashMap<String, String>();
				  for(String filePath:fileListNew){				   
					  
					   String[] filenames=filePath.split(FS);
					   
					   System.out.println("filenames--len"+filenames.length);
						  for(int j=filenames.length-1;j>=0;j--){
							  
							  flowId=filenames[j-1];
							   System.out.println("flowId--len"+flowId);									   

							  emsId=filenames[j-2];
							   System.out.println("emsId--len"+emsId);

							  date=filenames[j-3];	
							   System.out.println("date--len"+date);

							  href="search?date="+helper.dateToUser(date)+"&emsId="+emsId+"&flowId="+flowId;
							   System.out.println("href--len"+href);
							   map.put(flowId, href);

							  break;
						  }
					   
					   
				   }	
				  
				  Set<String> keys=map.keySet();
				  for(String s:keys){
					  SearchList searchList=new SearchList();
					  searchList.setHref(map.get(s));
					   searchList.setId(flowId);
					   searchList.setLabel(flowId);	
					   searchLists.add(searchList);
					   count++;
				  }						
				
				System.out.println("href "+href);
				
				System.out.println(searchLists.size());
				
			}else {
				System.out.println("emsId dir not exist");
				throw new InvalidRequestException("V21 has not received the request with the desired EMS id within the specified date range or please check if the EMS Id : " +emsId+ " is correct or not.", "emsId: "+emsId);
			}
		}else {
			System.out.println("date dir not exist");
			throw new InvalidRequestException("Invalid Date", "Date: "+helper.dateToUser(date));
		}

		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		return response;
	}


	public SearchResponse secondSearchCall(String emsId, String date,String flowId) {
		List<SearchList> searchLists = new ArrayList<SearchList>();

		date=helper.dateForOperation(date);
		String dir=V21SearchHelper.dataDir+FS+date;

		System.out.println("SecondSearch"+dir);

				File flowIdDir=new File(dir+FS+emsId+FS+flowId);
				System.out.println("flowIdDir"+dir);

					if (flowIdDir.exists() && flowIdDir.isDirectory()) {

						File listOfFiles[]=flowIdDir.listFiles();

						
						
						System.out.println("listOfFiles"+listOfFiles.length);

						for (int i = 0; i < listOfFiles.length; i++) {
							
							SearchList searchList = new SearchList();
							System.out.println(listOfFiles[i].getName());

							String id=listOfFiles[i].getName();
							
							//String tmpStr[]=flowIdFile.getName().split("_");
							String label=listOfFiles[i].getName();
							
							
							searchList.setLabel(label);

							//String flowPath=flowIdFile.getPath();

							String href="searchFile?date="+helper.dateToUser(date)+"&&emsId="+emsId+"&&flowId="+flowId+"&&fileName="+listOfFiles[i].getName();
							//search?date=01-10-2016&emsId=emsId-100&flowId=100_111
							searchList.setId(id);
							searchList.setHref(href);

							searchLists.add(searchList);
						}

						System.out.println("searchLists"+searchLists.size());

					}else {
						 System.out.println("Directory do not exists");
						 throw new InvalidRequestException("Invalid Flow Id", "flowId: "+flowId);
					}
				
			

		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		return response;
	}

	public SearchResponse prepareSearchResponce(String emsId, String date, List<SearchList> searchLists) {
		SearchResponse response = new SearchResponse();

		SearchCriteria criteria =new SearchCriteria();
		criteria.setDate(helper.dateToUser(date));
		criteria.setEmsId(emsId);

		response.setSearch(criteria);
		
		SearchResult result=new SearchResult();
		result.setCount(searchLists.size());
		result.setData(searchLists);
		response.setResult(result);

		return response;
	}



	public ErrorResponce sendEmail(String emailResult, SearchResponse searchResponse) {
		
		// TODO Auto-generated method stub
		
		ErrorResponce response=new ErrorResponce();
		response.setMessage(helper.sendEmail(emailResult, searchResponse));
		 return response;
		
	}

	public boolean validateUser(Credentials credentials, Map<String, String> mapOfUsers) {

        String password=mapOfUsers.get(credentials.getUsername());
        System.out.println("Password: "+password);
        if (credentials.getPassword().equals(password)) {
              return true;
        } else {
              return false;
        }
        
  }

	
	

}
