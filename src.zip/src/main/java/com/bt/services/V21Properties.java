package com.bt.services;

import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

 
@Configuration
@ComponentScan(basePackages = { "com.bt.*" })
@PropertySource("classpath:config.properties")
@Service
public class V21Properties{

	
	//Properties for data
	@Value("${zipFilepath}")
	private String zipFilepath;

	@Value("${dataDir}")
	private String dataDir;

	@Value("${indexDir}")
	private String indexDir;

	//Properties for user validation
	@Value("${credentials}")
	private String credentials; 

	//Properties for error codes
	@Value("${1100_Error_Txt}")
	private String error_1100_Txt; 

	@Value("${600_Erro_txt_NGA}")
	private String error_600_txt_NGA; 

	@Value("${600_Erro_txt_DSLM}")
	private String erro_600_txt_DSLM;
	
	
	//Properties for mail server
	@Value("${mailServer}")
	private String mailServer;

	@Value("${from}")
	private String from;

	@Value("${toAddresses}")
	private String toAddresses;

	/*@Bean
	public V21Properties v21Properties(){
		return new V21Properties();
	}*/
	
	public Map<String, String> getAllUsers(){
		String users[]=this.credentials.split(",");
		Map<String , String> allUsers = new TreeMap<String, String>();
		for (int i = 0; i < users.length; i++) {
			String userList[]=users[i].split("#");
			allUsers.put(userList[0], userList[1]);

		}

		return allUsers;

	}


	public String getZipFilepath() {
		return zipFilepath;
	}


	public void setZipFilepath(String zipFilepath) {
		this.zipFilepath = zipFilepath;
	}


	public String getDataDir() {
		return dataDir;
	}


	public void setDataDir(String dataDir) {
		this.dataDir = dataDir;
	}


	public String getIndexDir() {
		return indexDir;
	}


	public void setIndexDir(String indexDir) {
		this.indexDir = indexDir;
	}


	public String getCredentials() {
		return credentials;
	}


	public void setCredentials(String credentials) {
		this.credentials = credentials;
	}


	public String getError_1100_Txt() {
		return error_1100_Txt;
	}


	public void setError_1100_Txt(String error_1100_Txt) {
		this.error_1100_Txt = error_1100_Txt;
	}


	public String getError_600_txt_NGA() {
		return error_600_txt_NGA;
	}


	public void setError_600_txt_NGA(String error_600_txt_NGA) {
		this.error_600_txt_NGA = error_600_txt_NGA;
	}


	public String getErro_600_txt_DSLM() {
		return erro_600_txt_DSLM;
	}


	public void setErro_600_txt_DSLM(String erro_600_txt_DSLM) {
		this.erro_600_txt_DSLM = erro_600_txt_DSLM;
	}


	public String getMailServer() {
		return mailServer;
	}


	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}


	public String getFrom() {
		return from;
	}


	public void setFrom(String from) {
		this.from = from;
	}


	public String getToAddresses() {
		return toAddresses;
	}


	public void setToAddresses(String toAddresses) {
		this.toAddresses = toAddresses;
	}
	

}