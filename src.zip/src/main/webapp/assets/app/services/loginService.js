/**
 * Login Service
 * @returns {undefined}
 */

 (function(){
    'use strict';
    
    angular
        .module('MyApp')
        .factory('loginService', loginService);

        loginService.$inject = [ "$localStorage", "$sessionStorage"];

        function loginService($localStorage, $sessionStorage){
            return {
                login : function(loginObj){
                    if(loginObj.remember){
                        $localStorage.userName = loginObj.userName;
                        $localStorage.password = loginObj.password;
                    }else{
                        delete $localStorage.userName;
                        delete $localStorage.password;
                    }
                    $sessionStorage.userName = loginObj.userName;
                    return true;
                },
                getRemember : function(){
                    if($localStorage.userName){
                        return {
                        	userName:$localStorage.userName,
                            password:$localStorage.password,
                            remember:true
                        };
                    }else{
                        return {};
                    }
                },
                isLogedin : function(){
                    if($sessionStorage.userName)
                        return true;
                    else
                        return false;
                },
                logout : function(){
                    console.log('logout...');
                    delete $sessionStorage.userName;
                    return true;
                },
                getUserName : function(){
                    if($sessionStorage.userName)
                        return $sessionStorage.userName;
                    else
                        return "Guest";
                }
            };
        };

})();

