/**
 * Search Controller
 */

(function () {
    'use strict';

    angular
            .module('MyApp')
            .controller('searchByErrorCtrl', searchCtrl);

    searchCtrl.$inject = ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window'];
    
    function searchCtrl($scope, searchService, $state, $filter, toastr, $window) {

        /******* Date Picker  *******/
        $scope.today = function () {
            $scope.date = new Date();
        };
        $scope.today();

        $scope.clear = function () {
            $scope.date = null;
        };

        $scope.opened = false;
        var date=new Date();
        date.setMonth(date.getMonth() - 1);
        
        $scope.dateOptions = {
            //dateDisabled: disabled,
            formatYear: 'yy',
            maxDate: new Date(),
            minDate: date,
            startingDay: 1
        };

        // Disable weekend selection
        function disabled(data) {
            var date = data.date,
                    mode = data.mode;
            return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
        }

        $scope.formats = ['dd-MM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
        $scope.format = $scope.formats[0];

        $scope.loading = false;
        $scope.errorCode = "600";

        $scope.search = function (date, errorCode) {
        	$scope.errorCode = errorCode;
        	$scope.date = date;
            $scope.loading = true;
            date = $filter('date')($scope.date, $scope.format);
            searchService.searchByErrorCode(date, errorCode).then(function (response) {
                
                $scope.loading = false;
                $scope.selection = 'emsid';
                $scope.emsIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.data.message);
                console.log(response);
            });
        };

        $scope.selectEmsId = function(href){
        	$scope.loading = true;
            searchService.selectAnyId(href).then(function (response) {
                $scope.loading = false;
                $scope.selection = 'flowid';
                $scope.flowIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });
        }
        
        $scope.selectFlowId = function (href) {
            $scope.loading = true;
            searchService.selectAnyId(href).then(function (response) {
                $scope.loading = false;
                $scope.selection = 'xml';
                $scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });
        };

        $scope.showPage = function (value) {
            $scope.selection = value;
        };

        //$scope.xmlIds = searchService.getXmlIds();

        $scope.selectXmlId = function (href) {
            $window.open(href, "XML Document", "width=600,scrollbars=yes");
            searchService.selectAnyId(href).then(function (response) {
                //var myWindow = $window.open("", "XML Document", "width=600,height=400");
                //myWindow.document.write(response.data);
                //$scope.loading = false;
                //$scope.selection = 'xml';
                //$scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                //$scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });

        };

    }
    
})();