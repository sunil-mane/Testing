/**
 *
 **/

(function() {
	'use strict';
	angular.module('MyApp', [ "ui.router", "ui.bootstrap", "angularSpinner",
			"ngAnimate", "ngStorage", "toastr" ]);

	angular.element(document).ready(function() {
		angular.bootstrap(document.getElementById('entryPoint'), [ 'MyApp' ]);
	});

})();