/**
 * Login Controller
 * @returns {undefined}
 */

 (function(){
 	'use strict';

 	angular.module('MyApp').controller('loginCtrl', [ "$scope", "$state", "loginService", function($scope, $state, loginService){
 		$scope.loginObj = loginService.getRemember();

 		$scope.login = function(){
 			/**if(loginService.login($scope.loginObj)){
 				$state.go('home.search');
 			}else{
 				$state.go('login');
 			}**/
 			loginService.login($scope.loginObj).then(function(response){
 				loginService.setUserName(response.data.authToken);
 				$state.go('home.search');
 			}).catch(function(response){
 				console.log(response);
 			});

 		};
 	}]);

 })();

