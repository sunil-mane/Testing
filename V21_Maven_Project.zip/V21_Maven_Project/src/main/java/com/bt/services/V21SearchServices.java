package com.bt.services;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.bt.exceptions.InvalidRequestException;
import com.bt.jsonBean.SearchCriteria;
import com.bt.jsonBean.SearchList;
import com.bt.jsonBean.SearchResponse;
import com.bt.jsonBean.SearchResult;

public class V21SearchServices {
	
	V21SearchHelper helper = new V21SearchHelper();
	static String FS = File.separator; 
	
	
	public SearchResponse fourthUseCase(String dateForOperation, String[] flowIds, boolean b) {

		SearchResponse response = new SearchResponse();
		SearchResult result=helper.searchWithFlowIDs(dateForOperation, Arrays.asList(flowIds), false);
		response.setResult(result);
		return response;
	}



	public SearchResponse thirdUseCase(String dateForOperation, List<String> errors) {
		SearchResult result=	helper.searchErrorFiles(dateForOperation, errors);
		SearchResponse response = new SearchResponse();
		response.setResult(result);
		return response;
	}



	public SearchResponse secondUseCase(String date, String flowId,Boolean errorCode) {
		SearchResult  result=null;
		
		List<String> flowIds=new ArrayList<String>();
		flowIds.add(flowId);
		
		if (errorCode) {
			result=helper.searchWithFlowIDs(date, flowIds, false,true);
		} else {
			
			result=helper.searchWithFlowIDs(date, flowIds, false,false);
		} 
		
		SearchResponse response = new SearchResponse();
		response.setResult(result);
		return response;
		
		
		
		
		}
	
	
	public SearchResponse firstSearchCall(String emsId, String date) {
		System.out.println("firstSearchCall");
		List<SearchList> searchLists = new ArrayList<SearchList>();
		date=helper.dateForOperation(date);
		String dir=V21SearchHelper.dataDir+FS+date;
		System.out.println("First search call 1"+dir);
		File dateDir = new File(dir);
		System.out.println("dateDir---1"+dateDir);

		if (dateDir.exists()) {

			File emsIdDir = new File(dir+FS+emsId);
			
			System.out.println("emsIdDir---1"+emsIdDir);

			if (emsIdDir.exists()) {

				File listOfFiles[]=emsIdDir.listFiles();
				System.out.println("ListOfFiles---1"+listOfFiles.length);

				for (int i = 0; i < listOfFiles.length; i++) {
					File flowIdFile=listOfFiles[i];
					if (flowIdFile.isDirectory()) {

						SearchList searchList = new SearchList();

						String id=flowIdFile.getName();
						
						String tmpStr[]=flowIdFile.getName().split("_");
						String label=tmpStr[0];
						
						System.out.println("label---1"+label);

						searchList.setLabel(label);

						//String flowPath=flowIdFile.getPath();

						String href="search?date="+helper.dateToUser(date)+"&&emsId="+emsId+"&&flowId="+id+"";
						System.out.println("href---1"+href);
						//search?date=01-10-2016&emsId=emsId-100&flowId=100_111
						searchList.setId(flowIdFile.getName());
						searchList.setHref(href);

						searchLists.add(searchList);
						
						System.out.println("href "+href);

					}else {
						continue;
					}
				}
				System.out.println(searchLists.size());
				
			}else {
				System.out.println("emsId dir not exist");
				throw new InvalidRequestException("Invalid Ems Id", "emsId: "+emsId);
			}
		}else {
			System.out.println("date dir not exist");
			throw new InvalidRequestException("Invalid Date", "Date: "+helper.dateToUser(date));
		}

		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		return response;
	}




	public SearchResponse secondSearchCall(String emsId, String date,String flowId) {
		List<SearchList> searchLists = new ArrayList<SearchList>();

		date=helper.dateForOperation(date);
		String dir=V21SearchHelper.dataDir+FS+date;

		System.out.println("SecondSearch"+dir);

				File flowIdDir=new File(dir+FS+emsId+FS+flowId);
				System.out.println("flowIdDir"+dir);

					if (flowIdDir.exists() && flowIdDir.isDirectory()) {

						File listOfFiles[]=flowIdDir.listFiles();

						
						SearchList searchList = new SearchList();
						System.out.println("listOfFiles"+listOfFiles.length);

						for (int i = 0; i < listOfFiles.length; i++) {
							System.out.println(listOfFiles[i].getName());

							String id=listOfFiles[i].getName();
							
							//String tmpStr[]=flowIdFile.getName().split("_");
							String label=listOfFiles[i].getName();
							
							
							searchList.setLabel(label);

							//String flowPath=flowIdFile.getPath();

							String href="searchFile?date="+helper.dateToUser(date)+"&&emsId="+emsId+"&&flowId="+flowId+"&&fileName="+listOfFiles[i].getName();
							//search?date=01-10-2016&emsId=emsId-100&flowId=100_111
							searchList.setId(id);
							searchList.setHref(href);

							searchLists.add(searchList);
						}

						System.out.println("searchLists"+searchLists.size());

					}else {
						 System.out.println("Directory do not exists");
						 throw new InvalidRequestException("Invalid Flow Id", "flowId: "+flowId);
					}
				
			

		SearchResponse response = prepareSearchResponce(emsId, date, searchLists);
		return response;
	}

	public SearchResponse prepareSearchResponce(String emsId, String date, List<SearchList> searchLists) {
		SearchResponse response = new SearchResponse();

		SearchCriteria criteria =new SearchCriteria();
		criteria.setDate(helper.dateToUser(date));
		criteria.setEmsId(emsId);

		response.setSearch(criteria);
		
		SearchResult result=new SearchResult();
		result.setCount(searchLists.size());
		result.setData(searchLists);
		response.setResult(result);

		return response;
	}



	public String sendEmail(String emailResult, Object jsonObject) {
		
		// TODO Auto-generated method stub
		
		 return helper.sendEmail(emailResult, jsonObject);
		
	}

	
	
	

}
