package com.bt.services;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.lucene.search.TopDocs;

import com.bt.exceptions.InvalidRequestException;
import com.bt.jsonBean.SearchList;
import com.bt.jsonBean.SearchResult;
import com.bt.lucene.Indexer;
import com.bt.lucene.LuceneTester;
import com.bt.lucene.Searcher;
import com.bt.util.EmailUtility;
import com.bt.util.V21FileUtility;


public class V21SearchHelper {
	
   public Indexer indexer;
   public Searcher searcher;
   public TopDocs hits;
   public static List<String> fileList=new ArrayList<String>();
   public static List<String> pathList=new ArrayList<String>();
   public List<SearchList> searchListData=new ArrayList<SearchList>();
   public String zipFilepath=null;
   
   //Loading config files for file folder path
   public Properties props=new Properties();
   //for linux
   // public Properties props=V21FileUtility.loadPropertyFile("Properties/config.properties");
    V21FileUtility.loadPropertyFile("C://Users//611189996//Desktop//Sagar-Data//V21_Portal_06_10//Maven_proj//Properties//config.properties");
   
   public String indexDir = null;
   public static String dataDir =null;
   static String FS = File.separator;      
   //initializing dir path variables
   public V21SearchHelper(){
	  // V21FileUtility.loadPropertyFile("config.properties");
	   V21FileUtility.loadPropertyFile("C:/Users/611189996/Desktop/Sagar-Data/V21_Portal_06_10/Maven_proj/Properties/config.properties");
	   
	   zipFilepath=this.props.getProperty("zipFilepath");
	   dataDir=this.props.getProperty("dataDir");
	   //dataDir="vServe21/archive/Activation";

	   System.out.println("here daradir value "+dataDir);
	   indexDir=this.props.getProperty("indexDir");	   
	 //  indexDir="v21Portal/lucene/";	  
	   
	  


   }
    
   
   public void searchErrorCodes(List<String> errorCodes, String path) {
	  
	   System.out.println("Inside method searchErrorCodes..."+errorCodes);
	   String error_1100="ems.ConnectionException AND errorDescription";
	   String error_600_NGA="ActivityStatusType AND FAILURE";
	   String error_600_DSLM="responseStatus AND failed";
	   try{
	   LuceneTester tester = new LuceneTester();
	   dataDir=path;
	   System.out.println("path received : "+path);
       tester.createIndex(dataDir);       
       
       List<String> errorfileList=new ArrayList<String>();
      // fileList.clear();
       
       for(String errorCode:errorCodes){
    	   System.out.println("errorCode : "+errorCode);

		   if(errorCode.equals("1100")){
			   System.out.println("Searching for error code 1100");			   
			   
			   tester.search(error_1100);
			  // fileList=LuceneTester.fileList_first;
			   List<String> fileListNew=new ArrayList<String>();
			  
			    fileListNew=LuceneTester.fileList_first;
		    	   System.out.println("fileList_first in 1100: "+LuceneTester.fileList_first);

			    for(String file:fileListNew){
			    	System.out.println("FileList in 1100--"+file);
			    	fileList.add(file);
			    }
			    
		    	   System.out.println("fileList in 1100: "+fileList);

		   }
		   
		   if(errorCode.equals("600")){
			
			  System.out.println("Searching for error code 600" + error_600_NGA);
			  errorfileList=tester.search(error_600_NGA);	
			 // fileList=LuceneTester.fileList_first;
	    	   System.out.println("errorfileList in 600_NGA: "+errorfileList);

			  	List<String> fileListNew=new ArrayList<String>();
			  
			    fileListNew=LuceneTester.fileList_first;
		    	   System.out.println("fileList_first in 600_NGA: "+LuceneTester.fileList_first);

			    for(String file:fileListNew){
			    	System.out.println("FileList in 600_NGA--"+file);

			    	fileList.add(file);
			    }
		    	   System.out.println("fileList in 600_NGA: "+fileList);

			  
			 // System.out.println("fileList size for erros "+fileList);
			  for(String fileName:errorfileList){				
				  if(!fileName.contains("_NGA")){
					  for(int i=0;i<fileList.size();i++){
						  if(fileList.get(i).equals(fileName)){
							  fileList.remove(i);
						  }
						  
					  }
				  }
				  
			  }
			  errorfileList.clear();
			    tester.search(error_600_DSLM);	
			    //fileList=LuceneTester.fileList_first;
			    List<String> fileListNew1=new ArrayList<String>();
				  
			    fileListNew1=LuceneTester.fileList_first;
		    	   System.out.println("fileList in 600_DSLM: "+LuceneTester.fileList_first);

			    for(String file:fileListNew1){
			    	System.out.println("FileList in 600_DSLM--"+file);

			    	fileList.add(file);
			    }
		    	   System.out.println("fileList in 600_DSLM: "+fileList);

			    for(String fileName:errorfileList){
			    	 System.out.println("filename for error 1"+fileName);
					  if(!fileName.contains("_Him_DSLM")){
						  for(int i=0;i<fileList.size();i++){
							  if(fileList.get(i).equals(fileName)){
								  fileList.remove(i);
							  }
							  
						  }
					  }
					  
				  }			   
		   }	
	   }
	   }
	  catch(Exception e){
		  e.printStackTrace();
		  System.err.println("Exception occured inside method searchErrorCodes");
	  }
   }
   
   
   public List<String> searchFlowID(List<String> flowIds, String path){

	   System.out.println("Inside method searchFlowID..."+flowIds);
	   
	   try{
		  // LuceneTester tester = new LuceneTester();
		  // dataDir=path;
	      // tester.createIndex(dataDir);       
	       
	        for(String flowId:flowIds){
			   
	        	pathList.clear();
	        	List<String> newPathIds=new ArrayList<String>();
	             walk(path);          
	             System.out.println( "pathList:" + pathList );
			   
	             for(int i=0; i<pathList.size();i++){
	            	 System.out.println("pathlist sixe : "+i+" "+pathList.size());
	            	 if(pathList.get(i).contains(flowId)){  
	            		 System.out.println("flowId check "+flowId);
	            		 //pathList.remove(i);
	            		 newPathIds.add(pathList.get(i));
	            	 }	            	
	             }
	             pathList=newPathIds;
	             System.out.println( "pathList after filtering" + pathList );
			   
	             if(pathList.isEmpty()){
	            	 flowIds.remove(flowId);
	            	 System.out.println("removed flow if "+flowId);
	             }
		   }
	   }
	  catch(Exception e){
		  System.err.println("Exception occured inside method searchFlowId..");
	  }
	   
	   return flowIds;
   }
   
      
   
   
@SuppressWarnings("finally")
public SearchResult searchErrorFiles(String date, List<String> errorCodes ){
	   
	   System.out.println("Inside method searchErroFiles .... ");
	   V21SearchHelper helper = new V21SearchHelper();
	   SearchResult searchResult=new SearchResult();
	    //List<SearchList>  searchListDataNew=new ArrayList<SearchList>();
	   helper.searchDateFolder(date);
	   try{
		  // fileList.clear();
		   searchListData.clear();
		   for(String path:pathList){
			   helper.searchErrorCodes(errorCodes, path);		   
		   }
		   	   
		   System.out.println("Filelist size is returned after Error codes file search: "+fileList.size());
		   System.out.println("FileList in searchErrorFiles  "+fileList);
		   if(fileList.size()>0){
			  
			   int count=getHref(fileList);		   
			  
			   searchResult.setCount(count);
			   ArrayList<SearchList> searchListDataNew =  (ArrayList<SearchList>) ((ArrayList<SearchList>) searchListData).clone();
			   //Collections.copy(searchListDataNew, searchListData);
			   searchResult.setData(searchListDataNew);
			   
			   for(SearchList searchres:searchListDataNew){
				   System.out.println("searchListDataNew in searchErroFiles "+searchres.getHref());			   
			   }
			}
			   
			 else{
				   System.out.println("Empty list");
				   throw new InvalidRequestException("Invalid Error Code(s)", "errorCode(s): "+errorCodes);
			}
	   }
	   catch(Exception e){
		   e.printStackTrace();
		   System.err.println("Exception occured while searching for errorCodes");
		   
	   }	   
	   finally{
		   System.out.println("Exiting method  searchErrorFiles...");
		   fileList.clear();
		   LuceneTester.fileList_first.clear();
		   searchListData.clear();
		   return searchResult;
	   }
	  
   }


   @SuppressWarnings({ "rawtypes", "unchecked" })
public SearchResult searchWithFlowIDs(String date, List<String> flowIds , boolean sendEmail,boolean errorCode){
		 
	  // errorCode=true;
	   System.out.println("Inside method searchWithFlowIDs");
	   
		V21SearchHelper helper = new V21SearchHelper();
		SearchResult searchResult=new SearchResult();
		List<String> filesFlowIdSpec=new ArrayList<String>();
		//for checking error codes
		List<String> fileNames=new ArrayList<String>();
		ArrayList<SearchList> searchListDataNew =null;
		fileList.clear();
		String dateFolderpath=helper.searchDateFolder(date);
		try{

			flowIds=helper.searchFlowID(flowIds, dateFolderpath);	

			System.out.println("pathList size is "+pathList.size());

			if(pathList.size()>0){	  

				for(String flowIdDirPath:pathList){			   

					File root = new File( flowIdDirPath );
					File[] list = root.listFiles();
					if (list == null) continue;

					for ( File f : list ) {
						if ( f.isFile() && f.getName().endsWith(".xml")) {		        	   
							filesFlowIdSpec.add(f.getAbsolutePath());

						}
					}		       

				}	


				System.out.println("filesFlowIdSpec size is :"+filesFlowIdSpec.size());
				searchListData.clear();

				int count=getHref(filesFlowIdSpec);		 

				searchResult.setCount(count);
				  searchListDataNew =  (ArrayList<SearchList>) ((ArrayList<SearchList>) searchListData).clone();
				searchResult.setData(searchListDataNew);

				for(SearchList searchres:searchListDataNew){
					System.out.println("searchListDataNew "+searchres.getHref());

				}

			}		   

			else{
				System.out.println("Empty list");
				throw new InvalidRequestException("Invalid Flow Id(s)", "flowId: "+flowIds);
			}
			if (errorCode) {
				searchListData.clear();
				for (Iterator<String> iterator = filesFlowIdSpec.iterator(); iterator.hasNext();) {
					String flowPath = iterator.next();
					int lastIndex=flowPath.lastIndexOf(FS)+1;
					
					String fileName=flowPath.substring(lastIndex, flowPath.length());
					fileNames.add(fileName);		
					System.out.println("Added file: "+fileName);
					
					
				}
				List<String> errorCodes = new ArrayList<String>();
				errorCodes.add("600");
				errorCodes.add("1100");
				
				System.out.println("filesFlowIdSpec while errorcode : "+filesFlowIdSpec.size());
				for(String path:pathList){
					
					
					searchErrorCodes(errorCodes, path);			
					
				}
				if(fileList.size()>0){
						
					   int count=getHref(fileList);		   
					  
					   searchResult.setCount(count);
						  searchListDataNew =  (ArrayList<SearchList>) ((ArrayList<SearchList>) searchListData).clone();

					   searchResult.setData(searchListDataNew);
					   
					   for(SearchList searchres:searchListDataNew){
						   System.out.println("searchListDataNew "+searchres.getHref());			   
					   }
					}
					   
					 else{
						   System.out.println("Empty list");
						   throw new InvalidRequestException("Invalid Error Code(s)", "errorCode(s): "+errorCodes);
					}
				
				//searchResult= searchErrorFiles(date, errorCodes);
				System.out.println("searchRes: "+searchResult.getCount());
			}

		}
		catch(Exception e){
			e.printStackTrace();
		}finally{
			searchListData.clear();
			fileList.clear();
		}
		System.out.println("Done ...");

		

		return searchResult;
	}
   
   
   
   public String sendEmail(String emailAdd, Object jsonObject){	   
	   
			try {
			System.out.println("Received email Add : "+emailAdd);
			 byte[] byteoutput=V21FileUtility.zipFiles(jsonObject);
				EmailUtility gm = new EmailUtility();
				String body = gm.getHtmlMessageBody();		
				String subject = "V21 request and response xmls";
				List fileList = gm.getFileList();
			gm.sendMail(subject, body,byteoutput, emailAdd);
			return "Success";

			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.err.println("Exception while sending email");
				e.printStackTrace();
			return "Failure";
			}

		
   }
   
   @SuppressWarnings({ "rawtypes", "unchecked" })
   public SearchResult searchWithFlowIDs(String date, List<String> flowIds , boolean sendEmail){
   		 
   	   
   	   System.out.println("Inside method searchWithFlowIDs");
   	   
   		V21SearchHelper helper = new V21SearchHelper();
   		SearchResult searchResult=new SearchResult();
   		List<String> filesFlowIdSpec=new ArrayList<String>();
   		//for checking error codes
   		List<String> fileNames=new ArrayList<String>();
   		fileList.clear();
   		String dateFolderpath=helper.searchDateFolder(date);
   		try{

   			flowIds=helper.searchFlowID(flowIds, dateFolderpath);	

   			System.out.println("pathList size is "+pathList.size());

   			if(pathList.size()>0){	  

   				for(String flowIdDirPath:pathList){			   

   					File root = new File( flowIdDirPath );
   					File[] list = root.listFiles();
   					if (list == null) continue;

   					for ( File f : list ) {
   						if ( f.isFile() && f.getName().endsWith(".xml")) {		        	   
   							filesFlowIdSpec.add(f.getAbsolutePath());

   						}
   					}		       

   				}	


   				System.out.println("filesFlowIdSpec size is :"+filesFlowIdSpec.size());
   				searchListData.clear();

   				int count=0;		 
   				
	   			 for(int i=0; i<flowIds.size();i++){
	   				SearchList searchList=new SearchList();
	  			  			  
	   				String href="search?date="+dateToUser(date)+"&emsId="+""+"&flowId="+flowIds.get(i);
	   				searchList.setHref(href);
	   				searchList.setId(flowIds.get(i));
	   				searchList.setLabel(flowIds.get(i));				   
	   				count++;
	   				searchListData.add(searchList);
	   			 }

   				searchResult.setCount(count);
   				searchResult.setData(searchListData);

   				for(SearchList searchres:searchListData){
   					System.out.println("searchListData "+searchres.getHref());

   				}

   			}		   

   			else{
   				System.out.println("Empty list");
   				throw new InvalidRequestException("Invalid Flow Id(s)", "flowId: "+flowIds);
   			}
   			

   		}
   		catch(Exception e){
   			e.printStackTrace();
   		}
   		
   		//V21FileUtility.zipFile(pathList, zipFilepath);
   		System.out.println("Done ...");

   		
   		return searchResult;
   	}

   

   public int getHref(List<String> fileList){
	   
	  String href=null;
	  String fileName=null;
	  String flowId=null;
	  String emsId=null;
	  String date=null;
	  int count=0;
	  for(String filePath:fileList){
		   SearchList searchList=new SearchList();
		  
		   String[] filenames=filePath.split(FS);
		   
		   System.out.println("filenames--len"+filenames.length);
			  for(int i=filenames.length-1;i>=0;i--){

				  fileName=filenames[i];
				   System.out.println("fileName--len"+fileName);

				  flowId=filenames[i-1];
				   System.out.println("flowId--len"+flowId);

				  emsId=filenames[i-2];
				   System.out.println("emsId--len"+emsId);

				  date=filenames[i-3];	
				   System.out.println("date--len"+date);

				  href="searchFile?date="+dateToUser(date)+"&emsId="+emsId+"&flowId="+flowId+"&fileName="+fileName;
				   System.out.println("href--len"+href);

				  break;
			  }
		   
		   searchList.setHref(href);
		   searchList.setId(fileName);
		   searchList.setLabel(fileName);				   
		   count++;
		   searchListData.add(searchList);
	   }	

	   return count;
	   
   }
   
   @SuppressWarnings("rawtypes")
public List walk( String path ) {

       File root = new File( path );
       File[] list = root.listFiles();
      

       if (list == null) return null;

       for ( File f : list ) {
           if ( f.isDirectory() ) {
               walk( f.getAbsolutePath() );
               System.out.println( "Dir:" + f.getAbsoluteFile() );
           }
           else {
               System.out.println( "File:" + f.getAbsoluteFile() );
               pathList.add(path);
               break;
           }
       }
       return pathList;
   }
   
   public String searchDateFolder(String date){
	   
	   File root = new File(dataDir);
	   System.out.println("datedir : "+dataDir);
	   System.out.println("inside seachDateFlder :"+date+" "+root.getAbsolutePath());
       File[] list = root.listFiles();
       String dateFolderpath=null;

       System.out.println("list her "+list);
       if (list == null){
    	   System.out.println("fileList is empty");
    	   return null;
       }

       for ( File f : list ) {
           if ( f.isDirectory() && f.getName().equals(date)) {
        	   pathList.clear();
        	   dateFolderpath=f.getAbsolutePath();
               walk( f.getAbsolutePath() );
               System.out.println( "Dir:" + f.getAbsoluteFile() );
               System.out.println( "pathList:" + pathList );
               break;
           }
       }
       return dateFolderpath;
	   
   }
   
   
   

   public static void main(String[] args) {
	      V21SearchHelper tester;
	      try {
	         tester = new V21SearchHelper();	         
	         //tester.createIndex();
	        // tester.search("ems.ConnectionException AND errorDescription");
	         List<String> errorCodes=new ArrayList<String>();
	         errorCodes.add("1100");
	         errorCodes.add("600");
	         
	         List<String> flowIds=new ArrayList<String>();
	         flowIds.add("873864633");         
	         
	         
	      // tester.searchWithFlowIDs("06_10_16", flowIds);
	       tester.searchErrorFiles("06_10_16", errorCodes);
	         //tester.search("Ethernet");
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	   }

   
   public String dateForOperation(String oldDateString) {
		final String  NEW_FORMAT = "dd_M_yy";
		final String  OLD_FORMAT= "dd-M-yyyy";
		String newDateString;

		SimpleDateFormat sdf = new SimpleDateFormat(OLD_FORMAT);
		Date d = null;
		try {
			d = sdf.parse(oldDateString.replace("_", "-"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sdf.applyPattern(NEW_FORMAT);
		newDateString = sdf.format(d);
		return newDateString;
	}
   
   
	public String dateToUser(String oldDateString) {
		final String OLD_FORMAT = "dd_M_yy";
		final String NEW_FORMAT = "dd-M-yyyy";
		//oldDateString = "01_10_16";
		String newDateString;

		SimpleDateFormat sdf = new SimpleDateFormat(OLD_FORMAT);
		Date d = null;
		try {
			d = sdf.parse(oldDateString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sdf.applyPattern(NEW_FORMAT);
		newDateString = sdf.format(d);
		return newDateString;
	}
   
   
}
