package com.bt.util;

import java.io.*;
import java.util.*;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import com.bt.services.V21SearchHelper;

public class EmailUtility {
	
		
       public synchronized void sendMail(String subject, String body, byte[] bytes, String EmailAdd )throws Exception {
	// public synchronized void sendMail(String subject, String body, List<String> attachments, String EmailAdd )throws Exception {
        try{
                      Properties prop = new Properties();
                      prop.load(new FileInputStream("C:/Users/605561302/NPM/V21/V21_Woekspace/FileUtil/Mail.properties"));
                      String toAdd = "";
                  String ccAdd = "";

                  String mailServer = prop.getProperty("mailServer");
                  String from = prop.getProperty("from");
                  String toAddresses = EmailAdd;
                  String ccAddresses = prop.getProperty("ccAddresses");

                  Properties properties = System.getProperties();
                  properties.setProperty("mail.smtp.host", mailServer);
                  Session session = Session.getDefaultInstance(properties);
                  MimeMessage message = new MimeMessage(session);
                  StringTokenizer toList = new StringTokenizer(toAddresses, ";");
                  StringTokenizer ccList = new StringTokenizer(ccAddresses, ";");
                   int i = 0;
                   while (toList.hasMoreTokens()) {
                     i++;

                     toAdd = toList.nextToken();
                     //System.out.println("toAdd---"+toAdd);
                     InternetAddress address = new InternetAddress(toAdd);
                     message.addRecipient(Message.RecipientType.TO, address);
                   }

                   i = 0;
                   while (ccList.hasMoreTokens()) {
                     i++;
                     ccAdd = ccList.nextToken();
                     //System.out.println("ccAdd---"+ccAdd);
                     InternetAddress address = new InternetAddress(ccAdd);
                     message.addRecipient(Message.RecipientType.CC, address);
                   }

              message.setFrom(new InternetAddress(from));
              message.setSubject(subject);
              MimeBodyPart mimeBodyPart = new MimeBodyPart();
              mimeBodyPart.setText(body);
              mimeBodyPart.setContent(body, "text/html");
              Multipart multiPart = new MimeMultipart();
              multiPart.addBodyPart(mimeBodyPart);

              /*for (String fileName : attachments) {
                MimeBodyPart MimeBodyPart = new MimeBodyPart();
                FileDataSource fds = new FileDataSource(fileName);
                MimeBodyPart.setDataHandler(new DataHandler(fds));
                MimeBodyPart.setFileName(fds.getName());
                multiPart.addBodyPart(MimeBodyPart);
              }*/
              
              DataSource dataSource = new ByteArrayDataSource(bytes, "application/zip");
              MimeBodyPart zipBodyPart = new MimeBodyPart();
              zipBodyPart.setDataHandler(new DataHandler(dataSource));
              zipBodyPart.setFileName("test.zip");            
              multiPart.addBodyPart(zipBodyPart);

              message.setContent(multiPart);
              message.setSentDate(new Date());
              Transport.send(message);
              System.out.println("Sent message successfully....");
           }catch (MessagingException mex) {
               mex.printStackTrace();
           }
}
        public String getHtmlMessageBody()throws Exception {
                 File file = new File("C:/Users/605561302/NPM/V21/V21_Woekspace/FileUtil/Report.html");
             StringBuilder stringBuilder = new StringBuilder();
             BufferedReader reader = new BufferedReader(new FileReader(file));
             String line= null;
                    while ((line = reader.readLine()) != null) {
                            stringBuilder.append(line);
                    }
             //System.out.println(stringBuilder.toString());
             return stringBuilder.toString();
     }

     public String getMailSubject()throws Exception {
             File file = new File("SUBJECT.dat");
             StringBuilder stringBuilder = new StringBuilder();
             BufferedReader reader = new BufferedReader(new FileReader(file));
             String line= null;
                    while ((line = reader.readLine()) != null) {
                            stringBuilder.append(line);
                    }
             //System.out.println(stringBuilder.toString());
             //return stringBuilder.toString();
             String sub = stringBuilder.toString();
             sub= "["+ sub+"]:New HE - EC Diagnostics Report";
             return sub;
     }

     public List getFileList()throws Exception {
             File outputDir = new File("C:\\Users\\605561302\\NPM\\V21\\test.zip");
             List fileList = new ArrayList();
             
             fileList.add(outputDir.getAbsolutePath());
             return fileList;
     }

     public static void main(String a[])throws Exception {
         EmailUtility gm = new EmailUtility();
             String body = gm.getHtmlMessageBody();
             String subject = "V21 request and response xmls";
             List fileList = gm.getFileList();
            // gm.sendMail(subject, body,fileList, "");
     }
}
	


