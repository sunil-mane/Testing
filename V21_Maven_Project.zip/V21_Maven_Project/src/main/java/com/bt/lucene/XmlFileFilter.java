package com.bt.lucene;


import java.io.File;
import java.io.FileFilter;

public class XmlFileFilter implements FileFilter {

   public boolean accept(File pathname) {
      return pathname.getName().toLowerCase().endsWith(".xml");
   }
}