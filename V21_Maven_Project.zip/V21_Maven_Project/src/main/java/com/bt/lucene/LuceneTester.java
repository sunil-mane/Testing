package com.bt.lucene;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.json.simple.JSONObject;

import com.bt.jsonBean.SearchList;
import com.bt.jsonBean.SearchResult;
import com.bt.services.V21SearchHelper;



public class LuceneTester {
	
   //String indexDir = "C:\\Users\\605561302\\NPM\\V21\\Data";
//   String dataDir = "C:\\Users\\605561302\\NPM\\V21\\873864633";
  static  String dataDir ="C:\\Users\\605561302\\NPM\\V21\\Data_Files";
   //String dataDir ="C:\\Users\\605561302\\NPM\\V21\\566343512";   
   Indexer indexer;
   Searcher searcher;
   TopDocs hits;
   public static List<String> fileList_first=new ArrayList<String>();
  // public static List<String> pathList_first=new ArrayList<String>();
   public List<SearchList> searchListData=new ArrayList<SearchList>();
   
   public static void main(String[] args) {
      LuceneTester tester;
      try {
         tester = new LuceneTester();
         //tester.createIndex();
        // tester.search("ems.ConnectionException AND errorDescription");
         List<String> errorCodes=new ArrayList<String>();
         errorCodes.add("1100");
         errorCodes.add("600");
         
         List<String> flowIds=new ArrayList<String>();
         flowIds.add("873864633");         
         
         
      // tester.searchWithFlowIDs("06_10_16", flowIds);
       //tester.searchErrorFiles("06_10_16", errorCodes);
         //tester.search("Ethernet");
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   public void createIndex(String dataDir1) throws IOException{
	   V21SearchHelper helper=new V21SearchHelper();
      indexer = new Indexer(helper.indexDir);
      int numIndexed;
      long startTime = System.currentTimeMillis();	
      System.out.println("here path "+dataDir1);
      numIndexed = indexer.createIndex(dataDir1, new XmlFileFilter());
      long endTime = System.currentTimeMillis();
      indexer.close();
      System.out.println(numIndexed+" File indexed, time taken: "
         +(endTime-startTime)+" ms");		
   }

   public List<String> search(String searchQuery) throws IOException, ParseException{
	   V21SearchHelper helper=new V21SearchHelper();
      searcher = new Searcher(helper.indexDir);
      long startTime = System.currentTimeMillis();
       hits = searcher.search(searchQuery);
      long endTime = System.currentTimeMillis();
      String filePath=null;
      List<String> fileListNew=new ArrayList<String>();
   System.out.println("FileList before clear"+fileList_first.size());
      fileList_first.clear();
      System.out.println("FileList after clear"+fileList_first.size());
      System.out.println(hits.totalHits +
         " documents found. Time :" + (endTime - startTime));
      for(ScoreDoc scoreDoc : hits.scoreDocs) {
         Document doc = searcher.getDocument(scoreDoc);
         filePath=doc.get(LuceneConstants.FILE_PATH);
            System.out.println("File: "
            + filePath);
            fileList_first.add(filePath);
            fileListNew.add(filePath);
            System.out.println("fileList_first her "+fileList_first.size());
            System.out.println("fileListNew her "+fileListNew.size());

            
      }
      searcher.close();
      return fileListNew;
      
   }  
   
  
   
   
}
