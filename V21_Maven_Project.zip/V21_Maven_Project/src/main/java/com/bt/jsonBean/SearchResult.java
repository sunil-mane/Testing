package com.bt.jsonBean;

import java.util.List;

public class SearchResult {

	
	private int count;
	private  List<SearchList> data;
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<SearchList> getData() {
		return data;
	}
	public void setData(List<SearchList> data) {
		this.data = data;
	}
	
	
	
}
