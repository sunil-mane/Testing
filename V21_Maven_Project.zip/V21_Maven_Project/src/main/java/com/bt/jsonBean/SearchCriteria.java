package com.bt.jsonBean;

public class SearchCriteria {
	
	private String date;
	private String emsId;
	private String flowId;
	private String failureResponse;
	private String errorcode;
	
	
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getEmsId() {
		return emsId;
	}
	public void setEmsId(String emsId) {
		this.emsId = emsId;
	}
	public String getFlowId() {
		return flowId;
	}
	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}
	public String getFailureResponse() {
		return failureResponse;
	}
	public void setFailureResponse(String failureResponse) {
		this.failureResponse = failureResponse;
	}
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	
	
}
