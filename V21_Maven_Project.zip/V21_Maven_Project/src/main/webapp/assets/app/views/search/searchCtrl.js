/**
 * Search Controller
 */

(function () {
    'use strict';

    angular
            .module('MyApp')
            .controller('searchCtrl', searchCtrl);

    searchCtrl.$inject = ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window'];
    
    function searchCtrl($scope, searchService, $state, $filter, toastr, $window) {

        /******* Date Picker  *******/
        $scope.today = function () {
            $scope.date = new Date();
        };
        $scope.today();

        $scope.clear = function () {
            $scope.date = null;
        };

        $scope.opened = false;
        var date=new Date();
        date.setMonth(date.getMonth() - 1);
        
        $scope.dateOptions = {
            //dateDisabled: disabled,
            formatYear: 'yy',
            maxDate: new Date(),
            minDate: date,
            startingDay: 1
        };

        // Disable weekend selection
        function disabled(data) {
            var date = data.date,
                    mode = data.mode;
            return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
        }

        $scope.formats = ['dd-MM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
        $scope.format = $scope.formats[0];

        $scope.loading = false;

        $scope.search = function (date, emsId) {
        	$scope.ems_id = emsId;
        	$scope.date = date;
            $scope.loading = true;
            date = $filter('date')($scope.date, $scope.format);
            searchService.search(date, emsId).then(function (response) {
                
                $scope.loading = false;
                $scope.selection = 'flowid';
                $scope.flowIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.data.message);
                console.log(response);
            });
        };

        $scope.selectFlowId = function (flowId) {
            $scope.loading = true;
            searchService.selectFlowId(flowId).then(function (response) {
                $scope.loading = false;
                $scope.selection = 'xml';
                $scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });
        };

        $scope.showPage = function (value) {
            $scope.selection = value;
        };

        //$scope.xmlIds = searchService.getXmlIds();

        $scope.selectXmlId = function (xmlId) {
            $window.open(xmlId, "XML Document", "width=600,scrollbars=yes");
            searchService.selectFlowId(xmlId).then(function (response) {
                //var myWindow = $window.open("", "XML Document", "width=600,height=400");
                //myWindow.document.write(response.data);
                //$scope.loading = false;
                //$scope.selection = 'xml';
                //$scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                //$scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });

        };

    }
    
})();