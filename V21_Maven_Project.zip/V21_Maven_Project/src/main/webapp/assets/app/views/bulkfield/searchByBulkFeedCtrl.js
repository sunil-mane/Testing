/**
 * Search Controller
 */

(function () {
    'use strict';

    angular
            .module('MyApp')
            .controller('searchByBulkFeedCtrl', searchCtrl);

    searchCtrl.$inject = ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window'];
    
    function searchCtrl($scope, searchService, $state, $filter, toastr, $window) {

        /******* Date Picker  *******/
        $scope.today = function () {
            $scope.date = new Date();
        };
        $scope.today();
        $scope.email={};
        $scope.clear = function () {
            $scope.date = null;
        };
        $scope.selection="";
        $scope.opened = false;

        var date=new Date();
        date.setMonth(date.getMonth() - 1);
        $scope.dateOptions = {
            //dateDisabled: disabled,
            formatYear: 'yy',
            maxDate: new Date(),
            minDate: date,
            startingDay: 1
        };

        // Disable weekend selection
        function disabled(data) {
            var date = data.date,
                    mode = data.mode;
            return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
        }

        $scope.formats = ['dd-MM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
        $scope.format = $scope.formats[0];
        $scope.flowid_1=$scope.flowid_1?undefined:$("#flowid_1").val();
        $scope.loading = false;

        $scope.search = function () {
            $scope.loading = true;
            $scope.flowid_1=$scope.flowid_1?undefined:$("#flowid_1").val();
            var date = $filter('date')(date, $scope.format);
            searchService.searchByFlowId(date, $scope.flowid_1).then(function (response) {
               
                $scope.loading = false;
                $scope.selection = 'flowid';
                $scope.flowIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });
        };

        $scope.searchBulkIds= function(date,flowid){
        	
        	  $scope.loading = true;
         $scope.date = date;
         $scope.flowid_1 = flowid;
            var date = $filter('date')(date, $scope.format);
            searchService.bulkSearch({date:date, flowId:flowid}).then(function (response) {
               
                $scope.loading = false;
                $scope.selection = 'flowid';
                $scope.flowIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });
        }
        $scope.searhformInvalid=false;
        $scope.checkdata=function(data){
        	var count = (data.match(/,/g) || []).length;
        	if(count>29){
        		$scope.searhformInvalid=true;
        	}else{
        		$scope.searhformInvalid=false;
        	}
        }
      
        
        $scope.sendMail= function(emailOrZip,mailids){
        	
        	var date = $filter('date')($scope.date, $scope.format);
        	//$scope.email_id;
        	if(emailOrZip=='email'){
            searchService.sendMailorZip(mailids, $scope.flowIds).then(function (response) {
            	if(response.result=="Success"){
            		 $scope.loading = false;
                     $scope.selection = 'success';
                     $scope.flowIds = response.res;
            	}
               
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });
        	}else{
        		searchService.sendMailorZip(null, $scope.flowIds).then(function (response) {
                    
                    $scope.loading = false;
                    $scope.selection = 'flowid';
                    $scope.flowIds = response.data.result.data;
                }).catch(function (response) {
                    $scope.loading = false;
                    toastr.error('Error :' + response.statusText);
                    console.log(response);
                });
        	}
        }
        
        
        
        $scope.selectFlowId = function (flowId) {
            $scope.loading = true;
            searchService.selectFlowId(flowId).then(function (response) {
                $scope.loading = false;
                $scope.selection = 'xml';
                $scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });
        };

        $scope.showPage = function (value) {
            $scope.selection = value;
        };

        //$scope.xmlIds = searchService.getXmlIds();

        $scope.selectXmlId = function (xmlId) {
            $window.open('dataController/' + xmlId, "XML Document", "width=600,scrollbars=yes");
            searchService.selectFlowId(xmlId).then(function (response) {
                //var myWindow = $window.open("", "XML Document", "width=600,height=400");
                //myWindow.document.write(response.data);
                //$scope.loading = false;
                //$scope.selection = 'xml';
                //$scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                //$scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });

        };

    }
    
})();