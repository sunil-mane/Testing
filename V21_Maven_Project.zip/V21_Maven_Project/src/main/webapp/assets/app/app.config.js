/**
 * 
 */

(function () {
    angular
            .module('MyApp')
            .config(function (toastrConfig) {
                angular.extend(toastrConfig, {
                    closeButton: true,
                    progressBar: true
                });
            });
})();