/**
 *  Search Service
 */

(function(){
    'use strict';
    
    angular
            .module('MyApp')
            .factory('searchService', searchService);
    
    searchService.$inject = [ "$http"];
    
    function searchService($http){
        function search(date, emsId){
            //return $http.get('assets/data/flowids.json');
            return $http.get('search?date='+date+'&emsId='+emsId);
        }
        
        function selectFlowId(flowId){
            //return $http.get('assets/data/xml.json');
            return $http.get(flowId);
        }
        
        function selectXmlId(xmlId){
            return $http.get(xmlId);
        }
        
        function searchByFlowId(date, flowId){
            return $http.get('search?date='+date+'&flowId='+flowId);
        }
        
        function searchByErrorCode(date, errorCode){
        	return $http.get('search?date='+date+'&errorCode='+errorCode);
        }
        
        
        function sendMailorZip(mailds,data){
        	if(mailds!=null){
        		return $http.get('sendEmail?emailResult='+mailds+'&jsonObject='+JSON.stringify(data));
        	}else{
        		return $http.get('zip?jsonObject='+JSON.stringify(data));
        	}
        	
        }
        
        function bulkSearch(data){
        	return $http.post('search',data);
        }
        
        return {
            search:search,
            searchByFlowId:searchByFlowId,
            searchByErrorCode:searchByErrorCode,
            selectFlowId:selectFlowId,
            selectXmlId:selectXmlId,
            bulkSearch:bulkSearch,
            sendMailorZip:sendMailorZip
        };
    }
    
})();