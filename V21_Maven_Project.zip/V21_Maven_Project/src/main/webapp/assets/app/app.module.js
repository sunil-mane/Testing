angular.module('MyApp', [
    "ui.router",
    "ui.bootstrap",
    "angularSpinner",
    "ngAnimate",
    "ngStorage",
    "toastr"
]);